VL MIC HOST 0.3.3 / Windows 10 and 11 x64

Changes:
- MUTE MONITORING with a short gain ramp; separate stereo STREAM output.
- Mixer scales with the window, including controls and mouse hit-testing.
- Dedicated dark JUCE title bar separates window controls from the mixer.

MONITOR is the headphone/speaker output pair. STREAM must be assigned to a
separate available pair on the selected audio device, and captured by your
recording software. STREAM defaults off at launch. Recording the MONITOR
pair is also silenced by MUTE MONITORING. Hardware direct monitoring is not
controlled by this button. This version does not include a virtual driver.
WASAPI/DirectSound and VST3 supported; AU is macOS-only; ASIO not enabled.

Build: JUCE 8.0.6 + Visual Studio 2022 C++ + CMake + Inno Setup 6.
Run Packaging/build-windows.ps1. The script compiles, checks the engine and
monitor routing, and creates the installer with full AGPL source.
The 0.3.3 Windows build and visual verification are pending execution.

Plugin search (0.3.3):
Add effect opens a searchable browser. Match by name, manufacturer or format;
multiple words narrow the results. Double-click or press Load selected.
Scan all installed VST3 searches system and per-user standard VST3 folders
without filtering manufacturers. Scan VST3 folder... adds a custom location
for the current scan. Instruments are omitted from this microphone FX host.
AU is macOS-only. VST2, CLAP and 32-bit plugins are not supported.
Failed scans are isolated; see the library and scan-log.txt for failures.
