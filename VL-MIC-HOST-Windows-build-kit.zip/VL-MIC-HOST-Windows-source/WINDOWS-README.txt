VL MIC HOST NIGHT — Windows x64 port

STATUS: source and installer configuration prepared; Windows build and runtime
have NOT been executed on the development Mac. A successful GitHub Actions
run creates the actual installer. This source archive is not an installer.

Build requirements: Windows 10/11 x64, Visual Studio 2022 C++ Desktop tools,
CMake >=3.22, JUCE 8.0.6 source in JUCE/, Inno Setup 6.
Run Packaging/build-windows.ps1 in PowerShell.

GitHub: upload this directory as a repository root (keep .github).
Open Actions -> Build Windows installer -> Run workflow.
The result is the VL-MIC-HOST-Windows-x64 artifact containing Setup.exe,
complete source, checksums and a smoke-test report. This workflow does not
publish releases or upload user recordings/settings.

VST3 x64 effects only. AU is macOS-only. Intel 32-bit effects are unsupported.
Audio: WASAPI (including exclusive mode offered by JUCE), DirectSound fallback.
ASIO is not enabled in this build. Use the interface vendor's Windows driver.
Actual device latency, plugin compatibility and installer/uninstaller behavior
must be verified on Windows. CI checks signal pass-through, stop and preset recall.

Install: run Setup.exe. Installation is per-user; no administrator rights are
requested. Source and AGPLv3 license are included. No developer certificate is
configured, so Windows may show a publisher/SmartScreen warning.

Start: Audio setup -> select device/backend and sample buffer. Scan installed
VST3 effects, populate inserts, set reverb Mix to 100% wet on FX RETURN,
then START AUDIO. Settings live in %APPDATA%\VL MIC HOST.
No virtual microphone or third-party effects are installed.
