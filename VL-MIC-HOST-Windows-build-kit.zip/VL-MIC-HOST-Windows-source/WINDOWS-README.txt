VL MIC HOST 0.6.7 NIGHT — Windows 10 / 11 x64

1. УСТАНОВКА
Запустите VL-MIC-HOST-0.6.7-NIGHT-Windows-x64-Setup.exe.
Сторонние плагины и аппаратные ASIO-драйверы не входят в установщик.

2. АУДИО / ASIO
Установите x64 ASIO-драйвер от производителя карты.
Audio setup → Audio device type = ASIO → драйвер карты.
Активируйте микрофонный Input 1, гитарный Input 2 и нужные выходы.
Настройте 48 kHz и 128 / 64 samples; если настройку задаёт драйвер,
используйте Show control panel. Доступны также WASAPI и DirectSound.

3. ПЛАГИНЫ
Поддерживаются VST2 (.dll) и VST3 для Windows x64.
Plug-ins / Scan → Scan all installed VST2 / VST3.
Проверяются стандартные системные и пользовательские VST3-папки,
VSTPlugins / Steinberg VstPlugins / Common Files VST2 и пути VSTPluginsPath
в реестре. Подпапки учитываются; ограничения по производителям нет.
Если плагины стоят на другом диске, Add plug-in folder сохраняет его путь.
Retry failed / rescan перепроверяет каталог с очисткой кэша сканирования.
Scan report показывает все классы WaveShell, ошибки архитектуры и таймауты.
В All plug-ins / search ищите по имени, производителю, формату и категории.
При загрузке WaveShell host context задаётся до поиска выбранного класса.
Имя и ID выбранного эффекта проверяются также при загрузке пресета.
Check load / GUI проверяет выбранный плагин; Check all VST / GUI проверяет
все найденные VST-модули. Проверка выполняется в отдельных процессах и
не означает автоматическую активацию коммерческого плагина.
32-bit, AU, AAX, CLAP и плагины для другой ОС не поддерживаются.
Установите лицензии / ресурсы / библиотеки производителя отдельно.

4. ГОЛОС И ГИТАРА
MIC INPUT = Input 1; CHANNEL 2 = Audio / guitar, его вход = Input 2.
У каждого канала шесть отдельных insert-слотов, trim, fader и mute.
Эффекты CHANNEL 2 не применяются к MIC.
START AUDIO включает обработку; выключите direct monitoring карты,
если слышите сухой сигнал вместе с обработанным.

5. MIDI
CHANNEL 2 → + Load instrument → Serum, Kontakt или другой VST2/VST3.
Выберите звук внутри GUI инструмента, затем MIDI INPUT = ваша клавиатура.
Есть фильтр MIDI-канала, экранные клавиши, sustain, pitch bend, CC и PANIC.
Одновременно с микрофоном CHANNEL 2 работает как гитара или как MIDI.

6. ЧЕТЫРЕ ПАРАЛЛЕЛЬНЫХ FX
MIC FX 1 / MIC FX 2 принадлежат только MIC.
CH 2 FX 1 / CH 2 FX 2 принадлежат только CHANNEL 2.
У каждого FX отдельный фейдер, meter, M (Mute), S (Solo).
FX 2 получает исходный сигнал канала, а не обработанный выход FX 1.
SEND у каждого канала общий для двух его FX; Mix внутри реверба / дилея
ставьте 100% wet. Плагины продолжают обрабатываться при mute возврата.

7. МОНИТОРИНГ / OBS
MONITOR — наушники; STREAM / RECORD — отдельная пара для записи.
MUTE MONITORING глушит только MONITOR. Для передачи звука нужен подключённый
Discord / Virtual Mic либо отдельная активная пара STREAM / RECORD.
OBS должен записывать обработанный STREAM-источник, без дублирования
этого же голоса через сырой микрофон или системное аудио.
Собственный виртуальный драйвер VL MIC в этой версии не включён.

DISCORD / VIRTUAL MIC
Установите VB-CABLE: https://vb-audio.com/Cable/
Discord / Virtual Mic → CABLE Input (VB-Audio Virtual Cable) → Connect.
В Audio setup оставьте карту ASIO или WASAPI. Нажмите START AUDIO.
В Discord: вход — CABLE Output, выход — наушники / карта.
Голос с эффектами, CHANNEL 2 и FX передаются независимо от MUTE MONITORING.
Подробная инструкция — Discord-Подключение.txt в папке установки и окно
Discord / Virtual Mic в программе.

8. ПРЕСЕТЫ
Сохраняются 17 слотов, инструмент, MIDI и четыре FX-фейдера / mute / solo.
Пресеты v1–v4 читаются, но прежние два последовательных эффекта FX-шины
становятся двумя параллельными эффектами: проверьте звучание и уровни.
Mac AU-пресет не превращается в Windows VST автоматически: установите
Windows-версии плагинов и заново выберите формат при необходимости.

9. ИСХОДНИКИ / СБОРКА
AGPL-3.0-only, без гарантий. Полные исходники и лицензии входят в комплект.
JUCE 8.0.6 с backport исправления WaveShell 3fa28d0; открытые GPLv3 интерфейсы ASIO и FST / VST2 включены.
Visual Studio 2022 C++, CMake >= 3.22, Inno Setup 6.
Packaging/build-windows.ps1 собирает, проверяет маршрутизацию / MIDI /
ASIO / поиск и создаёт установщик. См. README.md и ThirdParty/FST/UPSTREAM.txt.
