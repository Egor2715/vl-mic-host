// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 VL MIC HOST contributors

#include "Engine.h"
#include "Scanner.h"
#include "PluginBrowser.h"
#include "PluginDiscovery.h"
using namespace juce;

#if JUCE_WINDOWS
static_assert(JUCE_ASIO == 1, "Windows releases must include ASIO support");
#endif

static String validatePluginSearch()
{
    PluginDescription effect;effect.name="Guitar Amp";effect.manufacturerName="Independent Developer";effect.pluginFormatName="VST3";effect.category="Distortion";
    PluginDescription synth;synth.name="Piano";synth.manufacturerName="Another Developer";synth.pluginFormatName="VST3";synth.isInstrument=true;
    bool ok=pluginMatchesSearch(effect,"") && pluginMatchesSearch(effect,"gUiTaR independent") && pluginMatchesSearch(effect,"distortion vst3")
        && pluginMatchesSearch(synth,"piano another") && !pluginMatchesSearch(effect,"piano");
    bool slotsOk=pluginMatchesSlot(effect,false) && !pluginMatchesSlot(effect,true)
        && pluginMatchesSlot(synth,true) && !pluginMatchesSlot(synth,false);
    effect.numInputChannels=2;effect.numOutputChannels=2;
    slotsOk=slotsOk && pluginMatchesSlot(effect,false);
    auto temp=File::getSpecialLocation(File::tempDirectory).getChildFile("VL-search-test-"+Uuid().toString());
    auto vstFolder=temp.getChildFile("custom-vst3");vstFolder.createDirectory();
    auto settings=temp.getChildFile("locations.xml");PluginLocations paths(settings);
    ok=paths.addVst3Folder(vstFolder) && ok;
    PluginLocations recalled(settings);VST3PluginFormat format;
    auto locations=recalled.forFormat(format);bool found=false;
    for(int i=0;i<locations.getNumPaths();++i)found=found||locations[i]==vstFolder;
    ok=ok && found;temp.deleteRecursively();
    String report=ok?"PASS: arbitrary manufacturers, effects and instruments, case-insensitive multi-word search, category, persistent custom VST3 folders\n":"FAIL: general plug-in search / folder recall\n";
    report+=slotsOk?"PASS: VST3 effects with unknown channel counts remain selectable; effects and instruments use their own slots\n":"FAIL: plug-in slot classification\n";
    // Exercise the actual picker with VST3 fast-scan descriptions, including
    // separate classes in one WaveShell file. No user catalog is read or changed.
    KnownPluginList library;
    PluginDescription mono;mono.name="Waves mono";mono.manufacturerName="Waves";mono.pluginFormatName="VST3";mono.fileOrIdentifier="test/WaveShell.vst3";mono.uniqueId=101;
    auto stereo=mono;stereo.name="Waves stereo";stereo.uniqueId=102;
    auto reverb=mono;reverb.name="Valhalla reverb";reverb.manufacturerName="Valhalla DSP";reverb.fileOrIdentifier="test/reverb.vst3";reverb.uniqueId=103;
    synth.fileOrIdentifier="test/piano.vst3";synth.uniqueId=104;
    for(auto d:{mono,stereo,reverb,synth})library.addType(d);
    int selectedId=0;PluginPicker picker(library,[&](PluginDescription d){selectedId=d.uniqueId;},{},{});
    TextEditor* search=nullptr;ListBox* rows=nullptr;TextButton* load=nullptr;
    for(auto* child:picker.getChildren())
    {
        if(auto* s=dynamic_cast<TextEditor*>(child))search=s;
        if(auto* r=dynamic_cast<ListBox*>(child))rows=r;
        if(auto* b=dynamic_cast<TextButton*>(child);b && b->getButtonText()=="Load selected")load=b;
    }
    bool pickerOk=search && rows && load && rows->getListBoxModel()->getNumRows()==3;
    if(pickerOk)
    {
        search->setText("waves",false);search->onTextChange();
        pickerOk=rows->getListBoxModel()->getNumRows()==2 && load->isEnabled();
        rows->selectRow(1);load->onClick();pickerOk=pickerOk && selectedId==102;
        search->setText("valhalla",false);search->onTextChange();
        load->onClick();pickerOk=pickerOk && rows->getListBoxModel()->getNumRows()==1 && selectedId==103;
    }
    report+=pickerOk?"PASS: picker searches zero-count Waves / Valhalla descriptions and dispatches the selected class to the load callback\n":"FAIL: zero-count VST3 picker selection / load callback\n";
    return report;
}

class PanelWindow : public DocumentWindow
{
public:
    PanelWindow(String title, Component* body) : DocumentWindow(title,Colour(0xff181d1b),closeButton)
    { setUsingNativeTitleBar(true); setContentOwned(body,true); setResizable(true,false); centreWithSize(body->getWidth(),body->getHeight()); setVisible(true); }
    void closeButtonPressed() override { setVisible(false); }
};

class LibraryPanel final : public Component, private Timer
{
public:
    explicit LibraryPanel(Engine& e):engine(e),list(e.formats,e.known,e.dataFolder().getChildFile("scan-in-progress.txt"),nullptr,true),locations(e.dataFolder().getChildFile("plugin-locations.xml"))
    {
        addAndMakeVisible(priority);addAndMakeVisible(folder);addAndMakeVisible(retry);addAndMakeVisible(tabs);
        catalog=std::make_unique<PluginPicker>(engine.known,std::function<void(PluginDescription)>{},[this]{tabs.setCurrentTabIndex(1);},std::function<void()>{},false,true);
        tabs.addTab("All plug-ins / search",Colour(0xff121a25),catalog.get(),false);
        tabs.addTab("Scan / failed plug-ins",Colour(0xff121a25),&list,false);
#if JUCE_WINDOWS
        priority.setButtonText("Scan all installed VST3");
#else
        priority.setButtonText("Scan all installed AU / VST3");
#endif
        priority.onClick=[this]{beginScan(false);};
        retry.setButtonText("Retry failed / rescan");retry.onClick=[this]{beginScan(true);};
        folder.setButtonText("Add VST3 folder...");
        folder.onClick=[this]{
            if(list.isScanning()||pending>=0)return;
            chooser=std::make_unique<FileChooser>("Choose an additional VST3 folder");
            const SafePointer<LibraryPanel> safe(this);
            chooser->launchAsync(FileBrowserComponent::openMode|FileBrowserComponent::canSelectDirectories,[safe](const FileChooser& fc){
                if(!safe||!fc.getResult().isDirectory())return;
                if(!safe->locations.addVst3Folder(fc.getResult()))return;
                safe->engine.live=false;safe->tabs.setCurrentTabIndex(1);
                for(auto* f:safe->engine.formats.getFormats())if(f->getName()=="VST3")
                    safe->list.scanFor(*f,f->searchPathsForPlugins(FileSearchPath(fc.getResult().getFullPathName()),true,false));
            });
        };
        list.setNumberOfThreadsForScanning(1);
        list.setScanDialogText("VL / Isolated plug-in scan","Each plug-in is checked in a separate process. Failed plug-ins are skipped.");
        setSize(900,600);
    }
    ~LibraryPanel()override {stopTimer();tabs.clearTabs();}
    void resized()override{priority.setBounds(12,10,getWidth()-438,32);retry.setBounds(getWidth()-414,10,198,32);folder.setBounds(getWidth()-210,10,198,32);tabs.setBounds(0,52,getWidth(),getHeight()-52);}
private:
    Engine& engine;TextButton priority,folder,retry;PluginListComponent list;PluginLocations locations;
    std::unique_ptr<PluginPicker> catalog;TabbedComponent tabs{TabbedButtonBar::TabsAtTop};
    std::unique_ptr<FileChooser> chooser;int pending=-1;
    void beginScan(bool retryFailures)
    {
        if(list.isScanning()||pending>=0)return;
        engine.live=false;tabs.setCurrentTabIndex(1);
        if(retryFailures)
        {
            engine.known.clearBlacklistedFiles();
            engine.dataFolder().getChildFile("scan-in-progress.txt").deleteFile();
        }
        pending=0;startTimer(200);
    }
    void timerCallback() override
    {
        if(list.isScanning())return;
        auto formats=engine.formats.getFormats();
        if(pending>=formats.size()){pending=-1;stopTimer();return;}
        auto* f=formats[pending++];
        auto candidates=f->searchPathsForPlugins(locations.forFormat(*f),true,false);candidates.removeDuplicates(false);
        if(!candidates.isEmpty())list.scanFor(*f,candidates);
    }
};

namespace Night
{
    const Colour mint{0xff8fe3ce}, lavender{0xffb7a0ed}, white{0xffdce5f0};
    const Colour muted{0xff8291a5}, border{0xff26303e};
}
class MixerLook final : public LookAndFeel_V4
{
public:
    void drawButtonBackground(Graphics& g,Button& b,const Colour&,bool over,bool down) override
    {
        auto r=b.getLocalBounds().toFloat().reduced(0.5f);
        auto accent=b.findColour(TextButton::buttonOnColourId);
        auto c=b.getToggleState()?accent.withAlpha(0.24f):Colour(0xff171f2b);
        if(over)c=c.brighter(0.13f);if(down)c=c.darker(0.2f);
        g.setGradientFill(ColourGradient(c.brighter(0.06f),0,0,c,0,r.getBottom(),false));
        g.fillRoundedRectangle(r,7);
        g.setColour((b.getToggleState()?accent:Night::border).withAlpha(b.isEnabled()?0.9f:0.3f));
        g.drawRoundedRectangle(r,7,1);
    }
    void drawRotarySlider(Graphics& g,int x,int y,int w,int h,float value,float start,float end,Slider& slider) override
    {
        auto r=Rectangle<float>((float)x,(float)y,(float)w,(float)h).reduced(9);
        float radius=jmin(r.getWidth(),r.getHeight())*0.5f, cx=r.getCentreX(),cy=r.getCentreY();
        auto accent=slider.findColour(Slider::rotarySliderFillColourId);
        Path track,fill;track.addCentredArc(cx,cy,radius,radius,0,start,end,true);
        fill.addCentredArc(cx,cy,radius,radius,0,start,start+value*(end-start),true);
        g.setColour(Night::border);g.strokePath(track,PathStrokeType(3));
        g.setColour(accent.withAlpha(0.08f));g.strokePath(fill,PathStrokeType(11));
        g.setColour(accent);g.strokePath(fill,PathStrokeType(3));
        g.setGradientFill(ColourGradient(Colour(0xff293342),cx,cy-radius,Colour(0xff0d121a),cx,cy+radius,false));
        g.fillEllipse(cx-radius+7,cy-radius+7,2*radius-14,2*radius-14);
        g.setColour(Night::border);g.drawEllipse(cx-radius+7,cy-radius+7,2*radius-14,2*radius-14,1);
        float angle=start+value*(end-start)-MathConstants<float>::halfPi;
        g.setColour(accent);g.drawLine(cx+std::cos(angle)*(radius-17),cy+std::sin(angle)*(radius-17),cx+std::cos(angle)*(radius-9),cy+std::sin(angle)*(radius-9),2);
    }
    void drawLinearSlider(Graphics& g,int x,int y,int w,int h,float pos,float min,float max,Slider::SliderStyle style,Slider& slider) override
    {
        if(style!=Slider::LinearVertical){LookAndFeel_V4::drawLinearSlider(g,x,y,w,h,pos,min,max,style,slider);return;}
        float centre=x+w*0.5f;auto accent=slider.findColour(Slider::thumbColourId);
        g.setColour(Colour(0xff080c12));g.fillRoundedRectangle(centre-5,(float)y,10,(float)h,5);
        g.setColour(Night::border);for(int j=0;j<=10;++j){float ty=y+h*j/10.0f;g.drawHorizontalLine((int)ty,centre-23,centre-12);g.drawHorizontalLine((int)ty,centre+12,centre+23);}
        g.setColour(accent.withAlpha(0.25f));g.fillRoundedRectangle(centre-1,pos,2,jmax(0.0f,y+h-pos),1);
        auto cap=Rectangle<float>(centre-17,pos-15,34,30);
        g.setColour(Colours::black.withAlpha(0.5f));g.fillRoundedRectangle(cap.translated(0,3).expanded(2),5);
        g.setGradientFill(ColourGradient(accent.brighter(0.15f),centre,pos-15,accent.darker(0.55f),centre,pos+15,false));g.fillRoundedRectangle(cap,4);
        g.setColour(accent.withAlpha(0.9f));g.drawRoundedRectangle(cap.reduced(0.5f),4,1);
        g.setColour(Colour(0xff141c26));g.fillRect(centre-15,pos-2,30.0f,4.0f);
        g.setColour(accent.brighter());g.drawHorizontalLine((int)pos,centre-14,centre+14);
    }
};

class MainPanel final : public Component, private Timer
{
public:
    MainPanel()
    {
        look.setColour(ResizableWindow::backgroundColourId,Colour(0xff0c1119));
        look.setColour(TextButton::textColourOffId,Night::white);
        look.setColour(TextButton::textColourOnId,Night::white);
        look.setColour(TextButton::buttonOnColourId,Night::mint);
        look.setColour(Slider::trackColourId,Night::mint);
        look.setColour(Slider::thumbColourId,Night::white);
        look.setColour(Slider::rotarySliderFillColourId,Night::mint);
        look.setColour(Slider::textBoxTextColourId,Night::white);
        look.setColour(Slider::textBoxOutlineColourId,Colours::transparentBlack);
        look.setColour(ComboBox::backgroundColourId,Colour(0xff141c27));
        look.setColour(ComboBox::outlineColourId,Night::border);
        look.setColour(ComboBox::textColourId,Night::white);
        look.setColour(PopupMenu::backgroundColourId,Colour(0xff141c27));
        look.setColour(PopupMenu::highlightedBackgroundColourId,Colour(0xff30443f));
        setLookAndFeel(&look);
        button(audio,"Audio setup",[this]{ showAudio(); });
        button(plugins,"Plug-ins / Scan",[this]{ showPlugins(); });
        button(save,"Save preset",[this]{ filePreset(true); });
        button(load,"Load preset",[this]{ filePreset(false); });
        button(diagnostics,"Diagnostics",[this]{
            if(engine.live){error("Stop audio before running diagnostics.");return;}
            Engine test;auto report=test.selfTest()+test.channelTest();
            for(auto& d:test.known.getTypes())engine.known.addType(d);
            auto f=engine.dataFolder().getChildFile("validation.txt");f.replaceWithText(report);
            auto* text=new TextEditor();text->setMultiLine(true);text->setReadOnly(true);text->setText(report);text->setSize(850,600);
            diagnosticWindow=std::make_unique<PanelWindow>("VL / Validation report",text);
            status=report.contains("FAIL")?"Diagnostics: a check failed. See validation report.":"Diagnostics passed. AU / VST3 test effects added to library.";
        });
        button(monitorMute,"MUTE MONITORING",[this]{
            if(!engine.monitorMuted && (engine.streamChannel<0 || std::abs(engine.streamChannel.load()-engine.outputChannel.load())<2))
            {error("To mute monitoring and keep the recording, first select a separate STREAM / RECORD output pair. If recording captures the MONITOR pair, muting it also mutes the recording.");return;}
            engine.monitorMuted=!engine.monitorMuted.load();
        });
        monitorMute.setTooltip("Mute only MONITOR. STREAM output continues; use a separate pair for recording.");
        stream.addItem("Stream off",1);stream.setSelectedId(1);
        stream.onChange=[this]{engine.streamChannel=stream.getSelectedId()-2;};addAndMakeVisible(stream);
        button(power,"START AUDIO",[this]{ sessionEdited=true;engine.live=!engine.live.load(); });
        mode.addItem("Stereo out",1); mode.addItem("Mono out",2); mode.setSelectedId(1);
        mode.onChange=[this]{ engine.mono=mode.getSelectedId()==2; }; addAndMakeVisible(mode);
        mic.onChange=[this]{ if(mic.getSelectedId()>0) engine.micChannel=mic.getSelectedId()-1; }; addAndMakeVisible(mic);
        output.onChange=[this]{ if(output.getSelectedId()>0) engine.outputChannel=output.getSelectedId()-1; }; addAndMakeVisible(output);
        gain(inGain,-60,24,[this]{engine.inputGain=Decibels::decibelsToGain((float)inGain.getValue());});
        gain(outGain,-60,12,[this]{engine.outputGain=Decibels::decibelsToGain((float)outGain.getValue());});
        extraMode.addItem("Channel 2 off",1);extraMode.addItem("Audio / guitar",2);extraMode.addItem("MIDI instrument",3);extraMode.setSelectedId(1);
        extraMode.onChange=[this]{sessionEdited=true;engine.setExtraSource((Engine::ExtraSource)(extraMode.getSelectedId()-1));refresh();};addAndMakeVisible(extraMode);
        extraInput.onChange=[this]{if(extraInput.getSelectedId()>0)engine.extraChannel=extraInput.getSelectedId()-1;};addAndMakeVisible(extraInput);
        midiDevices.onChange=[this]{auto i=midiDevices.getSelectedId()-2;auto e=engine.selectMidiInput(isPositiveAndBelow(i,midiList.size())?midiList[i].identifier:String{});if(e.isNotEmpty())error(e);};addAndMakeVisible(midiDevices);
        midiFilter.addItem("All MIDI channels",1);for(int c=1;c<=16;++c)midiFilter.addItem("MIDI channel "+String(c),c+1);midiFilter.setSelectedId(1);
        midiFilter.onChange=[this]{engine.panic();engine.midiChannel=midiFilter.getSelectedId()-1;};addAndMakeVisible(midiFilter);
        button(panicButton,"PANIC / notes off",[this]{engine.panic();});
        keyboard=std::make_unique<MidiKeyboardComponent>(engine.keyboard,MidiKeyboardComponent::horizontalKeyboard);
        keyboard->setAvailableRange(48,84);keyboard->setLowestVisibleKey(48);keyboard->setKeyWidth(23);keyboard->setWantsKeyboardFocus(false);addAndMakeVisible(*keyboard);
        gain(extraTrim,-60,24,[this]{engine.extraTrim=Decibels::decibelsToGain((float)extraTrim.getValue());});
        gain(extraFader,-60,12,[this]{engine.extraGain=Decibels::decibelsToGain((float)extraFader.getValue(),-60.0f);});
        gain(extraSend,-60,0,[this]{engine.extraSend=Decibels::decibelsToGain((float)extraSend.getValue(),-60.0f);});extraSend.setValue(-60);
        extraTrim.setSliderStyle(Slider::RotaryHorizontalVerticalDrag);extraTrim.setTextBoxStyle(Slider::TextBoxBelow,false,90,22);
        extraSend.setSliderStyle(Slider::RotaryHorizontalVerticalDrag);extraSend.setTextBoxStyle(Slider::TextBoxBelow,false,90,22);
        extraFader.setSliderStyle(Slider::LinearVertical);extraFader.setTextBoxStyle(Slider::TextBoxBelow,false,90,22);
        extraTrim.setColour(Slider::rotarySliderFillColourId,Night::lavender);extraFader.setColour(Slider::thumbColourId,Night::lavender);extraSend.setColour(Slider::rotarySliderFillColourId,Night::lavender);
        extraMute.setClickingTogglesState(true);button(extraMute,"MUTE CH 2",[this]{sessionEdited=true;engine.extraMute=extraMute.getToggleState();});
        for(int i=0;i<Engine::slotCount;++i)
        {
            auto& row=rows[(size_t)i];row.bypass.setTooltip("Bypass insert");row.up.setTooltip("Move insert up");row.down.setTooltip("Move insert down");row.remove.setTooltip("Remove insert");
            button(row.add,"+ Add effect",[this,i]{ choose(i); });
            button(row.edit,"GUI",[this,i]{ edit(i); });
            row.bypass.setClickingTogglesState(true);
            button(row.bypass,"B",[this,i]{engine.bypass(i,rows[(size_t)i].bypass.getToggleState());});
            button(row.up,"^",[this,i]{closeEditors();engine.move(i,i-1);refresh();});
            button(row.down,"v",[this,i]{closeEditors();engine.move(i,i+1);refresh();});
            button(row.remove,"X",[this,i]{editors[(size_t)i].reset();engine.remove(i);sessionEdited=true;refresh();});
        }
        gain(dryFader,-60,12,[this]{engine.dryGain=Decibels::decibelsToGain((float)dryFader.getValue(),-60.0f);});
        gain(sendLevel,-60,0,[this]{engine.sendGain=Decibels::decibelsToGain((float)sendLevel.getValue(),-60.0f);});
        gain(returnFader,-60,12,[this]{engine.returnGain=Decibels::decibelsToGain((float)returnFader.getValue(),-60.0f);});
        for(auto* f:{&dryFader,&returnFader,&outGain}){f->setSliderStyle(Slider::LinearVertical);f->setTextBoxStyle(Slider::TextBoxBelow,false,90,24);}
        for(auto* b:{&dryMute,&fxMute,&fxSolo})b->setClickingTogglesState(true);
        button(dryMute,"MUTE MIC",[this]{engine.dryMute=dryMute.getToggleState();});
        button(fxMute,"MUTE FX",[this]{engine.fxMute=fxMute.getToggleState();});
        button(fxSolo,"SOLO FX",[this]{engine.fxSolo=fxSolo.getToggleState();});
        button(lastSession,"Last session",[this]{
            auto x=XmlDocument::parse(engine.dataFolder().getChildFile("last-chain.vlmic"));
            if(!x){error("No saved session yet.");return;}closeEditors();auto e=engine.restore(*x);sessionEdited=e.isEmpty();if(e.isNotEmpty())error(e);else status="Last session restored. Output stopped.";refresh();
        });
        status="Choose your interface. Put reverb on FX RETURN and set its Mix to 100% wet.";
        dryFader.setColour(Slider::thumbColourId,Night::mint);
        returnFader.setColour(Slider::thumbColourId,Night::lavender);
        for(auto* knob:{&inGain,&sendLevel}){knob->setSliderStyle(Slider::RotaryHorizontalVerticalDrag);knob->setTextBoxStyle(Slider::TextBoxBelow,false,90,22);}
        sendLevel.setColour(Slider::rotarySliderFillColourId,Night::lavender);
        fxMute.setColour(TextButton::buttonOnColourId,Night::lavender);fxSolo.setColour(TextButton::buttonOnColourId,Night::lavender);
        extraTrim.setName("Channel 2 trim");extraFader.setName("Channel 2 level");extraSend.setName("Channel 2 FX send");
        inGain.setName("Input trim");dryFader.setName("Microphone level");sendLevel.setName("Send to FX");returnFader.setName("FX return level");outGain.setName("Master level");
        setSize(1280,1000); refresh(); startTimerHz(24);
    }
    ~MainPanel() override
    {
        stopTimer(); closeEditors(); pluginWindow.reset(); audioWindow.reset(); diagnosticWindow.reset();
        engine.live=false;
        if(started)if(auto x=engine.devices.createStateXml()) x->writeTo(engine.dataFolder().getChildFile("device.xml"));
        if (sessionEdited) engine.preset()->writeTo(engine.dataFolder().getChildFile("last-chain.vlmic"));
        setLookAndFeel(nullptr);
    }
    void paint(Graphics& g) override
    {
        g.setGradientFill(ColourGradient(Colour(0xff121a26),0,0,Colour(0xff080c12),1280,1000,false));g.fillAll();
        g.setColour(Night::mint);g.setFont(FontOptions(29.0f,Font::bold));g.drawText("VL",24,16,48,36,Justification::centredLeft);
        g.setColour(Night::white);g.setFont(FontOptions(16.0f,Font::bold));g.drawText("MIC HOST",82,16,180,24,Justification::centredLeft);
        g.setColour(Night::muted);g.setFont(10.0f);g.drawText("N I G H T   /   0.4.2",83,41,180,16,Justification::centredLeft);
        panel(g,{24,82,606,378});panel(g,{654,82,602,378});
        label(g,"MIC / 6 INSERTS",42,96);label(g,"CHANNEL 2",672,96);
        label(g,"MIC INPUT",42,135);
        for(int i=0;i<6;++i)
        {
            g.setFont(12.0f);g.setColour(Night::muted);
            g.drawText(String(i+1).paddedLeft('0',2),42,180+i*42,25,30,Justification::centredLeft);
            g.drawText(String(i+1).paddedLeft('0',2),672,180+i*42,25,30,Justification::centredLeft);
        }
        panel(g,{24,474,1232,112});label(g,"SHARED FX / REVERB",42,486);
        g.setColour(Night::lavender);g.setFont(12.0f);g.drawText("100% wet in the reverb. Blend with MIC / CH 2 sends and FX return.",230,484,1000,25,Justification::centredLeft);
        channel(g,24,"MIC",Night::mint);channel(g,338,"CHANNEL 2",Night::lavender);channel(g,652,"FX RETURN",Night::lavender);channel(g,966,"MASTER",Night::white);
        label(g,"TRIM",43,649);label(g,"TRIM",357,649);label(g,"SEND",125,649);label(g,"SEND",439,649);
        const int xs[]={270,584,898,1212};const float levels[]={dryLevel,extraLevel,fxLevel,outLevel};
        for(int i=0;i<4;++i)
        {
            verticalMeter(g,{xs[i],658,10,150},levels[i],i==0?Night::mint:i==3?Night::white:Night::lavender);
            g.setColour(Night::muted);g.setFont(10.0f);
            for(int j=0;j<6;++j)g.drawText(String(-j*12),xs[i]+15,652+j*29,27,16,Justification::centredLeft);
            g.drawText(levelText(levels[i]),xs[i]-74,812,110,18,Justification::centredRight);
        }
        g.setColour(Night::border);g.drawHorizontalLine(858,24,1256);
        label(g,"MONITOR",24,866);label(g,"STREAM / RECORD",306,866);label(g,"OUTPUT",588,866);
        label(g,"MIDI INPUT",24,930);
        g.setColour(Night::muted);g.setFont(10.0f);g.drawText(deviceInfo,24,914,1232,14,Justification::centredLeft);
        g.setFont(10.0f);g.drawText(status,24,978,1232,18,Justification::centredLeft);
    }
    void resized() override
    {
        audio.setBounds(340,22,110,32);plugins.setBounds(458,22,136,32);save.setBounds(602,22,112,32);load.setBounds(722,22,112,32);lastSession.setBounds(842,22,118,32);diagnostics.setBounds(968,22,110,32);
        mic.setBounds(145,130,462,32);
        extraMode.setBounds(814,92,174,30);extraInput.setBounds(998,92,236,30);
        power.setBounds(1080,872,176,32);monitorMute.setBounds(866,872,204,32);
        stream.setBounds(306,884,270,26);output.setBounds(24,884,270,26);mode.setBounds(588,884,154,26);
        inGain.setBounds(34,670,90,116);sendLevel.setBounds(120,670,88,116);dryFader.setBounds(194,646,78,170);
        extraTrim.setBounds(348,670,90,116);extraSend.setBounds(434,670,88,116);extraFader.setBounds(508,646,78,170);
        returnFader.setBounds(790,646,94,170);outGain.setBounds(1104,646,94,170);
        dryMute.setBounds(42,822,124,26);extraMute.setBounds(356,822,124,26);fxMute.setBounds(670,822,106,26);fxSolo.setBounds(786,822,106,26);
        midiDevices.setBounds(24,950,240,26);midiFilter.setBounds(276,950,172,26);panicButton.setBounds(460,950,144,26);keyboard->setBounds(622,932,634,44);
        for(int i=0;i<Engine::slotCount;++i)
        {
            auto& r=rows[(size_t)i];int x=75,y=178,nameWidth=342;
            if(i<6)y+=i*42;
            else if(i<Engine::fxEnd){x=42+(i-6)*612;y=532;nameWidth=390;}
            else if(i==Engine::instrumentSlot){x=672;y=132;nameWidth=366;}
            else{x=705;y=178+(i-Engine::extraFirst)*42;nameWidth=326;}
            r.add.setBounds(x,y,nameWidth,32);int bx=x+nameWidth+5;
            r.edit.setBounds(bx,y,42,32);r.bypass.setBounds(bx+47,y,30,32);r.up.setBounds(bx+82,y,28,32);r.down.setBounds(bx+115,y,28,32);r.remove.setBounds(bx+148,y,30,32);
            if(i==Engine::instrumentSlot){r.up.setVisible(false);r.down.setVisible(false);r.remove.setBounds(bx+84,y,30,32);}
        }
    }
    Engine engine;
    void openEditorForTest(int i) {edit(i);}
private:
    struct Row {TextButton add,edit,bypass,up,down,remove;};
    MixerLook look;
    std::array<Row,Engine::slotCount> rows;
    std::array<std::unique_ptr<PanelWindow>,Engine::slotCount> editors;
    std::unique_ptr<PanelWindow> pluginWindow,audioWindow,diagnosticWindow,pickerWindow;
    std::unique_ptr<FileChooser> chooser;
    TextButton audio,plugins,save,load,power,monitorMute,diagnostics,lastSession,dryMute,fxMute,fxSolo,extraMute,panicButton;
    ComboBox mic,output,mode,stream,extraMode,extraInput,midiDevices,midiFilter;
    Array<MidiDeviceInfo> midiList;String midiSignature;std::unique_ptr<MidiKeyboardComponent> keyboard;
    Slider inGain,outGain,dryFader,sendLevel,returnFader,extraTrim,extraFader,extraSend;
    String status,deviceInfo,channelSignature;
    float inLevel=0,outLevel=0,dryLevel=0,fxLevel=0,extraLevel=0;
    bool started=false, sessionEdited=false;
    void button(TextButton& b,const String& text,std::function<void()> f) {b.setButtonText(text);b.onClick=std::move(f);addAndMakeVisible(b);}
    void gain(Slider& s,double min,double max,std::function<void()> f) {s.setRange(min,max,0.1);s.setValue(0);s.setTextValueSuffix(" dB");s.setSliderStyle(Slider::LinearHorizontal);s.setTextBoxStyle(Slider::TextBoxRight,false,76,26);s.onValueChange=[this,f=std::move(f)]{sessionEdited=true;f();};addAndMakeVisible(s);}
    void panel(Graphics& g,Rectangle<int> bounds)
    {
        auto r=bounds.toFloat();
        g.setColour(Colours::black.withAlpha(0.25f));g.fillRoundedRectangle(r.translated(0,3),12);
        g.setGradientFill(ColourGradient(Colour(0xff121a25),r.getX(),r.getY(),Colour(0xff0b1018),r.getX(),r.getBottom(),false));g.fillRoundedRectangle(r,12);
        g.setColour(Night::border);g.drawRoundedRectangle(r.reduced(0.5f),12,1);
    }
    void channel(Graphics& g,int x,String title,Colour accent)
    {
        panel(g,{x,602,290,252});
        g.setColour(accent);g.fillRoundedRectangle((float)x+18,620,4,17,2);
        g.setFont(FontOptions(14.0f,Font::bold));g.drawText(title,x+32,615,230,27,Justification::centredLeft);
    }
    void verticalMeter(Graphics& g,Rectangle<int> r,float v,Colour accent)
    {
        g.setColour(Colour(0xff060a0f));g.fillRoundedRectangle(r.toFloat().expanded(3),4);
        auto fill=r.toFloat();float h=fill.getHeight()*jlimit(0.0f,1.0f,(Decibels::gainToDecibels(v,-60.0f)+60)/60);fill.setY(fill.getBottom()-h);fill.setHeight(h);
        auto c=v>=1?Colour(0xffff876e):accent;
        g.setColour(c.withAlpha(0.08f));g.fillRoundedRectangle(fill.expanded(4),4);
        g.setGradientFill(ColourGradient(c,fill.getX(),fill.getY(),c.darker(0.35f),fill.getX(),fill.getBottom(),false));g.fillRoundedRectangle(fill,2);
        g.setColour(Colour(0xff0c121b));g.fillRect(r.getX()+5,r.getY(),2,r.getHeight());
    }
    void label(Graphics& g,String text,int x,int y) {g.setFont(FontOptions(11.0f,Font::bold));g.setColour(Night::muted);g.drawText(text,x,y,260,20,Justification::centredLeft);}
    String levelText(float v) {return String(Decibels::gainToDecibels(v,-90.0f),1)+" dBFS"+(v>=1?"  CLIP":"");}
    void meter(Graphics& g,Rectangle<int> r,float value,Colour accent) {g.setColour(Night::border);g.fillRoundedRectangle(r.toFloat(),2);g.setColour(value>=1?Colour(0xffff866d):accent);g.fillRoundedRectangle(r.toFloat().withWidth(r.getWidth()*jlimit(0.0f,1.0f,(Decibels::gainToDecibels(value,-60.0f)+60)/60)),2);}
    void error(String e) {status=e;AlertWindow::showMessageBoxAsync(MessageBoxIconType::WarningIcon,"VL MIC HOST",e);}
    void closeEditors() {for(auto& e:editors)e.reset();}
    void refresh()
    {
        for(int i=0;i<Engine::slotCount;++i) {auto& r=rows[(size_t)i];auto& s=engine.slots[(size_t)i];bool has=s.plugin!=nullptr;r.add.setButtonText(has?s.description.name:(i==Engine::instrumentSlot?"+ Load instrument":"+ Add effect"));r.edit.setEnabled(has);r.bypass.setEnabled(has);r.remove.setEnabled(has);r.bypass.setToggleState(s.bypass,dontSendNotification);r.up.setEnabled(i!=0 && i!=6 && i!=8 && i!=9);r.down.setEnabled(i!=5 && i!=7 && i!=8 && i!=14);}
        dryFader.setValue(Decibels::gainToDecibels(engine.dryGain.load(),-60.0f),dontSendNotification);sendLevel.setValue(Decibels::gainToDecibels(engine.sendGain.load(),-60.0f),dontSendNotification);returnFader.setValue(Decibels::gainToDecibels(engine.returnGain.load(),-60.0f),dontSendNotification);
        dryMute.setToggleState(engine.dryMute,dontSendNotification);fxMute.setToggleState(engine.fxMute,dontSendNotification);fxSolo.setToggleState(engine.fxSolo,dontSendNotification);
        extraMode.setSelectedId(engine.extraSource+1,dontSendNotification);extraInput.setSelectedId(engine.extraChannel+1,dontSendNotification);midiFilter.setSelectedId(engine.midiChannel+1,dontSendNotification);
        extraTrim.setValue(Decibels::gainToDecibels(engine.extraTrim.load(),-60.0f),dontSendNotification);extraFader.setValue(Decibels::gainToDecibels(engine.extraGain.load(),-60.0f),dontSendNotification);extraSend.setValue(Decibels::gainToDecibels(engine.extraSend.load(),-60.0f),dontSendNotification);extraMute.setToggleState(engine.extraMute,dontSendNotification);
        extraInput.setEnabled(engine.extraSource==(int)Engine::ExtraSource::audio);
        inGain.setValue(Decibels::gainToDecibels(engine.inputGain.load(),-60.0f),dontSendNotification);outGain.setValue(Decibels::gainToDecibels(engine.outputGain.load(),-60.0f),dontSendNotification);mode.setSelectedId(engine.mono?2:1,dontSendNotification);
    }
    void showAudio()
    {
        if(!started)
        {
            auto e=engine.start();started=e.isEmpty();if(e.isNotEmpty())error(e);
        }
        if(!audioWindow) {auto* c=new AudioDeviceSelectorComponent(engine.devices,0,32,0,32,false,false,false,false);c->setSize(580,520);audioWindow=std::make_unique<PanelWindow>("VL / Audio setup",c);}
        audioWindow->setVisible(true);audioWindow->toFront(true);
    }
    void showPlugins()
    {
        if(!pluginWindow) {pluginWindow=std::make_unique<PanelWindow>("VL / Plug-in library",new LibraryPanel(engine));}
        pluginWindow->setVisible(true);pluginWindow->toFront(true);
    }
    void choose(int i)
    {
        auto safe=SafePointer<MainPanel>(this);
        pickerWindow=std::make_unique<PanelWindow>("VL / Find plug-in",new PluginPicker(engine.known,[safe,i](PluginDescription d){
            if(!safe)return;safe->editors[(size_t)i].reset();safe->sessionEdited=true;auto e=safe->engine.load(i,d);
            if(e.isNotEmpty())safe->error(e);else {safe->status="Loaded "+d.name;safe->pickerWindow->setVisible(false);}safe->refresh();
        },[safe]{if(safe)safe->showPlugins();},[safe,i]{if(safe)safe->legacyChoose(i);},i==Engine::instrumentSlot));
    }
    void legacyChoose(int i)
    {
        auto list=engine.known.getTypes();
        std::sort(list.begin(),list.end(),[](const auto& a,const auto& b){return (a.name+a.pluginFormatName).compareIgnoreCase(b.name+b.pluginFormatName)<0;});
        PopupMenu menu;menu.addItem(1,"Scan / manage plug-ins...");menu.addSeparator();
        int transferTarget=-1;
        if(engine.slots[i].plugin && i!=Engine::instrumentSlot)
        {
            for(int j=(i<6?6:0);j<(i<6?8:6);++j)if(!engine.slots[j].plugin){transferTarget=j;break;}
            if(transferTarget>=0)menu.addItem(2,i<6?"Move this insert to FX RETURN":"Move this insert to MICROPHONE");
            menu.addSeparator();
        }
        for(int k=0;k<list.size();++k) if(pluginMatchesSlot(list[k],i==Engine::instrumentSlot))menu.addItem(k+100,list[k].name+" ["+list[k].pluginFormatName+"]");
        menu.showMenuAsync(PopupMenu::Options().withTargetComponent(&rows[(size_t)i].add).withMaximumNumColumns(3),[safe=SafePointer<MainPanel>(this),i,list,transferTarget](int r){if(!safe)return;if(r==1){safe->showPlugins();return;}if(r==2 && transferTarget>=0){safe->closeEditors();safe->engine.transfer(i,transferTarget);safe->status="Insert moved with its settings. On FX RETURN, set reverb Mix to 100% wet.";safe->refresh();return;}if(r>=100){safe->editors[(size_t)i].reset();auto e=safe->engine.load(i,list[r-100]);if(e.isNotEmpty())safe->error(e);else safe->status="Loaded "+list[r-100].name+(i>=6?" on FX RETURN. Set the plug-in Mix to 100% wet.":"");safe->refresh();}});
    }
    void edit(int i)
    {
        auto& w=editors[(size_t)i];if(w){w->setVisible(true);w->toFront(true);return;}
        auto* p=engine.slots[(size_t)i].plugin.get();if(!p)return;
        auto* e=p->createEditorIfNeeded();if(!e)e=new GenericAudioProcessorEditor(*p);
        w=std::make_unique<PanelWindow>("VL / "+p->getName(),e);
    }
    void filePreset(bool writing)
    {
        chooser=std::make_unique<FileChooser>(writing?"Save VL chain":"Load VL chain",engine.dataFolder(),"*.vlmic");
        chooser->launchAsync(FileBrowserComponent::canSelectFiles|(writing?FileBrowserComponent::saveMode|FileBrowserComponent::warnAboutOverwriting:FileBrowserComponent::openMode),[safe=SafePointer<MainPanel>(this),writing](const FileChooser& fc){if(!safe)return;auto f=fc.getResult();if(f==File{})return;if(writing){f=f.withFileExtension("vlmic");if(!safe->engine.preset()->writeTo(f))safe->error("Could not save preset");else safe->status="Saved "+f.getFileName();}else{auto x=XmlDocument::parse(f);if(!x){safe->error("Invalid preset file");return;}safe->closeEditors();auto e=safe->engine.restore(*x);safe->sessionEdited=e.isEmpty();if(e.isNotEmpty())safe->error(e);else safe->status="Loaded "+f.getFileName()+". Press START AUDIO when ready.";safe->refresh();}});
    }
    void timerCallback() override
    {
        inLevel=jmax(engine.inputPeak.exchange(0),inLevel*0.88f);outLevel=jmax(engine.outputPeak.exchange(0),outLevel*0.88f);
        extraLevel=jmax(engine.extraPeak.exchange(0),extraLevel*0.88f);
        dryLevel=jmax(engine.dryPeak.exchange(0),dryLevel*0.88f);fxLevel=jmax(engine.fxPeak.exchange(0),fxLevel*0.88f);
        monitorMute.setToggleState(engine.monitorMuted,dontSendNotification);
        monitorMute.setButtonText(engine.monitorMuted?"MONITORING MUTED":"MUTE MONITORING");
        power.setButtonText(engine.live?"STOP AUDIO":"START AUDIO");
        power.setEnabled(engine.devices.getCurrentAudioDevice()!=nullptr);power.setToggleState(engine.live,dontSendNotification);
        if(auto* d=engine.devices.getCurrentAudioDevice())
        {
            auto ins=d->getInputChannelNames(),outs=d->getOutputChannelNames();auto activeIn=d->getActiveInputChannels(),activeOut=d->getActiveOutputChannels();
            String signature=d->getName()+ins.joinIntoString("|")+outs.joinIntoString("|")+activeIn.toString(2)+activeOut.toString(2);
            if(signature!=channelSignature)
            {
                channelSignature=signature;engine.live=false;mic.clear(dontSendNotification);extraInput.clear(dontSendNotification);output.clear(dontSendNotification);
                stream.clear(dontSendNotification);stream.addItem("Stream off",1);engine.streamChannel=-1;stream.setSelectedId(1,dontSendNotification);
                int packed=0;for(int k=0;k<ins.size();++k)if(activeIn[k]){++packed;mic.addItem(ins[k],packed);extraInput.addItem(ins[k],packed);}
                packed=0;for(int k=0;k<outs.size();++k)if(activeOut[k]){output.addItem(outs[k]+" (L / mono)",++packed);}
                for(int k=0;k+1<output.getNumItems();k+=2)stream.addItem(output.getItemText(k)+" + R",k+2);
                mic.setSelectedId(1);extraInput.setSelectedId(engine.extraChannel.load()+1);if(extraInput.getSelectedId()==0)engine.extraChannel=-1;output.setSelectedId(1);
            }
            int latency=0;for(auto& s:engine.slots)if(s.plugin&&!s.bypass)latency+=s.plugin->getLatencySamples();
            deviceInfo=engine.devices.getCurrentAudioDeviceType()+" / "+d->getName()+"  /  "+String(d->getCurrentSampleRate()/1000,1)+" kHz  /  "+String(d->getCurrentBufferSizeSamples())+" samples  /  plug-in latency "+String(latency*1000.0/d->getCurrentSampleRate(),1)+" ms  /  CPU "+String(engine.devices.getCpuUsage()*100,1)+"%";
        }else deviceInfo="No audio device open. Choose Audio setup to connect your interface.";
        auto available=MidiInput::getAvailableDevices();String midiIds;
        for(auto& info:available)midiIds+=info.identifier+"|"+info.name;
        if(midiIds!=midiSignature || midiDevices.getNumItems()==0)
        {
            auto selected=engine.selectedMidiInput();midiSignature=midiIds;midiList=available;
            midiDevices.clear(dontSendNotification);midiDevices.addItem("No MIDI device / screen keys",1);int id=1;
            for(int i=0;i<midiList.size();++i){midiDevices.addItem(midiList[i].name,i+2);if(midiList[i].identifier==selected)id=i+2;}
            midiDevices.setSelectedId(id,dontSendNotification);if(id==1 && selected.isNotEmpty()){engine.selectMidiInput({});status="MIDI keyboard disconnected. Reconnect and select it again.";}
        }
        int selectedMidiId=1;for(int i=0;i<midiList.size();++i)if(midiList[i].identifier==engine.selectedMidiInput())selectedMidiId=i+2;
        midiDevices.setSelectedId(selectedMidiId,dontSendNotification);
        if(engine.extraSource==(int)Engine::ExtraSource::audio && engine.extraChannel<0)status="Enable the guitar input in Audio setup, then select it for Channel 2.";
        if(engine.extraSource==(int)Engine::ExtraSource::midi && !engine.slots[Engine::instrumentSlot].plugin)status="Channel 2 MIDI: load an instrument, then choose a sound inside its GUI.";
        if(engine.streamChannel>=0 && std::abs(engine.streamChannel.load()-engine.outputChannel.load())<2)status="Choose separate MONITOR and STREAM channel pairs. Overlapping STREAM route is disabled.";
        if(engine.fxLatencyOverflow)status="FX latency exceeds compensation capacity. FX return muted.";
        repaint();
    }
};

// The design and its controls share the same transform, including hit-testing.
// The wrapper occupies the client area supplied by DocumentWindow, never the title bar.
class ScaledMixer final : public Component
{
public:
    ScaledMixer() { addAndMakeVisible(panel); setSize(1280,1000); }
    void resized() override
    {
        panel.setTransform(AffineTransform());
        panel.setBounds(0,0,1280,1000);
        panel.setTransform(AffineTransform::scale(getWidth()/1280.0f,getHeight()/1000.0f));
    }
private:
    MainPanel panel;
};

class App final : public JUCEApplication
{
public:
    const String getApplicationName() override{return "VL MIC HOST";}
    const String getApplicationVersion() override{return "0.4.2";}
    void initialise(const String& args) override
    {
        auto tokens=StringArray::fromTokens(args,true);tokens.removeEmptyStrings();for(auto& t:tokens)t=t.unquoted();
        if(tokens.size()>0 && tokens[0]=="--scan-worker")
        {
#if JUCE_MAC
        Process::setDockIconVisible(false);
#endif
MessageManager::callAsync([tokens]{runScanWorker(tokens);});return;}
#if defined(VL_HOST_VALIDATION)
        MessageManager::callAsync([]{
            Engine e;auto report=e.selfTest()+e.channelTest()+validatePluginSearch();
            e.dataFolder().getChildFile("validation.txt").replaceWithText(report);
            JUCEApplication::getInstance()->setApplicationReturnValue(report.contains("FAIL")?1:0);
            JUCEApplication::getInstance()->quit();
        });return;
#endif
        if(args.contains("--smoke-test"))
        {
            Engine e;e.prepare(48000,128);e.live=true;
            AudioBuffer<float> in(1,128),out(2,128);
            for(int n=0;n<128;++n)in.setSample(0,n,0.125f);
            e.process(in.getArrayOfReadPointers(),1,out.getArrayOfWritePointers(),2,128);
            bool ok=std::abs(out.getSample(0,127)-0.125f)<0.00001f && std::abs(out.getSample(1,127)-0.125f)<0.00001f;
            e.live=false;e.process(in.getArrayOfReadPointers(),1,out.getArrayOfWritePointers(),2,128);
            ok=ok && out.getMagnitude(0,128)==0;
            auto xml=e.preset();ok=ok && e.restore(*xml).isEmpty();
            auto report=ok?"PASS: stereo pass-through, stop, preset round-trip":"FAIL: engine smoke test";
            File::getCurrentWorkingDirectory().getChildFile("smoke-test.txt").replaceWithText(report);
            setApplicationReturnValue(ok?0:1);quit();return;
        }
        if(args.contains("--monitor-test"))
        {
            Engine e;e.prepare(48000,64);e.live=true;e.streamChannel=2;
            AudioBuffer<float> in(1,128),out(4,128);in.clear();for(int j=0;j<128;++j)in.setSample(0,j,0.25f);
            auto run=[&]{e.process(in.getArrayOfReadPointers(),1,out.getArrayOfWritePointers(),4,128);};
            run();bool ok=out.getSample(0,127)==0.25f && out.getSample(2,127)==0.25f;
            e.monitorMuted=true;run();ok=ok && out.getSample(0,127)==0 && out.getSample(1,127)==0 && out.getSample(2,127)==0.25f && out.getSample(3,127)==0.25f;
            e.monitorMuted=false;run();ok=ok && out.getSample(0,127)==0.25f;
            e.live=false;run();ok=ok && out.getMagnitude(0,128)==0;
            e.live=true;e.streamChannel=0;e.monitorMuted=true;run();ok=ok && out.getSample(0,127)==0;
            std::cout<<(ok?"PASS":"FAIL")<<": monitor mute/unmute, uninterrupted stereo stream, stop, overlapping route protection"<<std::endl;
            File::getCurrentWorkingDirectory().getChildFile("monitor-validation.txt").replaceWithText(ok?"PASS: mute/unmute, independent stereo stream, stop and overlapping route protection":"FAIL");
            setApplicationReturnValue(ok?0:1);quit();return;
        }
        if(args.contains("--channel-test"))
        {
            Engine e;auto report=e.channelTest();File::getCurrentWorkingDirectory().getChildFile("channel-test.txt").replaceWithText(report);std::cout<<report<<std::endl;setApplicationReturnValue(report.contains("FAIL")?1:0);quit();return;
        }
        if(args.contains("--driver-test"))
        {
            Engine e;StringArray types;
            for(auto* type:e.devices.getAvailableDeviceTypes())types.add(type->getTypeName());
            bool ok=true;
#if JUCE_WINDOWS
            ok=types.contains("ASIO") && types.contains("Windows Audio") && types.contains("DirectSound");
#endif
            String report=(ok?"PASS: ":"FAIL: ")+String("compiled audio backends: ")+types.joinIntoString(", ");
            File::getCurrentWorkingDirectory().getChildFile("driver-test.txt").replaceWithText(report);
            setApplicationReturnValue(ok?0:1);quit();return;
        }
        if(args.contains("--plugin-search-test"))
        {
            auto report=validatePluginSearch();bool ok=!report.contains("FAIL");
            File::getCurrentWorkingDirectory().getChildFile("plugin-search-test.txt").replaceWithText(report);
            setApplicationReturnValue(ok?0:1);quit();return;
        }
        if(args.contains("--self-test"))
        {
            Engine e;auto report=e.selfTest();auto f=File::getCurrentWorkingDirectory().getChildFile("self-test.txt");f.replaceWithText(report);std::cout<<report<<std::endl;setApplicationReturnValue(report.contains("FAIL")?1:0);quit();return;
        }
        main=std::make_unique<Window>();
    }
    void shutdown() override{main.reset();}
    void systemRequestedQuit() override{quit();}
private:
    struct Window:DocumentWindow
    {
        Window():DocumentWindow("VL MIC HOST",Colour(0xff121a26),allButtons)
        {
            // A JUCE title bar keeps Windows non-client/DPI metrics out of the mixer.
            #if JUCE_WINDOWS
            setUsingNativeTitleBar(false);
#else
            setUsingNativeTitleBar(true);
#endif
            setTitleBarHeight(32);
            setContentOwned(new ScaledMixer(),true);
            setResizable(true,false);
            setResizeLimits(640,540,7680,4320);
            auto area=Desktop::getInstance().getDisplays().getPrimaryDisplay()->userArea;
            centreWithSize(jmin(1280,area.getWidth()-40),jmin(1034,area.getHeight()-40));
            setVisible(true);
        }
        void closeButtonPressed() override{JUCEApplication::getInstance()->systemRequestedQuit();}
    };
    std::unique_ptr<Window> main;
};
START_JUCE_APPLICATION(App)
