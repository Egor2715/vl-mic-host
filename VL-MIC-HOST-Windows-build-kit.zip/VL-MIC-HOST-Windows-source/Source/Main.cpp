// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 VL MIC HOST contributors

#include "Engine.h"
#include "Scanner.h"
using namespace juce;

class PanelWindow : public DocumentWindow
{
public:
    PanelWindow(String title, Component* body) : DocumentWindow(title,Colour(0xff181d1b),closeButton)
    { setUsingNativeTitleBar(true); setContentOwned(body,true); setResizable(true,false); centreWithSize(body->getWidth(),body->getHeight()); setVisible(true); }
    void closeButtonPressed() override { setVisible(false); }
};

class LibraryPanel final : public Component
{
public:
    explicit LibraryPanel(Engine& e):engine(e),list(e.formats,e.known,e.dataFolder().getChildFile("scan-in-progress.txt"),nullptr,true)
    {
        addAndMakeVisible(priority);addAndMakeVisible(list);
        priority.setButtonText("Scan Waves + UAD + FabFilter + Valhalla (VST3)");
        priority.onClick=[this]{
            if(list.isScanning())return;
            engine.live=false;
            for(auto* f:engine.formats.getFormats())if(f->getName()=="VST3")
            {
                StringArray selected;
                for(auto& id:f->searchPathsForPlugins(f->getDefaultLocationsToSearch(),true,false))
                    if(id.containsIgnoreCase("WaveShell")||id.containsIgnoreCase("uaudio")||id.containsIgnoreCase("FabFilter")||id.containsIgnoreCase("Valhalla"))selected.addIfNotAlreadyThere(id);
                list.scanFor(*f,selected);break;
            }
        };
        list.setNumberOfThreadsForScanning(1);
        list.setScanDialogText("VL / Isolated plug-in scan","Each plug-in is checked in a separate process. Failed plug-ins are skipped.");
        setSize(900,520);
    }
    void resized()override{priority.setBounds(12,10,getWidth()-24,32);list.setBounds(0,52,getWidth(),getHeight()-52);}
private:
    Engine& engine;TextButton priority;PluginListComponent list;
};

namespace Night
{
    const Colour mint{0xff8fe3ce}, lavender{0xffb7a0ed}, white{0xffdce5f0};
    const Colour muted{0xff8291a5}, border{0xff26303e};
}
class MixerLook final : public LookAndFeel_V4
{
public:
    void drawButtonBackground(Graphics& g,Button& b,const Colour&,bool over,bool down) override
    {
        auto r=b.getLocalBounds().toFloat().reduced(0.5f);
        auto accent=b.findColour(TextButton::buttonOnColourId);
        auto c=b.getToggleState()?accent.withAlpha(0.24f):Colour(0xff171f2b);
        if(over)c=c.brighter(0.13f);if(down)c=c.darker(0.2f);
        g.setGradientFill(ColourGradient(c.brighter(0.06f),0,0,c,0,r.getBottom(),false));
        g.fillRoundedRectangle(r,7);
        g.setColour((b.getToggleState()?accent:Night::border).withAlpha(b.isEnabled()?0.9f:0.3f));
        g.drawRoundedRectangle(r,7,1);
    }
    void drawRotarySlider(Graphics& g,int x,int y,int w,int h,float value,float start,float end,Slider& slider) override
    {
        auto r=Rectangle<float>((float)x,(float)y,(float)w,(float)h).reduced(9);
        float radius=jmin(r.getWidth(),r.getHeight())*0.5f, cx=r.getCentreX(),cy=r.getCentreY();
        auto accent=slider.findColour(Slider::rotarySliderFillColourId);
        Path track,fill;track.addCentredArc(cx,cy,radius,radius,0,start,end,true);
        fill.addCentredArc(cx,cy,radius,radius,0,start,start+value*(end-start),true);
        g.setColour(Night::border);g.strokePath(track,PathStrokeType(3));
        g.setColour(accent.withAlpha(0.08f));g.strokePath(fill,PathStrokeType(11));
        g.setColour(accent);g.strokePath(fill,PathStrokeType(3));
        g.setGradientFill(ColourGradient(Colour(0xff293342),cx,cy-radius,Colour(0xff0d121a),cx,cy+radius,false));
        g.fillEllipse(cx-radius+7,cy-radius+7,2*radius-14,2*radius-14);
        g.setColour(Night::border);g.drawEllipse(cx-radius+7,cy-radius+7,2*radius-14,2*radius-14,1);
        float angle=start+value*(end-start)-MathConstants<float>::halfPi;
        g.setColour(accent);g.drawLine(cx+std::cos(angle)*(radius-17),cy+std::sin(angle)*(radius-17),cx+std::cos(angle)*(radius-9),cy+std::sin(angle)*(radius-9),2);
    }
    void drawLinearSlider(Graphics& g,int x,int y,int w,int h,float pos,float min,float max,Slider::SliderStyle style,Slider& slider) override
    {
        if(style!=Slider::LinearVertical){LookAndFeel_V4::drawLinearSlider(g,x,y,w,h,pos,min,max,style,slider);return;}
        float centre=x+w*0.5f;auto accent=slider.findColour(Slider::thumbColourId);
        g.setColour(Colour(0xff080c12));g.fillRoundedRectangle(centre-5,(float)y,10,(float)h,5);
        g.setColour(Night::border);for(int j=0;j<=10;++j){float ty=y+h*j/10.0f;g.drawHorizontalLine((int)ty,centre-23,centre-12);g.drawHorizontalLine((int)ty,centre+12,centre+23);}
        g.setColour(accent.withAlpha(0.25f));g.fillRoundedRectangle(centre-1,pos,2,jmax(0.0f,y+h-pos),1);
        auto cap=Rectangle<float>(centre-17,pos-15,34,30);
        g.setColour(Colours::black.withAlpha(0.5f));g.fillRoundedRectangle(cap.translated(0,3).expanded(2),5);
        g.setGradientFill(ColourGradient(accent.brighter(0.15f),centre,pos-15,accent.darker(0.55f),centre,pos+15,false));g.fillRoundedRectangle(cap,4);
        g.setColour(accent.withAlpha(0.9f));g.drawRoundedRectangle(cap.reduced(0.5f),4,1);
        g.setColour(Colour(0xff141c26));g.fillRect(centre-15,pos-2,30.0f,4.0f);
        g.setColour(accent.brighter());g.drawHorizontalLine((int)pos,centre-14,centre+14);
    }
};

class MainPanel final : public Component, private Timer
{
public:
    MainPanel()
    {
        look.setColour(ResizableWindow::backgroundColourId,Colour(0xff0c1119));
        look.setColour(TextButton::textColourOffId,Night::white);
        look.setColour(TextButton::textColourOnId,Night::white);
        look.setColour(TextButton::buttonOnColourId,Night::mint);
        look.setColour(Slider::trackColourId,Night::mint);
        look.setColour(Slider::thumbColourId,Night::white);
        look.setColour(Slider::rotarySliderFillColourId,Night::mint);
        look.setColour(Slider::textBoxTextColourId,Night::white);
        look.setColour(Slider::textBoxOutlineColourId,Colours::transparentBlack);
        look.setColour(ComboBox::backgroundColourId,Colour(0xff141c27));
        look.setColour(ComboBox::outlineColourId,Night::border);
        look.setColour(ComboBox::textColourId,Night::white);
        look.setColour(PopupMenu::backgroundColourId,Colour(0xff141c27));
        look.setColour(PopupMenu::highlightedBackgroundColourId,Colour(0xff30443f));
        setLookAndFeel(&look);
        button(audio,"Audio setup",[this]{ showAudio(); });
        button(plugins,"Plug-ins / Scan",[this]{ showPlugins(); });
        button(save,"Save preset",[this]{ filePreset(true); });
        button(load,"Load preset",[this]{ filePreset(false); });
        button(diagnostics,"Diagnostics",[this]{
            if(engine.live){error("Stop audio before running diagnostics.");return;}
            Engine test;auto report=test.selfTest();
            for(auto& d:test.known.getTypes())engine.known.addType(d);
            auto f=engine.dataFolder().getChildFile("validation.txt");f.replaceWithText(report);
            auto* text=new TextEditor();text->setMultiLine(true);text->setReadOnly(true);text->setText(report);text->setSize(850,600);
            diagnosticWindow=std::make_unique<PanelWindow>("VL / Validation report",text);
            status=report.contains("FAIL")?"Diagnostics: a check failed. See validation report.":"Diagnostics completed. See report for optional plugin checks.";
        });
        button(power,"START AUDIO",[this]{ engine.live=!engine.live.load(); });
        mode.addItem("Stereo out",1); mode.addItem("Mono out",2); mode.setSelectedId(1);
        mode.onChange=[this]{ engine.mono=mode.getSelectedId()==2; }; addAndMakeVisible(mode);
        mic.onChange=[this]{ if(mic.getSelectedId()>0) engine.micChannel=mic.getSelectedId()-1; }; addAndMakeVisible(mic);
        output.onChange=[this]{ if(output.getSelectedId()>0) engine.outputChannel=output.getSelectedId()-1; }; addAndMakeVisible(output);
        gain(inGain,-60,24,[this]{engine.inputGain=Decibels::decibelsToGain((float)inGain.getValue());});
        gain(outGain,-60,12,[this]{engine.outputGain=Decibels::decibelsToGain((float)outGain.getValue());});
        for(int i=0;i<Engine::slotCount;++i)
        {
            auto& row=rows[(size_t)i];row.bypass.setTooltip("Bypass insert");row.up.setTooltip("Move insert up");row.down.setTooltip("Move insert down");row.remove.setTooltip("Remove insert");
            button(row.add,"+ Add effect",[this,i]{ choose(i); });
            button(row.edit,"GUI",[this,i]{ edit(i); });
            row.bypass.setClickingTogglesState(true);
            button(row.bypass,"B",[this,i]{engine.bypass(i,rows[(size_t)i].bypass.getToggleState());});
            button(row.up,"^",[this,i]{closeEditors();engine.move(i,i-1);refresh();});
            button(row.down,"v",[this,i]{closeEditors();engine.move(i,i+1);refresh();});
            button(row.remove,"X",[this,i]{editors[(size_t)i].reset();engine.remove(i);refresh();});
        }
        gain(dryFader,-60,12,[this]{engine.dryGain=Decibels::decibelsToGain((float)dryFader.getValue(),-60.0f);});
        gain(sendLevel,-60,0,[this]{engine.sendGain=Decibels::decibelsToGain((float)sendLevel.getValue(),-60.0f);});
        gain(returnFader,-60,12,[this]{engine.returnGain=Decibels::decibelsToGain((float)returnFader.getValue(),-60.0f);});
        for(auto* f:{&dryFader,&returnFader,&outGain}){f->setSliderStyle(Slider::LinearVertical);f->setTextBoxStyle(Slider::TextBoxBelow,false,90,24);}
        for(auto* b:{&dryMute,&fxMute,&fxSolo})b->setClickingTogglesState(true);
        button(dryMute,"MUTE MIC",[this]{engine.dryMute=dryMute.getToggleState();});
        button(fxMute,"MUTE FX",[this]{engine.fxMute=fxMute.getToggleState();});
        button(fxSolo,"SOLO FX",[this]{engine.fxSolo=fxSolo.getToggleState();});
        button(lastSession,"Last session",[this]{
            auto x=XmlDocument::parse(engine.dataFolder().getChildFile("last-chain.vlmic"));
            if(!x){error("No saved session yet.");return;}closeEditors();auto e=engine.restore(*x);if(e.isNotEmpty())error(e);else status="Last session restored. Output stopped.";refresh();
        });
        status="Choose your interface. Put reverb on FX RETURN and set its Mix to 100% wet.";
        dryFader.setColour(Slider::thumbColourId,Night::mint);
        returnFader.setColour(Slider::thumbColourId,Night::lavender);
        for(auto* knob:{&inGain,&sendLevel}){knob->setSliderStyle(Slider::RotaryHorizontalVerticalDrag);knob->setTextBoxStyle(Slider::TextBoxBelow,false,90,22);}
        sendLevel.setColour(Slider::rotarySliderFillColourId,Night::lavender);
        fxMute.setColour(TextButton::buttonOnColourId,Night::lavender);fxSolo.setColour(TextButton::buttonOnColourId,Night::lavender);
        inGain.setName("Input trim");dryFader.setName("Microphone level");sendLevel.setName("Send to FX");returnFader.setName("FX return level");outGain.setName("Master level");
        setSize(1060,800); refresh(); startTimerHz(24);
    }
    ~MainPanel() override
    {
        stopTimer(); closeEditors(); pluginWindow.reset(); audioWindow.reset(); diagnosticWindow.reset();
        engine.live=false;
        if(auto x=engine.devices.createStateXml()) x->writeTo(engine.dataFolder().getChildFile("device.xml"));
        engine.preset()->writeTo(engine.dataFolder().getChildFile("last-chain.vlmic"));
        setLookAndFeel(nullptr);
    }
    void paint(Graphics& g) override
    {
        g.setGradientFill(ColourGradient(Colour(0xff121a26),0,0,Colour(0xff080c12),1060,800,false));g.fillAll();
        g.setColour(Night::mint);g.setFont(FontOptions(29.0f,Font::bold));g.drawText("VL",24,16,48,36,Justification::centredLeft);
        g.setColour(Night::white);g.setFont(FontOptions(16.0f,Font::bold));g.drawText("MIC HOST",82,16,140,24,Justification::centredLeft);
        g.setColour(Night::muted);g.setFont(10.0f);g.drawText("N I G H T   /   0.3.0",83,41,165,16,Justification::centredLeft);
        panel(g,{24,82,612,318});panel(g,{652,82,384,318});
        label(g,"PLUG-INS",42,96);g.setColour(Night::muted);g.setFont(10.0f);g.drawText("6 SERIAL INSERTS",460,97,156,18,Justification::centredRight);
        label(g,"REVERB / PARALLEL",672,96);
        for(int i=0;i<6;++i){g.setFont(12.0f);g.setColour(Night::muted);g.drawText(String(i+1).paddedLeft('0',2),42,134+i*42,25,30,Justification::centredLeft);}
        label(g,"SEND",695,226);label(g,"FX RETURN",850,226);
        g.setColour(Night::lavender);g.setFont(15.0f);g.drawText("100% WET",850,261,160,24,Justification::centredLeft);
        g.setColour(Night::muted);g.setFont(12.0f);g.drawFittedText("Set Mix inside your reverb.\nBlend with the return fader.",850,295,160,44,Justification::topLeft,3);
        meter(g,{672,378,344,3},fxLevel,Night::lavender);
        channel(g,24,"MIC",Night::mint);channel(g,368,"FX RETURN",Night::lavender);channel(g,712,"MASTER",Night::white);
        label(g,"TRIM",48,472);
        verticalMeter(g,{272,476,12,154},dryLevel,Night::mint);verticalMeter(g,{616,476,12,154},fxLevel,Night::lavender);verticalMeter(g,{960,476,12,154},outLevel,Night::white);
        for(int x:{291,635,979}){g.setColour(Night::muted);g.setFont(10.0f);for(int j=0;j<6;++j)g.drawText(String(-j*12),x,470+j*30,32,16,Justification::centredLeft);}
        g.setColour(Night::muted);g.setFont(11.0f);g.drawText(levelText(dryLevel),220,649,108,20,Justification::centredRight);g.drawText(levelText(fxLevel),564,649,108,20,Justification::centredRight);g.drawText(levelText(outLevel),908,649,108,20,Justification::centredRight);
        g.setColour(Night::border);g.drawHorizontalLine(699,24,1036);
        label(g,"INPUT",24,708);label(g,"OUTPUT",276,708);
        g.setColour(Night::muted);g.setFont(11.0f);g.drawText(deviceInfo,24,762,800,16,Justification::centredLeft);
        g.setFont(10.0f);g.drawText(status,24,780,1012,16,Justification::centredLeft);
    }
    void resized() override
    {
        audio.setBounds(278,22,104,30);plugins.setBounds(390,22,118,30);save.setBounds(516,22,96,30);load.setBounds(620,22,96,30);lastSession.setBounds(724,22,106,30);diagnostics.setBounds(838,22,96,30);
        power.setBounds(858,720,178,36);
        mic.setBounds(24,731,236,27);output.setBounds(276,731,236,27);mode.setBounds(528,731,150,27);
        inGain.setBounds(42,498,100,120);dryFader.setBounds(167,470,88,190);
        sendLevel.setBounds(684,245,126,124);returnFader.setBounds(475,470,88,190);outGain.setBounds(819,470,88,190);
        dryMute.setBounds(48,661,108,26);fxMute.setBounds(392,661,100,26);fxSolo.setBounds(504,661,100,26);
        for(int i=0;i<Engine::slotCount;++i)
        {
            auto& r=rows[(size_t)i];bool main=i<6;int x=main?75:672,y=main?132+i*42:132+(i-6)*42;
            int nameWidth=main?326:142;
            r.add.setBounds(x,y,nameWidth,32);int bx=x+nameWidth+5;
            r.edit.setBounds(bx,y,42,32);r.bypass.setBounds(bx+47,y,30,32);r.up.setBounds(bx+82,y,28,32);r.down.setBounds(bx+115,y,28,32);r.remove.setBounds(bx+148,y,30,32);
        }
    }
    Engine engine;
    void openEditorForTest(int i) {edit(i);}
private:
    struct Row {TextButton add,edit,bypass,up,down,remove;};
    MixerLook look;
    std::array<Row,Engine::slotCount> rows;
    std::array<std::unique_ptr<PanelWindow>,Engine::slotCount> editors;
    std::unique_ptr<PanelWindow> pluginWindow,audioWindow,diagnosticWindow;
    std::unique_ptr<FileChooser> chooser;
    TextButton audio,plugins,save,load,power,diagnostics,lastSession,dryMute,fxMute,fxSolo;
    ComboBox mic,output,mode;
    Slider inGain,outGain,dryFader,sendLevel,returnFader;
    String status,deviceInfo,channelSignature;
    float inLevel=0,outLevel=0,dryLevel=0,fxLevel=0;
    bool started=false;
    void button(TextButton& b,const String& text,std::function<void()> f) {b.setButtonText(text);b.onClick=std::move(f);addAndMakeVisible(b);}
    void gain(Slider& s,double min,double max,std::function<void()> f) {s.setRange(min,max,0.1);s.setValue(0);s.setTextValueSuffix(" dB");s.setSliderStyle(Slider::LinearHorizontal);s.setTextBoxStyle(Slider::TextBoxRight,false,76,26);s.onValueChange=std::move(f);addAndMakeVisible(s);}
    void panel(Graphics& g,Rectangle<int> bounds)
    {
        auto r=bounds.toFloat();
        g.setColour(Colours::black.withAlpha(0.25f));g.fillRoundedRectangle(r.translated(0,3),12);
        g.setGradientFill(ColourGradient(Colour(0xff121a25),r.getX(),r.getY(),Colour(0xff0b1018),r.getX(),r.getBottom(),false));g.fillRoundedRectangle(r,12);
        g.setColour(Night::border);g.drawRoundedRectangle(r.reduced(0.5f),12,1);
    }
    void channel(Graphics& g,int x,String title,Colour accent)
    {
        panel(g,{x,416,324,278});
        g.setColour(accent);g.fillRoundedRectangle((float)x+24,440,4,17,2);
        g.setFont(FontOptions(14.0f,Font::bold));g.drawText(title,x+39,435,230,27,Justification::centredLeft);
    }
    void verticalMeter(Graphics& g,Rectangle<int> r,float v,Colour accent)
    {
        g.setColour(Colour(0xff060a0f));g.fillRoundedRectangle(r.toFloat().expanded(3),4);
        auto fill=r.toFloat();float h=fill.getHeight()*jlimit(0.0f,1.0f,(Decibels::gainToDecibels(v,-60.0f)+60)/60);fill.setY(fill.getBottom()-h);fill.setHeight(h);
        auto c=v>=1?Colour(0xffff876e):accent;
        g.setColour(c.withAlpha(0.08f));g.fillRoundedRectangle(fill.expanded(4),4);
        g.setGradientFill(ColourGradient(c,fill.getX(),fill.getY(),c.darker(0.35f),fill.getX(),fill.getBottom(),false));g.fillRoundedRectangle(fill,2);
        g.setColour(Colour(0xff0c121b));g.fillRect(r.getX()+5,r.getY(),2,r.getHeight());
    }
    void label(Graphics& g,String text,int x,int y) {g.setFont(FontOptions(11.0f,Font::bold));g.setColour(Night::muted);g.drawText(text,x,y,260,20,Justification::centredLeft);}
    String levelText(float v) {return String(Decibels::gainToDecibels(v,-90.0f),1)+" dBFS"+(v>=1?"  CLIP":"");}
    void meter(Graphics& g,Rectangle<int> r,float value,Colour accent) {g.setColour(Night::border);g.fillRoundedRectangle(r.toFloat(),2);g.setColour(value>=1?Colour(0xffff866d):accent);g.fillRoundedRectangle(r.toFloat().withWidth(r.getWidth()*jlimit(0.0f,1.0f,(Decibels::gainToDecibels(value,-60.0f)+60)/60)),2);}
    void error(String e) {status=e;AlertWindow::showMessageBoxAsync(MessageBoxIconType::WarningIcon,"VL MIC HOST",e);}
    void closeEditors() {for(auto& e:editors)e.reset();}
    void refresh()
    {
        for(int i=0;i<Engine::slotCount;++i) {auto& r=rows[(size_t)i];auto& s=engine.slots[(size_t)i];bool has=s.plugin!=nullptr;r.add.setButtonText(has?s.description.name:"+ Add effect");r.edit.setEnabled(has);r.bypass.setEnabled(has);r.remove.setEnabled(has);r.bypass.setToggleState(s.bypass,dontSendNotification);r.up.setEnabled(i!=0 && i!=6);r.down.setEnabled(i!=5 && i!=7);}
        dryFader.setValue(Decibels::gainToDecibels(engine.dryGain.load(),-60.0f),dontSendNotification);sendLevel.setValue(Decibels::gainToDecibels(engine.sendGain.load(),-60.0f),dontSendNotification);returnFader.setValue(Decibels::gainToDecibels(engine.returnGain.load(),-60.0f),dontSendNotification);
        dryMute.setToggleState(engine.dryMute,dontSendNotification);fxMute.setToggleState(engine.fxMute,dontSendNotification);fxSolo.setToggleState(engine.fxSolo,dontSendNotification);
        inGain.setValue(Decibels::gainToDecibels(engine.inputGain.load(),-60.0f),dontSendNotification);outGain.setValue(Decibels::gainToDecibels(engine.outputGain.load(),-60.0f),dontSendNotification);mode.setSelectedId(engine.mono?2:1,dontSendNotification);
    }
    void showAudio()
    {
        if(!started)
        {
            auto e=engine.start();started=e.isEmpty();if(e.isNotEmpty())error(e);
        }
        if(!audioWindow) {auto* c=new AudioDeviceSelectorComponent(engine.devices,0,32,0,32,false,false,false,false);c->setSize(580,520);audioWindow=std::make_unique<PanelWindow>("VL / Audio setup",c);}
        audioWindow->setVisible(true);audioWindow->toFront(true);
    }
    void showPlugins()
    {
        if(!pluginWindow) {pluginWindow=std::make_unique<PanelWindow>("VL / Plug-in library",new LibraryPanel(engine));}
        pluginWindow->setVisible(true);pluginWindow->toFront(true);
    }
    void choose(int i)
    {
        auto list=engine.known.getTypes();
        std::sort(list.begin(),list.end(),[](const auto& a,const auto& b){return (a.name+a.pluginFormatName).compareIgnoreCase(b.name+b.pluginFormatName)<0;});
        PopupMenu menu;menu.addItem(1,"Scan / manage plug-ins...");menu.addSeparator();
        int transferTarget=-1;
        if(engine.slots[i].plugin)
        {
            for(int j=(i<6?6:0);j<(i<6?8:6);++j)if(!engine.slots[j].plugin){transferTarget=j;break;}
            if(transferTarget>=0)menu.addItem(2,i<6?"Move this insert to FX RETURN":"Move this insert to MICROPHONE");
            menu.addSeparator();
        }
        for(int k=0;k<list.size();++k) if(!list[k].isInstrument && list[k].numInputChannels>0)menu.addItem(k+100,list[k].name+" ["+list[k].pluginFormatName+"]");
        menu.showMenuAsync(PopupMenu::Options().withTargetComponent(&rows[(size_t)i].add).withMaximumNumColumns(3),[safe=SafePointer<MainPanel>(this),i,list,transferTarget](int r){if(!safe)return;if(r==1){safe->showPlugins();return;}if(r==2 && transferTarget>=0){safe->closeEditors();safe->engine.transfer(i,transferTarget);safe->status="Insert moved with its settings. On FX RETURN, set reverb Mix to 100% wet.";safe->refresh();return;}if(r>=100){safe->editors[(size_t)i].reset();auto e=safe->engine.load(i,list[r-100]);if(e.isNotEmpty())safe->error(e);else safe->status="Loaded "+list[r-100].name+(i>=6?" on FX RETURN. Set the plug-in Mix to 100% wet.":"");safe->refresh();}});
    }
    void edit(int i)
    {
        auto& w=editors[(size_t)i];if(w){w->setVisible(true);w->toFront(true);return;}
        auto* p=engine.slots[(size_t)i].plugin.get();if(!p)return;
        auto* e=p->createEditorIfNeeded();if(!e)e=new GenericAudioProcessorEditor(*p);
        w=std::make_unique<PanelWindow>("VL / "+p->getName(),e);
    }
    void filePreset(bool writing)
    {
        chooser=std::make_unique<FileChooser>(writing?"Save VL chain":"Load VL chain",engine.dataFolder(),"*.vlmic");
        chooser->launchAsync(FileBrowserComponent::canSelectFiles|(writing?FileBrowserComponent::saveMode|FileBrowserComponent::warnAboutOverwriting:FileBrowserComponent::openMode),[safe=SafePointer<MainPanel>(this),writing](const FileChooser& fc){if(!safe)return;auto f=fc.getResult();if(f==File{})return;if(writing){f=f.withFileExtension("vlmic");if(!safe->engine.preset()->writeTo(f))safe->error("Could not save preset");else safe->status="Saved "+f.getFileName();}else{auto x=XmlDocument::parse(f);if(!x){safe->error("Invalid preset file");return;}safe->closeEditors();auto e=safe->engine.restore(*x);if(e.isNotEmpty())safe->error(e);else safe->status="Loaded "+f.getFileName()+". Press START AUDIO when ready.";safe->refresh();}});
    }
    void timerCallback() override
    {
        inLevel=jmax(engine.inputPeak.exchange(0),inLevel*0.88f);outLevel=jmax(engine.outputPeak.exchange(0),outLevel*0.88f);
        dryLevel=jmax(engine.dryPeak.exchange(0),dryLevel*0.88f);fxLevel=jmax(engine.fxPeak.exchange(0),fxLevel*0.88f);
        power.setButtonText(engine.live?"STOP AUDIO":"START AUDIO");
        power.setEnabled(engine.devices.getCurrentAudioDevice()!=nullptr);power.setToggleState(engine.live,dontSendNotification);
        if(auto* d=engine.devices.getCurrentAudioDevice())
        {
            auto ins=d->getInputChannelNames(),outs=d->getOutputChannelNames();auto activeIn=d->getActiveInputChannels(),activeOut=d->getActiveOutputChannels();
            String signature=d->getName()+ins.joinIntoString("|")+outs.joinIntoString("|")+activeIn.toString(2)+activeOut.toString(2);
            if(signature!=channelSignature)
            {
                channelSignature=signature;engine.live=false;mic.clear(dontSendNotification);output.clear(dontSendNotification);
                int packed=0;for(int k=0;k<ins.size();++k)if(activeIn[k])mic.addItem(ins[k],++packed);
                packed=0;for(int k=0;k<outs.size();++k)if(activeOut[k]){output.addItem(outs[k]+" (L / mono)",++packed);}
                mic.setSelectedId(1);output.setSelectedId(1);
            }
            int latency=0;for(auto& s:engine.slots)if(s.plugin&&!s.bypass)latency+=s.plugin->getLatencySamples();
            deviceInfo=d->getName()+"  /  "+String(d->getCurrentSampleRate()/1000,1)+" kHz  /  "+String(d->getCurrentBufferSizeSamples())+" samples  /  plug-in latency "+String(latency*1000.0/d->getCurrentSampleRate(),1)+" ms  /  CPU "+String(engine.devices.getCpuUsage()*100,1)+"%";
        }else deviceInfo="No audio device open. Choose Audio setup to connect your interface.";
        if(engine.fxLatencyOverflow)status="FX latency exceeds compensation capacity. FX return muted.";
        repaint();
    }
};

class App final : public JUCEApplication
{
public:
    const String getApplicationName() override{return "VL MIC HOST";}
    const String getApplicationVersion() override{return "0.3.0";}
    void initialise(const String& args) override
    {
        auto tokens=StringArray::fromTokens(args,true);tokens.removeEmptyStrings();for(auto& t:tokens)t=t.unquoted();
        if(tokens.size()>0 && tokens[0]=="--scan-worker")
        {
#if JUCE_MAC
        Process::setDockIconVisible(false);
#endif
MessageManager::callAsync([tokens]{runScanWorker(tokens);});return;}
        if(args.contains("--smoke-test"))
        {
            Engine e;e.prepare(48000,128);e.live=true;
            AudioBuffer<float> in(1,128),out(2,128);
            for(int n=0;n<128;++n)in.setSample(0,n,0.125f);
            e.process(in.getArrayOfReadPointers(),1,out.getArrayOfWritePointers(),2,128);
            bool ok=std::abs(out.getSample(0,127)-0.125f)<0.00001f && std::abs(out.getSample(1,127)-0.125f)<0.00001f;
            e.live=false;e.process(in.getArrayOfReadPointers(),1,out.getArrayOfWritePointers(),2,128);
            ok=ok && out.getMagnitude(0,128)==0;
            auto xml=e.preset();ok=ok && e.restore(*xml).isEmpty();
            auto report=ok?"PASS: stereo pass-through, stop, preset round-trip":"FAIL: engine smoke test";
            File::getCurrentWorkingDirectory().getChildFile("smoke-test.txt").replaceWithText(report);
            setApplicationReturnValue(ok?0:1);quit();return;
        }
        if(args.contains("--self-test"))
        {
            Engine e;auto report=e.selfTest();auto f=File::getCurrentWorkingDirectory().getChildFile("self-test.txt");f.replaceWithText(report);std::cout<<report<<std::endl;setApplicationReturnValue(report.contains("FAIL")?1:0);quit();return;
        }
        main=std::make_unique<Window>();
    }
    void shutdown() override{main.reset();}
    void systemRequestedQuit() override{quit();}
private:
    struct Window:DocumentWindow
    {
        Window():DocumentWindow("VL MIC HOST",Colour(0xff111714),allButtons){setUsingNativeTitleBar(true);setContentOwned(new MainPanel(),true);setResizable(false,false);centreWithSize(1060,800);setVisible(true);}
        void closeButtonPressed() override{JUCEApplication::getInstance()->systemRequestedQuit();}
    };
    std::unique_ptr<Window> main;
};
START_JUCE_APPLICATION(App)
