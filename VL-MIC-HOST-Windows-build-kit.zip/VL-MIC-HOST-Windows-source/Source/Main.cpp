// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 VL MIC HOST contributors

#include "Engine.h"
#include "Scanner.h"
#include "PluginBrowser.h"
#include "PluginDiscovery.h"
#include "PluginAudit.h"
#include "FullPluginAudit.h"
using namespace juce;

#if JUCE_WINDOWS
static_assert(JUCE_ASIO == 1, "Windows releases must include ASIO support");
#endif

static String validatePluginSearch()
{
    PluginDescription effect;effect.name="Guitar Amp";effect.manufacturerName="Independent Developer";effect.pluginFormatName="VST3";effect.category="Distortion";
    PluginDescription synth;synth.name="Piano";synth.manufacturerName="Another Developer";synth.pluginFormatName="VST3";synth.isInstrument=true;
    bool ok=pluginMatchesSearch(effect,"") && pluginMatchesSearch(effect,"gUiTaR independent") && pluginMatchesSearch(effect,"distortion vst3")
        && pluginMatchesSearch(synth,"piano another") && !pluginMatchesSearch(effect,"piano");
    bool slotsOk=pluginMatchesSlot(effect,false) && !pluginMatchesSlot(effect,true)
        && pluginMatchesSlot(synth,true) && !pluginMatchesSlot(synth,false);
    effect.numInputChannels=2;effect.numOutputChannels=2;
    slotsOk=slotsOk && pluginMatchesSlot(effect,false);
    auto temp=File::getSpecialLocation(File::tempDirectory).getChildFile("VL-search-test-"+Uuid().toString());
    auto vstFolder=temp.getChildFile("custom-vst3");vstFolder.createDirectory();
    auto settings=temp.getChildFile("locations.xml");PluginLocations paths(settings);
    ok=paths.addVst3Folder(vstFolder) && ok;
    PluginLocations recalled(settings);VST3PluginFormat format;
    auto locations=recalled.forFormat(format);bool found=false;
    for(int i=0;i<locations.getNumPaths();++i)found=found||locations[i]==vstFolder;
    ok=ok && found;
    VSTPluginFormat legacyFormat;auto legacyLocations=recalled.forFormat(legacyFormat);bool legacyFound=false;
    for(int i=0;i<legacyLocations.getNumPaths();++i)legacyFound=legacyFound||legacyLocations[i]==vstFolder;
    ok=ok&&legacyFound;temp.deleteRecursively();
    String report=ok?"PASS: arbitrary manufacturers, effects and instruments, case-insensitive multi-word search, category, persistent custom VST3 folders\n":"FAIL: general plug-in search / folder recall\n";
    report+=slotsOk?"PASS: VST3 effects with unknown channel counts remain selectable; effects and instruments use their own slots\n":"FAIL: plug-in slot classification\n";
    // Exercise the actual picker with VST3 fast-scan descriptions, including
    // separate classes in one WaveShell file. No user catalog is read or changed.
    KnownPluginList library;
    PluginDescription mono;mono.name="Waves mono";mono.manufacturerName="Waves";mono.pluginFormatName="VST3";mono.fileOrIdentifier="test/WaveShell.vst3";mono.uniqueId=101;
    auto stereo=mono;stereo.name="Waves stereo";stereo.uniqueId=102;
    auto reverb=mono;reverb.name="Valhalla reverb";reverb.manufacturerName="Valhalla DSP";reverb.fileOrIdentifier="test/reverb.vst3";reverb.uniqueId=103;
    synth.fileOrIdentifier="test/piano.vst3";synth.uniqueId=104;
    for(auto d:{mono,stereo,reverb,synth})library.addType(d);
    auto cached=reverb;cached.version="1.0";cached.lastFileModTime=Time::getCurrentTime();library.addType(cached);
    forcePluginRescan(library);
    auto invalidated=library.getTypeForFile(reverb.fileOrIdentifier);
    bool rescanOk=library.getTypes().size()==4 && invalidated && invalidated->version.isEmpty() && invalidated->lastFileModTime==Time(0);
    report+=rescanOk?"PASS: full rescan invalidates cached metadata without dropping catalog classes\n":"FAIL: full rescan cache invalidation\n";
    int selectedId=0;PluginPicker picker(library,[&](PluginDescription d){selectedId=d.uniqueId;},{},{});
    TextEditor* search=nullptr;ListBox* rows=nullptr;TextButton* load=nullptr;
    for(auto* child:picker.getChildren())
    {
        if(auto* s=dynamic_cast<TextEditor*>(child))search=s;
        if(auto* r=dynamic_cast<ListBox*>(child))rows=r;
        if(auto* b=dynamic_cast<TextButton*>(child);b && b->getButtonText()=="Load selected")load=b;
    }
    bool pickerOk=search && rows && load && rows->getListBoxModel()->getNumRows()==3;
    if(pickerOk)
    {
        search->setText("waves",false);search->onTextChange();
        pickerOk=rows->getListBoxModel()->getNumRows()==2 && load->isEnabled();
        rows->selectRow(1);load->onClick();pickerOk=pickerOk && selectedId==102;
        search->setText("valhalla",false);search->onTextChange();
        load->onClick();pickerOk=pickerOk && rows->getListBoxModel()->getNumRows()==1 && selectedId==103;
    }
    report+=pickerOk?"PASS: picker searches zero-count Waves / Valhalla descriptions and dispatches the selected class to the load callback\n":"FAIL: zero-count VST3 picker selection / load callback\n";
    return report;
}

static String validateInstalledDiscovery(Engine& engine)
{
    String report;int files=0,classes=0;
    for(auto* format:engine.formats.getFormats())if(format->getName()=="VST3")
    {
        PluginLocations locations(engine.dataFolder().getChildFile("plugin-locations.xml"));
        auto candidates=format->searchPathsForPlugins(locations.forFormat(*format),true,false);candidates.removeDuplicates(false);
        for(auto identifier:candidates)if(identifier.containsIgnoreCase("Valhalla")||identifier.containsIgnoreCase("WaveShell"))
        {
            ++files;OwnedArray<PluginDescription> found;IsolatedScanner scanner(engine.dataFolder());
            bool ok=scanner.findPluginTypesFor(*format,found,identifier) && !found.isEmpty();
            for(auto* d:found){engine.known.addType(*d);ok=ok && pluginMatchesSlot(*d,d->isInstrument);}
            classes+=found.size();
            report+=(ok?"PASS ":"FAIL ")+File(identifier).getFileName()+" / "+String(found.size())+" discovered classes, all available in their slot category\n";
            engine.dataFolder().getChildFile("discovery-progress.txt").replaceWithText(report);
        }
    }
    report+=files==0?"SKIP installed Waves / Valhalla VST3: no matching modules on this machine\n":"PASS discovery inventory: "+String(files)+" modules / "+String(classes)+" classes\n";
    return report;
}

class PanelWindow : public DocumentWindow
{
public:
    PanelWindow(String title, Component* body) : DocumentWindow(title,Colour(0xff181d1b),closeButton)
    { setUsingNativeTitleBar(true); setContentOwned(body,true); setResizable(true,false); centreWithSize(body->getWidth(),body->getHeight()); setVisible(true); }
    void closeButtonPressed() override { setVisible(false); }
};

class LibraryPanel final : public Component, private Timer
{
public:
    explicit LibraryPanel(Engine& e):engine(e),list(e.formats,e.known,e.dataFolder().getChildFile("scan-in-progress.txt"),nullptr,true),locations(e.dataFolder().getChildFile("plugin-locations.xml"))
    {
        addAndMakeVisible(priority);addAndMakeVisible(folder);addAndMakeVisible(retry);addAndMakeVisible(tabs);addAndMakeVisible(summary);addAndMakeVisible(scanLog);addAndMakeVisible(checkLoad);addAndMakeVisible(checkAll);
        scanLog.setButtonText("Scan report...");scanLog.onClick=[this]{
            auto* text=new TextEditor();text->setMultiLine(true);text->setReadOnly(true);
            text->setText(engine.dataFolder().getChildFile("scan-log.txt").loadFileAsString()+"\nLOAD / GUI CHECKS\n"+engine.dataFolder().getChildFile("load-log.txt").loadFileAsString());text->setSize(850,600);
            reportWindow=std::make_unique<PanelWindow>("VL / Scan report",text);
        };
        checkAll.setButtonText("Check all VST / GUI");checkAll.onClick=[this]{
            if(list.isScanning()||pending>=0||auditing)return;engine.live=false;
            fullAuditWindow=std::make_unique<PanelWindow>("VL / Full VST2 and VST3 audit",new FullPluginAudit(engine));
        };
        checkLoad.setButtonText("Check load / GUI");checkLoad.onClick=[this]{
            if(list.isScanning()||pending>=0||auditProcess.isRunning())return;
            auto selected=catalog->selectedPlugin();if(!selected)return;
            engine.live=false;auditName=selected->name;
            auditDirectory=engine.dataFolder().getChildFile("audit-jobs").getChildFile(Uuid().toString());auditDirectory.createDirectory();
            selected->createXml()->writeTo(auditDirectory.getChildFile("request.xml"));
            auditProcess.start(StringArray{File::getSpecialLocation(File::currentExecutableFile).getFullPathName(),"--audit-worker",auditDirectory.getChildFile("request.xml").getFullPathName(),auditDirectory.getChildFile("response.xml").getFullPathName()},0);
            auditDeadline=Time::getMillisecondCounterHiRes()+30000;auditing=true;
        };
        catalog=std::make_unique<PluginPicker>(engine.known,std::function<void(PluginDescription)>{},[this]{tabs.setCurrentTabIndex(1);},std::function<void()>{},false,true);
        tabs.addTab("All plug-ins / search",Colour(0xff121a25),catalog.get(),false);
        tabs.addTab("Scan / failed plug-ins",Colour(0xff121a25),&list,false);
#if JUCE_WINDOWS
        priority.setButtonText("Scan all installed VST2 / VST3");
#else
        priority.setButtonText("Scan all installed AU / VST2 / VST3");
#endif
        priority.onClick=[this]{beginScan(true);};
        retry.setButtonText("Retry failed / rescan");retry.onClick=[this]{beginScan(true);};
        folder.setButtonText("Add plug-in folder...");
        folder.onClick=[this]{
            if(list.isScanning()||pending>=0)return;
            chooser=std::make_unique<FileChooser>("Choose an additional VST2 / VST3 folder");
            const SafePointer<LibraryPanel> safe(this);
            chooser->launchAsync(FileBrowserComponent::openMode|FileBrowserComponent::canSelectDirectories,[safe](const FileChooser& fc){
                if(!safe||!fc.getResult().isDirectory())return;
                if(!safe->locations.addVst3Folder(fc.getResult()))return;
                safe->engine.live=false;safe->tabs.setCurrentTabIndex(1);
                for(auto* f:safe->engine.formats.getFormats()){ (void)f; }
                safe->beginScan(true);
            });
        };
        list.setNumberOfThreadsForScanning(1);
        list.setScanDialogText("VL / Isolated plug-in scan","AU, VST2 and VST3 are scanned in separate processes. Use Check load / GUI to verify a selected plug-in.");
        setSize(900,620);startTimer(200);
    }
    ~LibraryPanel()override {stopTimer();if(auditProcess.isRunning()){auditProcess.kill();auditProcess.waitForProcessToFinish(2000);}if(auditDirectory!=File{})auditDirectory.deleteRecursively();tabs.clearTabs();}
    void resized()override{priority.setBounds(12,10,getWidth()-660,32);checkAll.setBounds(getWidth()-636,10,210,32);retry.setBounds(getWidth()-414,10,198,32);folder.setBounds(getWidth()-210,10,198,32);tabs.setBounds(0,52,getWidth(),getHeight()-108);summary.setBounds(12,getHeight()-52,getWidth()-414,44);checkLoad.setBounds(getWidth()-396,getHeight()-44,186,32);scanLog.setBounds(getWidth()-198,getHeight()-44,186,32);}
private:
    Engine& engine;TextButton priority,folder,retry,scanLog,checkLoad,checkAll;Label summary;PluginListComponent list;PluginLocations locations;
    std::unique_ptr<PanelWindow> reportWindow,fullAuditWindow;
    std::unique_ptr<PluginPicker> catalog;TabbedComponent tabs{TabbedButtonBar::TabsAtTop};
    std::unique_ptr<FileChooser> chooser;int pending=-1;
    ChildProcess auditProcess;File auditDirectory;String auditName;double auditDeadline=0;bool auditing=false;
    void beginScan(bool retryFailures)
    {
        if(list.isScanning()||pending>=0)return;
        engine.live=false;tabs.setCurrentTabIndex(1);
        if(retryFailures)
        {
            forcePluginRescan(engine.known);
            engine.dataFolder().getChildFile("scan-in-progress.txt").deleteFile();
        }
        pending=0;startTimer(200);
    }
    void timerCallback() override
    {
        checkAll.setEnabled(!auditing&&!list.isScanning()&&pending<0);
        checkLoad.setEnabled(!auditing&&!list.isScanning()&&pending<0);
        if(auditing)
        {
            summary.setText("Checking load / processing / GUI: "+auditName,dontSendNotification);
            if(auditProcess.isRunning()&&Time::getMillisecondCounterHiRes()<auditDeadline)return;
            const bool timeout=auditProcess.isRunning();if(timeout){auditProcess.kill();auditProcess.waitForProcessToFinish(2000);}
            String outcome=timeout?"Timed out (license dialog / slow initialization)":"Worker crashed before completing load / GUI";
            if(!timeout)if(auto result=XmlDocument::parse(auditDirectory.getChildFile("response.xml")))
                outcome=result->getBoolAttribute("loaded")&&result->getBoolAttribute("rendered")&&result->getBoolAttribute("editorCreated")&&result->getBoolAttribute("closed")?"PASS: loaded, processed audio, created and closed GUI":result->getStringAttribute("error","Load / GUI check failed");
            engine.dataFolder().getChildFile("load-log.txt").appendText(auditName+" | "+outcome+"\n");
            auditDirectory.deleteRecursively();auditDirectory=File{};auditing=false;
            auto* text=new TextEditor();text->setMultiLine(true);text->setReadOnly(true);text->setText(auditName+"\n"+outcome);text->setSize(680,240);
            reportWindow=std::make_unique<PanelWindow>("VL / Load and GUI check",text);
        }
        int au=0,vst=0,vst2=0;for(auto d:engine.known.getTypes()){if(d.pluginFormatName=="AudioUnit")++au;else if(d.pluginFormatName=="VST3")++vst;else if(d.pluginFormatName=="VST")++vst2;}
        summary.setText(String(au)+" AU / "+String(vst2)+" VST2 / "+String(vst)+" VST3 variants / "+String(engine.known.getBlacklistedFiles().size())+" failed files\n"+(list.isScanning()?"Scanning...":"Use Retry / rescan for a full refresh. Additional locations: Add plug-in folder."),dontSendNotification);
        if(list.isScanning())return;
        if(pending<0)return;
        auto formats=engine.formats.getFormats();
        if(pending>=formats.size()){pending=-1;return;}
        auto* f=formats[pending++];
        auto candidates=f->searchPathsForPlugins(locations.forFormat(*f),true,false);candidates.removeDuplicates(false);
        if(!candidates.isEmpty())list.scanFor(*f,candidates);
    }
};

namespace Night
{
    const Colour mint{0xff8fe3ce}, lavender{0xffb7a0ed}, white{0xffdce5f0};
    const Colour muted{0xff8291a5}, border{0xff26303e};
}
class MixerLook final : public LookAndFeel_V4
{
public:
    void drawButtonBackground(Graphics& g,Button& b,const Colour&,bool over,bool down) override
    {
        auto r=b.getLocalBounds().toFloat().reduced(0.5f);
        auto accent=b.findColour(TextButton::buttonOnColourId);
        auto c=b.getToggleState()?accent.withAlpha(0.24f):Colour(0xff171f2b);
        if(over)c=c.brighter(0.13f);if(down)c=c.darker(0.2f);
        g.setGradientFill(ColourGradient(c.brighter(0.06f),0,0,c,0,r.getBottom(),false));
        g.fillRoundedRectangle(r,7);
        g.setColour((b.getToggleState()?accent:Night::border).withAlpha(b.isEnabled()?0.9f:0.3f));
        g.drawRoundedRectangle(r,7,1);
    }
    void drawRotarySlider(Graphics& g,int x,int y,int w,int h,float value,float start,float end,Slider& slider) override
    {
        auto r=Rectangle<float>((float)x,(float)y,(float)w,(float)h).reduced(9);
        float radius=jmin(r.getWidth(),r.getHeight())*0.5f, cx=r.getCentreX(),cy=r.getCentreY();
        auto accent=slider.findColour(Slider::rotarySliderFillColourId);
        Path track,fill;track.addCentredArc(cx,cy,radius,radius,0,start,end,true);
        fill.addCentredArc(cx,cy,radius,radius,0,start,start+value*(end-start),true);
        g.setColour(Night::border);g.strokePath(track,PathStrokeType(3));
        g.setColour(accent.withAlpha(0.08f));g.strokePath(fill,PathStrokeType(11));
        g.setColour(accent);g.strokePath(fill,PathStrokeType(3));
        g.setGradientFill(ColourGradient(Colour(0xff293342),cx,cy-radius,Colour(0xff0d121a),cx,cy+radius,false));
        g.fillEllipse(cx-radius+7,cy-radius+7,2*radius-14,2*radius-14);
        g.setColour(Night::border);g.drawEllipse(cx-radius+7,cy-radius+7,2*radius-14,2*radius-14,1);
        float angle=start+value*(end-start)-MathConstants<float>::halfPi;
        g.setColour(accent);g.drawLine(cx+std::cos(angle)*(radius-17),cy+std::sin(angle)*(radius-17),cx+std::cos(angle)*(radius-9),cy+std::sin(angle)*(radius-9),2);
    }
    void drawLinearSlider(Graphics& g,int x,int y,int w,int h,float pos,float min,float max,Slider::SliderStyle style,Slider& slider) override
    {
        if(style!=Slider::LinearVertical){LookAndFeel_V4::drawLinearSlider(g,x,y,w,h,pos,min,max,style,slider);return;}
        float centre=x+w*0.5f;auto accent=slider.findColour(Slider::thumbColourId);
        g.setColour(Colour(0xff080c12));g.fillRoundedRectangle(centre-5,(float)y,10,(float)h,5);
        g.setColour(Night::border);for(int j=0;j<=10;++j){float ty=y+h*j/10.0f;g.drawHorizontalLine((int)ty,centre-23,centre-12);g.drawHorizontalLine((int)ty,centre+12,centre+23);}
        g.setColour(accent.withAlpha(0.25f));g.fillRoundedRectangle(centre-1,pos,2,jmax(0.0f,y+h-pos),1);
        auto cap=Rectangle<float>(centre-17,pos-15,34,30);
        g.setColour(Colours::black.withAlpha(0.5f));g.fillRoundedRectangle(cap.translated(0,3).expanded(2),5);
        g.setGradientFill(ColourGradient(accent.brighter(0.15f),centre,pos-15,accent.darker(0.55f),centre,pos+15,false));g.fillRoundedRectangle(cap,4);
        g.setColour(accent.withAlpha(0.9f));g.drawRoundedRectangle(cap.reduced(0.5f),4,1);
        g.setColour(Colour(0xff141c26));g.fillRect(centre-15,pos-2,30.0f,4.0f);
        g.setColour(accent.brighter());g.drawHorizontalLine((int)pos,centre-14,centre+14);
    }
};

class MainPanel final : public Component, private Timer
{
public:
    MainPanel()
    {
        look.setColour(ResizableWindow::backgroundColourId,Colour(0xff0c1119));
        look.setColour(TextButton::textColourOffId,Night::white);
        look.setColour(TextButton::textColourOnId,Night::white);
        look.setColour(TextButton::buttonOnColourId,Night::mint);
        look.setColour(Slider::trackColourId,Night::mint);
        look.setColour(Slider::thumbColourId,Night::white);
        look.setColour(Slider::rotarySliderFillColourId,Night::mint);
        look.setColour(Slider::textBoxTextColourId,Night::white);
        look.setColour(Slider::textBoxOutlineColourId,Colours::transparentBlack);
        look.setColour(ComboBox::backgroundColourId,Colour(0xff141c27));
        look.setColour(ComboBox::outlineColourId,Night::border);
        look.setColour(ComboBox::textColourId,Night::white);
        look.setColour(PopupMenu::backgroundColourId,Colour(0xff141c27));
        look.setColour(PopupMenu::highlightedBackgroundColourId,Colour(0xff30443f));
        setLookAndFeel(&look);
        button(audio,"Audio setup",[this]{ showAudio(); });
        button(plugins,"Plug-ins / Scan",[this]{ showPlugins(); });
        button(save,"Save preset",[this]{ filePreset(true); });
        button(load,"Load preset",[this]{ filePreset(false); });
        button(diagnostics,"Diagnostics",[this]{
            if(engine.live){error("Stop audio before running diagnostics.");return;}
            Engine test;auto report=test.selfTest()+test.channelTest();
            for(auto& d:test.known.getTypes())engine.known.addType(d);
            auto f=engine.dataFolder().getChildFile("validation.txt");f.replaceWithText(report);
            auto* text=new TextEditor();text->setMultiLine(true);text->setReadOnly(true);text->setText(report);text->setSize(850,600);
            diagnosticWindow=std::make_unique<PanelWindow>("VL / Validation report",text);
            status=report.contains("FAIL")?"Diagnostics: a check failed. See validation report.":"Diagnostics passed. AU / VST3 test effects added to library.";
        });
        button(monitorMute,"MUTE MONITORING",[this]{
            if(!engine.monitorMuted && (engine.streamChannel<0 || std::abs(engine.streamChannel.load()-engine.outputChannel.load())<2))
            {error("To mute monitoring and keep the recording, first select a separate STREAM / RECORD output pair. If recording captures the MONITOR pair, muting it also mutes the recording.");return;}
            engine.monitorMuted=!engine.monitorMuted.load();
        });
        monitorMute.setTooltip("Mute only MONITOR. STREAM output continues; use a separate pair for recording.");
        stream.addItem("Stream off",1);stream.setSelectedId(1);
        stream.onChange=[this]{engine.streamChannel=stream.getSelectedId()-2;};addAndMakeVisible(stream);
        button(power,"START AUDIO",[this]{ sessionEdited=true;engine.live=!engine.live.load(); });
        mode.addItem("Stereo out",1); mode.addItem("Mono out",2); mode.setSelectedId(1);
        mode.onChange=[this]{ engine.mono=mode.getSelectedId()==2; }; addAndMakeVisible(mode);
        mic.onChange=[this]{ if(mic.getSelectedId()>0) engine.micChannel=mic.getSelectedId()-1; }; addAndMakeVisible(mic);
        output.onChange=[this]{ if(output.getSelectedId()>0) engine.outputChannel=output.getSelectedId()-1; }; addAndMakeVisible(output);
        gain(inGain,-60,24,[this]{engine.inputGain=Decibels::decibelsToGain((float)inGain.getValue());});
        gain(outGain,-60,12,[this]{engine.outputGain=Decibels::decibelsToGain((float)outGain.getValue());});
        extraMode.addItem("Channel 2 off",1);extraMode.addItem("Audio / guitar",2);extraMode.addItem("MIDI instrument",3);extraMode.setSelectedId(1);
        extraMode.onChange=[this]{sessionEdited=true;engine.setExtraSource((Engine::ExtraSource)(extraMode.getSelectedId()-1));refresh();};addAndMakeVisible(extraMode);
        extraInput.onChange=[this]{if(extraInput.getSelectedId()>0)engine.extraChannel=extraInput.getSelectedId()-1;};addAndMakeVisible(extraInput);
        midiDevices.onChange=[this]{auto i=midiDevices.getSelectedId()-2;auto e=engine.selectMidiInput(isPositiveAndBelow(i,midiList.size())?midiList[i].identifier:String{});if(e.isNotEmpty())error(e);};addAndMakeVisible(midiDevices);
        midiFilter.addItem("All MIDI channels",1);for(int c=1;c<=16;++c)midiFilter.addItem("MIDI channel "+String(c),c+1);midiFilter.setSelectedId(1);
        midiFilter.onChange=[this]{engine.panic();engine.midiChannel=midiFilter.getSelectedId()-1;};addAndMakeVisible(midiFilter);
        button(panicButton,"PANIC / notes off",[this]{engine.panic();});
        keyboard=std::make_unique<MidiKeyboardComponent>(engine.keyboard,MidiKeyboardComponent::horizontalKeyboard);
        keyboard->setAvailableRange(48,84);keyboard->setLowestVisibleKey(48);keyboard->setKeyWidth(23);keyboard->setWantsKeyboardFocus(false);addAndMakeVisible(*keyboard);
        gain(extraTrim,-60,24,[this]{engine.extraTrim=Decibels::decibelsToGain((float)extraTrim.getValue());});
        gain(extraFader,-60,12,[this]{engine.extraGain=Decibels::decibelsToGain((float)extraFader.getValue(),-60.0f);});
        gain(extraSend,-60,0,[this]{engine.extraSend=Decibels::decibelsToGain((float)extraSend.getValue(),-60.0f);});extraSend.setValue(-60);
        extraTrim.setSliderStyle(Slider::RotaryHorizontalVerticalDrag);extraTrim.setTextBoxStyle(Slider::TextBoxBelow,false,90,22);
        extraSend.setSliderStyle(Slider::RotaryHorizontalVerticalDrag);extraSend.setTextBoxStyle(Slider::TextBoxBelow,false,90,22);
        extraFader.setSliderStyle(Slider::LinearVertical);extraFader.setTextBoxStyle(Slider::TextBoxBelow,false,90,22);
        extraTrim.setColour(Slider::rotarySliderFillColourId,Night::lavender);extraFader.setColour(Slider::thumbColourId,Night::lavender);extraSend.setColour(Slider::rotarySliderFillColourId,Night::lavender);
        extraMute.setClickingTogglesState(true);button(extraMute,"MUTE CH 2",[this]{sessionEdited=true;engine.extraMute=extraMute.getToggleState();});
        for(int i=0;i<Engine::slotCount;++i)
        {
            auto& row=rows[(size_t)i];row.add.setTooltip(slotLocation(i));row.bypass.setTooltip("Bypass insert");row.up.setTooltip("Move insert up");row.down.setTooltip("Move insert down");row.remove.setTooltip("Remove insert");
            button(row.add,"+ Add effect",[this,i]{ choose(i); });
            button(row.edit,"GUI",[this,i]{ edit(i); });
            row.bypass.setClickingTogglesState(true);
            button(row.bypass,"B",[this,i]{sessionEdited=true;engine.bypass(i,rows[(size_t)i].bypass.getToggleState());});
            button(row.up,"^",[this,i]{sessionEdited=true;closeEditors();engine.move(i,i-1);refresh();});
            button(row.down,"v",[this,i]{sessionEdited=true;closeEditors();engine.move(i,i+1);refresh();});
            button(row.remove,"X",[this,i]{editors[(size_t)i].reset();engine.remove(i);sessionEdited=true;refresh();});
        }
        gain(dryFader,-60,12,[this]{engine.dryGain=Decibels::decibelsToGain((float)dryFader.getValue(),-60.0f);});
        gain(sendLevel,-60,0,[this]{engine.sendGain=Decibels::decibelsToGain((float)sendLevel.getValue(),-60.0f);});
        gain(returnFader,-60,12,[this]{engine.returnGain=Decibels::decibelsToGain((float)returnFader.getValue(),-60.0f);});
        gain(extraReturnFader,-60,12,[this]{engine.extraReturnGain=Decibels::decibelsToGain((float)extraReturnFader.getValue(),-60.0f);});
        for(int i=0;i<4;++i)
        {
            gain(fxFaders[i],-60,12,[this,i]{engine.fxGain(i)=Decibels::decibelsToGain((float)fxFaders[i].getValue(),-60.0f);});
            fxFaders[i].setSliderStyle(Slider::LinearVertical);fxFaders[i].setTextBoxStyle(Slider::TextBoxBelow,false,82,22);
            fxFaders[i].setColour(Slider::thumbColourId,i<2?Night::mint:Night::lavender);
            fxFaders[i].setName(String(i<2?"MIC FX ":"Channel 2 FX ")+String(i%2+1)+" return level");
            fxMutes[i].setClickingTogglesState(true);fxSolos[i].setClickingTogglesState(true);
            button(fxMutes[i],"M",[this,i]{engine.fxMuted(i)=fxMutes[i].getToggleState();});
            button(fxSolos[i],"S",[this,i]{engine.fxSoloed(i)=fxSolos[i].getToggleState();});
            fxMutes[i].setTooltip("Mute this FX return only");fxSolos[i].setTooltip("Solo this FX return");
        }
        returnFader.setVisible(false);extraReturnFader.setVisible(false);
        for(auto* f:{&dryFader,&outGain}){f->setSliderStyle(Slider::LinearVertical);f->setTextBoxStyle(Slider::TextBoxBelow,false,90,24);}
        dryMute.setClickingTogglesState(true);button(dryMute,"MUTE MIC",[this]{engine.dryMute=dryMute.getToggleState();});
        button(lastSession,"Last session",[this]{
            auto x=XmlDocument::parse(engine.dataFolder().getChildFile("last-chain.vlmic"));
            if(!x){error("No saved session yet.");return;}closeEditors();auto e=engine.restore(*x);sessionEdited=e.isEmpty();if(e.isNotEmpty())error(e);else status="Last session restored. Output stopped.";refresh();
        });
        status="FX 1 / FX 2 are independent parallel returns for each channel. Set each effect to 100% wet.";
        dryFader.setColour(Slider::thumbColourId,Night::mint);
        returnFader.setColour(Slider::thumbColourId,Night::lavender);
        for(auto* knob:{&inGain,&sendLevel}){knob->setSliderStyle(Slider::RotaryHorizontalVerticalDrag);knob->setTextBoxStyle(Slider::TextBoxBelow,false,90,22);}
        sendLevel.setColour(Slider::rotarySliderFillColourId,Night::lavender);
        fxMute.setColour(TextButton::buttonOnColourId,Night::lavender);fxSolo.setColour(TextButton::buttonOnColourId,Night::lavender);
        extraTrim.setName("Channel 2 trim");extraFader.setName("Channel 2 level");extraSend.setName("Channel 2 FX send");
        inGain.setName("Input trim");dryFader.setName("Microphone level");sendLevel.setName("Send to FX");returnFader.setName("FX return level");outGain.setName("Master level");
        setSize(1280,1040); refresh(); startTimerHz(24);
    }
    ~MainPanel() override
    {
        stopTimer(); closeEditors(); pluginWindow.reset(); audioWindow.reset(); diagnosticWindow.reset();
        engine.live=false;
        if(started)if(auto x=engine.devices.createStateXml()) x->writeTo(engine.dataFolder().getChildFile("device.xml"));
        if (sessionEdited) engine.preset()->writeTo(engine.dataFolder().getChildFile("last-chain.vlmic"));
        setLookAndFeel(nullptr);
    }
    void paint(Graphics& g) override
    {
        g.setGradientFill(ColourGradient(Colour(0xff121a26),0,0,Colour(0xff080c12),1280,1040,false));g.fillAll();
        g.setColour(Night::mint);g.setFont(FontOptions(29.0f,Font::bold));g.drawText("VL",24,16,48,36,Justification::centredLeft);
        g.setColour(Night::white);g.setFont(FontOptions(16.0f,Font::bold));g.drawText("MIC HOST",82,16,180,24,Justification::centredLeft);
        g.setColour(Night::muted);g.setFont(10.0f);g.drawText("N I G H T   /   0.6.0",83,41,180,16,Justification::centredLeft);
        panel(g,{24,82,606,378});panel(g,{654,82,602,378});
        label(g,"MIC / 6 INSERTS",42,96);label(g,"CHANNEL 2 / 6 INSERTS",672,96);
        label(g,"MIC INPUT",42,135);
        for(int i=0;i<6;++i)
        {
            g.setFont(12.0f);g.setColour(Night::muted);
            g.drawText(String(i+1).paddedLeft('0',2),42,180+i*42,25,30,Justification::centredLeft);
            g.drawText(String(i+1).paddedLeft('0',2),672,180+i*42,25,30,Justification::centredLeft);
        }
        panel(g,{24,474,606,128});panel(g,{654,474,602,128});
        label(g,"MIC FX / 2 EFFECTS",42,486);label(g,"CH 2 FX / 2 EFFECTS",672,486);
        g.setColour(Night::mint);g.setFont(11.0f);g.drawText("MIC only / 100% wet",298,486,304,20,Justification::centredRight);
        g.setColour(Night::lavender);g.drawText("CH 2 only / 100% wet",928,486,304,20,Justification::centredRight);
        channel(g,24,290,"MIC",Night::mint);channel(g,326,290,"CHANNEL 2",Night::lavender);
        for(int i=0;i<4;++i)channel(g,628+i*118,110,String(i<2?"MIC FX ":"CH 2 FX ")+String(i%2+1),i<2?Night::mint:Night::lavender);
        channel(g,1100,156,"MASTER",Night::white);
        label(g,"TRIM",43,663);label(g,"TRIM",345,663);label(g,"MIC FX SEND",125,663);label(g,"CH 2 FX SEND",427,663);
        const int xs[]={270,572,716,834,952,1070,1212};const float levels[]={dryLevel,extraLevel,fxLevels[0],fxLevels[1],fxLevels[2],fxLevels[3],outLevel};
        for(int i=0;i<7;++i)
        {
            auto accent=(i==0||i==2||i==3)?Night::mint:i==6?Night::white:Night::lavender;
            verticalMeter(g,{xs[i],672,10,150},levels[i],accent);
            g.setColour(Night::muted);g.setFont(10.0f);
            if(i<2||i==6)for(int j=0;j<6;++j)g.drawText(String(-j*12),xs[i]+15,666+j*29,27,16,Justification::centredLeft);
            g.drawText(levelText(levels[i]),xs[i]-76,824,110,18,Justification::centredRight);
        }
        g.setColour(Night::border);g.drawHorizontalLine(882,24,1256);
        label(g,"MONITOR",24,890);label(g,"STREAM / RECORD",306,890);label(g,"OUTPUT",588,890);
        label(g,"MIDI INPUT",24,966);
        g.setColour(Night::muted);g.setFont(10.0f);g.drawText(deviceInfo,24,942,1232,14,Justification::centredLeft);
        g.setFont(10.0f);g.drawText(status,24,1018,1232,18,Justification::centredLeft);
    }
    void resized() override
    {
        audio.setBounds(340,22,110,32);plugins.setBounds(458,22,136,32);save.setBounds(602,22,112,32);load.setBounds(722,22,112,32);lastSession.setBounds(842,22,118,32);diagnostics.setBounds(968,22,110,32);
        mic.setBounds(145,130,462,32);
        extraMode.setBounds(822,92,174,30);extraInput.setBounds(1006,92,228,30);
        power.setBounds(1080,902,176,32);monitorMute.setBounds(866,902,204,32);
        stream.setBounds(306,912,270,26);output.setBounds(24,912,270,26);mode.setBounds(588,912,154,26);
        inGain.setBounds(34,684,90,116);sendLevel.setBounds(120,684,88,116);dryFader.setBounds(194,660,78,170);
        extraTrim.setBounds(336,684,90,116);extraSend.setBounds(422,684,88,116);extraFader.setBounds(496,660,78,170);
        for(int i=0;i<4;++i){const int x=628+i*118;fxFaders[i].setBounds(x+8,660,80,170);fxMutes[i].setBounds(x+10,840,40,26);fxSolos[i].setBounds(x+60,840,40,26);}
        outGain.setBounds(1108,660,98,170);
        dryMute.setBounds(42,840,124,26);extraMute.setBounds(344,840,124,26);

        midiDevices.setBounds(24,986,240,26);midiFilter.setBounds(276,986,172,26);panicButton.setBounds(460,986,144,26);keyboard->setBounds(622,968,634,44);
        for(int i=0;i<Engine::slotCount;++i)
        {
            auto& r=rows[(size_t)i];int x=75,y=178,nameWidth=342;
            if(i<Engine::mainSlots)y+=i*42;
            else if(i<Engine::fxEnd){x=42;y=520+(i-Engine::fxFirst)*40;nameWidth=384;}
            else if(i==Engine::instrumentSlot){x=672;y=132;nameWidth=366;}
            else if(i<Engine::extraEnd){x=705;y=178+(i-Engine::extraFirst)*42;nameWidth=326;}
            else{x=672;y=520+(i-Engine::extraFxFirst)*40;nameWidth=366;}
            r.add.setBounds(x,y,nameWidth,32);int bx=x+nameWidth+5;
            r.edit.setBounds(bx,y,42,32);r.bypass.setBounds(bx+47,y,30,32);r.up.setBounds(bx+82,y,28,32);r.down.setBounds(bx+115,y,28,32);r.remove.setBounds(bx+148,y,30,32);
            if(i==Engine::instrumentSlot){r.up.setVisible(false);r.down.setVisible(false);r.remove.setBounds(bx+84,y,30,32);}
        }
    }
    Engine engine;
    void openEditorForTest(int i) {edit(i);}
private:
    struct Row {TextButton add,edit,bypass,up,down,remove;};
    MixerLook look;
    std::array<Row,Engine::slotCount> rows;
    std::array<std::unique_ptr<PanelWindow>,Engine::slotCount> editors;
    std::unique_ptr<PanelWindow> pluginWindow,audioWindow,diagnosticWindow,pickerWindow;
    std::unique_ptr<FileChooser> chooser;
    TextButton audio,plugins,save,load,power,monitorMute,diagnostics,lastSession,dryMute,fxMute,fxSolo,extraFxMute,extraFxSolo,extraMute,panicButton;
    ComboBox mic,output,mode,stream,extraMode,extraInput,midiDevices,midiFilter;
    Array<MidiDeviceInfo> midiList;String midiSignature;std::unique_ptr<MidiKeyboardComponent> keyboard;
    std::array<Slider,4> fxFaders;std::array<TextButton,4> fxMutes,fxSolos;std::array<float,4> fxLevels{};
    Slider inGain,outGain,dryFader,sendLevel,returnFader,extraReturnFader,extraTrim,extraFader,extraSend;
    String status,deviceInfo,channelSignature;
    float inLevel=0,outLevel=0,dryLevel=0,fxLevel=0,extraFxLevel=0,extraLevel=0;
    bool started=false, sessionEdited=false;
    void button(TextButton& b,const String& text,std::function<void()> f) {b.setButtonText(text);b.onClick=std::move(f);addAndMakeVisible(b);}
    void gain(Slider& s,double min,double max,std::function<void()> f) {s.setRange(min,max,0.1);s.setValue(0);s.setTextValueSuffix(" dB");s.setSliderStyle(Slider::LinearHorizontal);s.setTextBoxStyle(Slider::TextBoxRight,false,76,26);s.onValueChange=[this,f=std::move(f)]{sessionEdited=true;f();};addAndMakeVisible(s);}
    void panel(Graphics& g,Rectangle<int> bounds)
    {
        auto r=bounds.toFloat();
        g.setColour(Colours::black.withAlpha(0.25f));g.fillRoundedRectangle(r.translated(0,3),12);
        g.setGradientFill(ColourGradient(Colour(0xff121a25),r.getX(),r.getY(),Colour(0xff0b1018),r.getX(),r.getBottom(),false));g.fillRoundedRectangle(r,12);
        g.setColour(Night::border);g.drawRoundedRectangle(r.reduced(0.5f),12,1);
    }
    void channel(Graphics& g,int x,int width,String title,Colour accent)
    {
        panel(g,{x,616,width,264});
        g.setColour(accent);g.fillRoundedRectangle((float)x+18,634,4,17,2);
        g.setFont(FontOptions(14.0f,Font::bold));g.drawText(title,x+32,629,width-48,27,Justification::centredLeft);
    }
    void verticalMeter(Graphics& g,Rectangle<int> r,float v,Colour accent)
    {
        g.setColour(Colour(0xff060a0f));g.fillRoundedRectangle(r.toFloat().expanded(3),4);
        auto fill=r.toFloat();float h=fill.getHeight()*jlimit(0.0f,1.0f,(Decibels::gainToDecibels(v,-60.0f)+60)/60);fill.setY(fill.getBottom()-h);fill.setHeight(h);
        auto c=v>=1?Colour(0xffff876e):accent;
        g.setColour(c.withAlpha(0.08f));g.fillRoundedRectangle(fill.expanded(4),4);
        g.setGradientFill(ColourGradient(c,fill.getX(),fill.getY(),c.darker(0.35f),fill.getX(),fill.getBottom(),false));g.fillRoundedRectangle(fill,2);
        g.setColour(Colour(0xff0c121b));g.fillRect(r.getX()+5,r.getY(),2,r.getHeight());
    }
    void label(Graphics& g,String text,int x,int y) {g.setFont(FontOptions(11.0f,Font::bold));g.setColour(Night::muted);g.drawText(text,x,y,260,20,Justification::centredLeft);}
    String levelText(float v) {return String(Decibels::gainToDecibels(v,-90.0f),1)+" dBFS"+(v>=1?"  CLIP":"");}
    void meter(Graphics& g,Rectangle<int> r,float value,Colour accent) {g.setColour(Night::border);g.fillRoundedRectangle(r.toFloat(),2);g.setColour(value>=1?Colour(0xffff866d):accent);g.fillRoundedRectangle(r.toFloat().withWidth(r.getWidth()*jlimit(0.0f,1.0f,(Decibels::gainToDecibels(value,-60.0f)+60)/60)),2);}
    void error(String e) {status=e;AlertWindow::showMessageBoxAsync(MessageBoxIconType::WarningIcon,"VL MIC HOST",e);}
    void closeEditors() {for(auto& e:editors)e.reset();}
    void refresh()
    {
        for(int i=0;i<Engine::slotCount;++i) {auto& r=rows[(size_t)i];auto& s=engine.slots[(size_t)i];bool has=s.plugin!=nullptr;r.add.setButtonText((i>=Engine::fxFirst&&i<Engine::fxEnd)||i>=Engine::extraFxFirst ? "FX "+String(i<Engine::fxEnd?i-Engine::fxFirst+1:i-Engine::extraFxFirst+1)+" / "+(has?s.description.name:"+ Add effect") : has?s.description.name:(i==Engine::instrumentSlot?"+ Load instrument":"+ Add effect"));r.edit.setEnabled(has);r.bypass.setEnabled(has);r.remove.setEnabled(has);r.bypass.setToggleState(s.bypass,dontSendNotification);r.up.setEnabled(i>0 && i!=Engine::instrumentSlot && Engine::slotGroup(i)==Engine::slotGroup(i-1));r.down.setEnabled(i+1<Engine::slotCount && i!=Engine::instrumentSlot && Engine::slotGroup(i)==Engine::slotGroup(i+1));}
        dryFader.setValue(Decibels::gainToDecibels(engine.dryGain.load(),-60.0f),dontSendNotification);sendLevel.setValue(Decibels::gainToDecibels(engine.sendGain.load(),-60.0f),dontSendNotification);returnFader.setValue(Decibels::gainToDecibels(engine.returnGain.load(),-60.0f),dontSendNotification);
        for(int i=0;i<4;++i){fxFaders[i].setValue(Decibels::gainToDecibels(engine.fxGain(i).load(),-60.0f),dontSendNotification);fxMutes[i].setToggleState(engine.fxMuted(i),dontSendNotification);fxSolos[i].setToggleState(engine.fxSoloed(i),dontSendNotification);}
        extraReturnFader.setValue(Decibels::gainToDecibels(engine.extraReturnGain.load(),-60.0f),dontSendNotification);extraFxMute.setToggleState(engine.extraFxMute,dontSendNotification);extraFxSolo.setToggleState(engine.extraFxSolo,dontSendNotification);
        dryMute.setToggleState(engine.dryMute,dontSendNotification);fxMute.setToggleState(engine.fxMute,dontSendNotification);fxSolo.setToggleState(engine.fxSolo,dontSendNotification);
        extraMode.setSelectedId(engine.extraSource+1,dontSendNotification);extraInput.setSelectedId(engine.extraChannel+1,dontSendNotification);midiFilter.setSelectedId(engine.midiChannel+1,dontSendNotification);
        extraTrim.setValue(Decibels::gainToDecibels(engine.extraTrim.load(),-60.0f),dontSendNotification);extraFader.setValue(Decibels::gainToDecibels(engine.extraGain.load(),-60.0f),dontSendNotification);extraSend.setValue(Decibels::gainToDecibels(engine.extraSend.load(),-60.0f),dontSendNotification);extraMute.setToggleState(engine.extraMute,dontSendNotification);
        extraInput.setEnabled(engine.extraSource==(int)Engine::ExtraSource::audio);
        inGain.setValue(Decibels::gainToDecibels(engine.inputGain.load(),-60.0f),dontSendNotification);outGain.setValue(Decibels::gainToDecibels(engine.outputGain.load(),-60.0f),dontSendNotification);mode.setSelectedId(engine.mono?2:1,dontSendNotification);
    }
    void showAudio()
    {
        if(!started)
        {
            auto e=engine.start();started=e.isEmpty();if(e.isNotEmpty())error(e);
        }
        if(!audioWindow) {auto* c=new AudioDeviceSelectorComponent(engine.devices,0,32,0,32,false,false,false,false);c->setSize(580,520);audioWindow=std::make_unique<PanelWindow>("VL / Audio setup",c);}
        audioWindow->setVisible(true);audioWindow->toFront(true);
    }
    void showPlugins()
    {
        if(!pluginWindow) {pluginWindow=std::make_unique<PanelWindow>("VL / Plug-in library",new LibraryPanel(engine));}
        pluginWindow->setVisible(true);pluginWindow->toFront(true);
    }
    static String slotLocation(int i)
    {
        if(i<Engine::mainSlots)return "MIC insert "+String(i+1);
        if(i<Engine::fxEnd)return "MIC FX "+String(i-Engine::fxFirst+1);
        if(i==Engine::instrumentSlot)return "CH 2 instrument";
        if(i<Engine::extraEnd)return "CH 2 insert "+String(i-Engine::extraFirst+1);
        return "CH 2 FX "+String(i-Engine::extraFxFirst+1);
    }
    void choose(int i)
    {
        auto safe=SafePointer<MainPanel>(this);
        pickerWindow=std::make_unique<PanelWindow>("VL / "+slotLocation(i)+" / Find plug-in",new PluginPicker(engine.known,[safe,i](PluginDescription d){
            if(!safe)return;safe->editors[(size_t)i].reset();safe->sessionEdited=true;auto e=safe->engine.load(i,d);
            if(e.isNotEmpty())safe->error(e);else {safe->status="Loaded "+d.name+" / "+slotLocation(i);safe->pickerWindow->setVisible(false);}safe->refresh();
        },[safe]{if(safe)safe->showPlugins();},[safe,i]{if(safe)safe->legacyChoose(i);},i==Engine::instrumentSlot));
    }
    void legacyChoose(int i)
    {
        auto list=engine.known.getTypes();
        std::sort(list.begin(),list.end(),[](const auto& a,const auto& b){return (a.name+a.pluginFormatName).compareIgnoreCase(b.name+b.pluginFormatName)<0;});
        PopupMenu menu;menu.addItem(1,"Scan / manage plug-ins...");menu.addSeparator();
        int transferTarget=-1;
        if(engine.slots[i].plugin && i!=Engine::instrumentSlot)
        {
            const bool micOwner=i<Engine::fxEnd;
            const bool returnSlot=(i>=Engine::fxFirst && i<Engine::fxEnd)||i>=Engine::extraFxFirst;
            const int first=micOwner?(returnSlot?0:Engine::fxFirst):(returnSlot?Engine::extraFirst:Engine::extraFxFirst);
            const int end=micOwner?(returnSlot?Engine::mainSlots:Engine::fxEnd):(returnSlot?Engine::extraEnd:Engine::extraFxEnd);
            for(int j=first;j<end;++j)if(!engine.slots[j].plugin){transferTarget=j;break;}
            if(transferTarget>=0)menu.addItem(2,String("Move to ")+(micOwner?"MIC ":"CH 2 ")+(returnSlot?"INSERTS":"FX RETURN"));
            menu.addSeparator();
        }
        for(int k=0;k<list.size();++k) if(pluginMatchesSlot(list[k],i==Engine::instrumentSlot))menu.addItem(k+100,list[k].name+" ["+list[k].pluginFormatName+"]");
        menu.showMenuAsync(PopupMenu::Options().withTargetComponent(&rows[(size_t)i].add).withMaximumNumColumns(3),[safe=SafePointer<MainPanel>(this),i,list,transferTarget](int r){if(!safe)return;if(r==1){safe->showPlugins();return;}if(r==2 && transferTarget>=0){safe->closeEditors();safe->engine.transfer(i,transferTarget);safe->sessionEdited=true;safe->status="Insert moved with its settings. On FX RETURN, set reverb Mix to 100% wet.";safe->refresh();return;}if(r>=100){safe->sessionEdited=true;safe->editors[(size_t)i].reset();auto e=safe->engine.load(i,list[r-100]);if(e.isNotEmpty())safe->error(e);else safe->status="Loaded "+list[r-100].name+" / "+slotLocation(i);safe->refresh();}});
    }
    void edit(int i)
    {
        auto& w=editors[(size_t)i];if(w){w->setVisible(true);w->toFront(true);return;}
        auto* p=engine.slots[(size_t)i].plugin.get();if(!p)return;
        auto* e=p->createEditorIfNeeded();if(!e)e=new GenericAudioProcessorEditor(*p);
        w=std::make_unique<PanelWindow>("VL / "+p->getName(),e);
    }
    void filePreset(bool writing)
    {
        chooser=std::make_unique<FileChooser>(writing?"Save VL chain":"Load VL chain",engine.dataFolder(),"*.vlmic");
        chooser->launchAsync(FileBrowserComponent::canSelectFiles|(writing?FileBrowserComponent::saveMode|FileBrowserComponent::warnAboutOverwriting:FileBrowserComponent::openMode),[safe=SafePointer<MainPanel>(this),writing](const FileChooser& fc){if(!safe)return;auto f=fc.getResult();if(f==File{})return;if(writing){f=f.withFileExtension("vlmic");if(!safe->engine.preset()->writeTo(f))safe->error("Could not save preset");else safe->status="Saved "+f.getFileName();}else{auto x=XmlDocument::parse(f);if(!x){safe->error("Invalid preset file");return;}safe->closeEditors();auto e=safe->engine.restore(*x);safe->sessionEdited=e.isEmpty();if(e.isNotEmpty())safe->error(e);else safe->status="Loaded "+f.getFileName()+". Press START AUDIO when ready.";safe->refresh();}});
    }
    void timerCallback() override
    {
        inLevel=jmax(engine.inputPeak.exchange(0),inLevel*0.88f);outLevel=jmax(engine.outputPeak.exchange(0),outLevel*0.88f);
        extraLevel=jmax(engine.extraPeak.exchange(0),extraLevel*0.88f);
        dryLevel=jmax(engine.dryPeak.exchange(0),dryLevel*0.88f);
        for(int i=0;i<4;++i)fxLevels[i]=jmax(engine.fxMeter(i).exchange(0),fxLevels[i]*.88f);
        monitorMute.setToggleState(engine.monitorMuted,dontSendNotification);
        monitorMute.setButtonText(engine.monitorMuted?"MONITORING MUTED":"MUTE MONITORING");
        power.setButtonText(engine.live?"STOP AUDIO":"START AUDIO");
        power.setEnabled(engine.devices.getCurrentAudioDevice()!=nullptr);power.setToggleState(engine.live,dontSendNotification);
        if(auto* d=engine.devices.getCurrentAudioDevice())
        {
            auto ins=d->getInputChannelNames(),outs=d->getOutputChannelNames();auto activeIn=d->getActiveInputChannels(),activeOut=d->getActiveOutputChannels();
            String signature=d->getName()+ins.joinIntoString("|")+outs.joinIntoString("|")+activeIn.toString(2)+activeOut.toString(2);
            if(signature!=channelSignature)
            {
                channelSignature=signature;engine.live=false;mic.clear(dontSendNotification);extraInput.clear(dontSendNotification);output.clear(dontSendNotification);
                stream.clear(dontSendNotification);stream.addItem("Stream off",1);engine.streamChannel=-1;stream.setSelectedId(1,dontSendNotification);
                int packed=0;for(int k=0;k<ins.size();++k)if(activeIn[k]){++packed;mic.addItem(ins[k],packed);extraInput.addItem(ins[k],packed);}
                packed=0;for(int k=0;k<outs.size();++k)if(activeOut[k]){output.addItem(outs[k]+" (L / mono)",++packed);}
                for(int k=0;k+1<output.getNumItems();k+=2)stream.addItem(output.getItemText(k)+" + R",k+2);
                mic.setSelectedId(1);extraInput.setSelectedId(engine.extraChannel.load()+1);if(extraInput.getSelectedId()==0)engine.extraChannel=-1;output.setSelectedId(1);
            }
            int latency=0;for(auto& s:engine.slots)if(s.plugin&&!s.bypass)latency+=s.plugin->getLatencySamples();
            deviceInfo=engine.devices.getCurrentAudioDeviceType()+" / "+d->getName()+"  /  "+String(d->getCurrentSampleRate()/1000,1)+" kHz  /  "+String(d->getCurrentBufferSizeSamples())+" samples  /  plug-in latency "+String(latency*1000.0/d->getCurrentSampleRate(),1)+" ms  /  CPU "+String(engine.devices.getCpuUsage()*100,1)+"%";
        }else deviceInfo="No audio device open. Choose Audio setup to connect your interface.";
        auto available=MidiInput::getAvailableDevices();String midiIds;
        for(auto& info:available)midiIds+=info.identifier+"|"+info.name;
        if(midiIds!=midiSignature || midiDevices.getNumItems()==0)
        {
            auto selected=engine.selectedMidiInput();midiSignature=midiIds;midiList=available;
            midiDevices.clear(dontSendNotification);midiDevices.addItem("No MIDI device / screen keys",1);int id=1;
            for(int i=0;i<midiList.size();++i){midiDevices.addItem(midiList[i].name,i+2);if(midiList[i].identifier==selected)id=i+2;}
            midiDevices.setSelectedId(id,dontSendNotification);if(id==1 && selected.isNotEmpty()){engine.selectMidiInput({});status="MIDI keyboard disconnected. Reconnect and select it again.";}
        }
        int selectedMidiId=1;for(int i=0;i<midiList.size();++i)if(midiList[i].identifier==engine.selectedMidiInput())selectedMidiId=i+2;
        midiDevices.setSelectedId(selectedMidiId,dontSendNotification);
        if(engine.extraSource==(int)Engine::ExtraSource::audio && engine.extraChannel<0)status="Enable the guitar input in Audio setup, then select it for Channel 2.";
        if(engine.extraSource==(int)Engine::ExtraSource::midi && !engine.slots[Engine::instrumentSlot].plugin)status="Channel 2 MIDI: load an instrument, then choose a sound inside its GUI.";
        if(engine.streamChannel>=0 && std::abs(engine.streamChannel.load()-engine.outputChannel.load())<2)status="Choose separate MONITOR and STREAM channel pairs. Overlapping STREAM route is disabled.";
        if(engine.fxLatencyOverflow||engine.extraFxLatencyOverflow)status="An FX return latency exceeds compensation capacity. That return is muted.";
        repaint();
    }
};

// The design and its controls share the same transform, including hit-testing.
// The wrapper occupies the client area supplied by DocumentWindow, never the title bar.
class ScaledMixer final : public Component
{
public:
    ScaledMixer() { addAndMakeVisible(panel); setSize(1280,1040); }
    void resized() override
    {
        panel.setTransform(AffineTransform());
        panel.setBounds(0,0,1280,1040);
        panel.setTransform(AffineTransform::scale(getWidth()/1280.0f,getHeight()/1040.0f));
    }
private:
    MainPanel panel;
};

class App final : public JUCEApplication
{
public:
    const String getApplicationName() override{return "VL MIC HOST";}
    const String getApplicationVersion() override{return "0.6.0";}
    void initialise(const String& args) override
    {
        auto tokens=StringArray::fromTokens(args,true);tokens.removeEmptyStrings();for(auto& t:tokens)t=t.unquoted();
        if(tokens.size()>0 && tokens[0]=="--audit-worker")
        {MessageManager::callAsync([tokens]{runPluginAuditWorker(tokens);});return;}
        if(tokens.size()>0 && tokens[0]=="--scan-worker")
        {
#if JUCE_MAC
        Process::setDockIconVisible(false);
#endif
MessageManager::callAsync([tokens]{runScanWorker(tokens);});return;}
#if defined(VL_HOST_VALIDATION)
        if(File::getSpecialLocation(File::currentApplicationFile).getSiblingFile("ValidationData").getChildFile("full-audit").existsAsFile())
        {auditEngine=std::make_unique<Engine>();auditWindow=std::make_unique<PanelWindow>("VL / Full VST2 and VST3 audit",new FullPluginAudit(*auditEngine));return;}
        if(File::getSpecialLocation(File::currentApplicationFile).getSiblingFile("ValidationData").getChildFile("preview-ui").existsAsFile())
        { main=std::make_unique<Window>();return; }
        MessageManager::callAsync([]{
            Engine e;auto report=e.selfTest()+e.channelTest()+validatePluginSearch()+validateInstalledDiscovery(e);
            e.dataFolder().getChildFile("validation.txt").replaceWithText(report);
            JUCEApplication::getInstance()->setApplicationReturnValue(report.contains("FAIL")?1:0);
            JUCEApplication::getInstance()->quit();
        });return;
#endif
        if(args.contains("--smoke-test"))
        {
            Engine e;e.prepare(48000,128);e.live=true;
            AudioBuffer<float> in(1,128),out(2,128);
            for(int n=0;n<128;++n)in.setSample(0,n,0.125f);
            e.process(in.getArrayOfReadPointers(),1,out.getArrayOfWritePointers(),2,128);
            bool ok=std::abs(out.getSample(0,127)-0.125f)<0.00001f && std::abs(out.getSample(1,127)-0.125f)<0.00001f;
            e.live=false;e.process(in.getArrayOfReadPointers(),1,out.getArrayOfWritePointers(),2,128);
            ok=ok && out.getMagnitude(0,128)==0;
            auto xml=e.preset();ok=ok && e.restore(*xml).isEmpty();
            auto report=ok?"PASS: stereo pass-through, stop, preset round-trip":"FAIL: engine smoke test";
            File::getCurrentWorkingDirectory().getChildFile("smoke-test.txt").replaceWithText(report);
            setApplicationReturnValue(ok?0:1);quit();return;
        }
        if(args.contains("--monitor-test"))
        {
            Engine e;e.prepare(48000,64);e.live=true;e.streamChannel=2;
            AudioBuffer<float> in(1,128),out(4,128);in.clear();for(int j=0;j<128;++j)in.setSample(0,j,0.25f);
            auto run=[&]{e.process(in.getArrayOfReadPointers(),1,out.getArrayOfWritePointers(),4,128);};
            run();bool ok=out.getSample(0,127)==0.25f && out.getSample(2,127)==0.25f;
            e.monitorMuted=true;run();ok=ok && out.getSample(0,127)==0 && out.getSample(1,127)==0 && out.getSample(2,127)==0.25f && out.getSample(3,127)==0.25f;
            e.monitorMuted=false;run();ok=ok && out.getSample(0,127)==0.25f;
            e.live=false;run();ok=ok && out.getMagnitude(0,128)==0;
            e.live=true;e.streamChannel=0;e.monitorMuted=true;run();ok=ok && out.getSample(0,127)==0;
            std::cout<<(ok?"PASS":"FAIL")<<": monitor mute/unmute, uninterrupted stereo stream, stop, overlapping route protection"<<std::endl;
            File::getCurrentWorkingDirectory().getChildFile("monitor-validation.txt").replaceWithText(ok?"PASS: mute/unmute, independent stereo stream, stop and overlapping route protection":"FAIL");
            setApplicationReturnValue(ok?0:1);quit();return;
        }
        if(args.contains("--channel-test"))
        {
            Engine e;auto report=e.channelTest();File::getCurrentWorkingDirectory().getChildFile("channel-test.txt").replaceWithText(report);std::cout<<report<<std::endl;setApplicationReturnValue(report.contains("FAIL")?1:0);quit();return;
        }
        if(args.contains("--driver-test"))
        {
            Engine e;StringArray types;
            for(auto* type:e.devices.getAvailableDeviceTypes())types.add(type->getTypeName());
            bool ok=true;
#if JUCE_WINDOWS
            ok=types.contains("ASIO") && types.contains("Windows Audio") && types.contains("DirectSound");
#endif
            String report=(ok?"PASS: ":"FAIL: ")+String("compiled audio backends: ")+types.joinIntoString(", ");
            File::getCurrentWorkingDirectory().getChildFile("driver-test.txt").replaceWithText(report);
            setApplicationReturnValue(ok?0:1);quit();return;
        }
        if(args.contains("--plugin-search-test"))
        {
            Engine e;auto report=validatePluginSearch()+validateInstalledDiscovery(e);bool ok=!report.contains("FAIL");
            File::getCurrentWorkingDirectory().getChildFile("plugin-search-test.txt").replaceWithText(report);
            setApplicationReturnValue(ok?0:1);quit();return;
        }
        if(args.contains("--self-test"))
        {
            Engine e;auto report=e.selfTest();auto f=File::getCurrentWorkingDirectory().getChildFile("self-test.txt");f.replaceWithText(report);std::cout<<report<<std::endl;setApplicationReturnValue(report.contains("FAIL")?1:0);quit();return;
        }
        main=std::make_unique<Window>();
    }
    void shutdown() override{main.reset();auditWindow.reset();auditEngine.reset();}
    void systemRequestedQuit() override{quit();}
private:
    struct Window:DocumentWindow
    {
        Window():DocumentWindow("VL MIC HOST",Colour(0xff121a26),allButtons)
        {
            // A JUCE title bar keeps Windows non-client/DPI metrics out of the mixer.
            #if JUCE_WINDOWS
            setUsingNativeTitleBar(false);
#else
            setUsingNativeTitleBar(true);
#endif
            setTitleBarHeight(32);
            setContentOwned(new ScaledMixer(),true);
            setResizable(true,false);
            setResizeLimits(640,540,7680,4320);
            auto area=Desktop::getInstance().getDisplays().getPrimaryDisplay()->userArea;
            centreWithSize(jmin(1280,area.getWidth()-40),jmin(1074,area.getHeight()-40));
            setVisible(true);
        }
        void closeButtonPressed() override{JUCEApplication::getInstance()->systemRequestedQuit();}
    };
    std::unique_ptr<Engine> auditEngine;std::unique_ptr<PanelWindow> auditWindow;
    std::unique_ptr<Window> main;
};
START_JUCE_APPLICATION(App)
