// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include "Engine.h"
#include "TestEffect.h"

inline juce::String validateDiscordOutput()
{
    using namespace juce;
    String report;
    auto check=[&](bool result,const String& label){report+=(result?"PASS ":"FAIL ")+label+"\n";};
    check(VirtualMicOutput::isVirtualName("BlackHole 2ch"),"BlackHole virtual output is recognized");
    check(VirtualMicOutput::isVirtualName("CABLE Input (VB-Audio Virtual Cable)"),"VB-CABLE virtual output is recognized");
    check(!VirtualMicOutput::isVirtualName("Audient iD4"),"Physical interface is excluded from Discord virtual outputs");
    check(VirtualMicOutput::inputName("CABLE Input (VB-Audio Virtual Cable)")=="CABLE Output (VB-Audio Virtual Cable)","Discord recording endpoint uses CABLE Output, not CABLE Input");
    {
        VirtualMicOutput output;
        check(output.open({"CoreAudio","BlackHole 2ch"},"BlackHole 2ch").isNotEmpty()
              && output.open({"CoreAudio","BlackHole 2ch"},"Speakers","BlackHole 2ch").isNotEmpty()
              && output.open({"Windows Audio","CABLE Input"},"Speakers","CABLE Output").isNotEmpty(),
              "Same monitor destination and cable feedback input are rejected");
        auto file=File::getSpecialLocation(File::tempDirectory).getChildFile("vl-discord-state-"+Uuid().toString()+".xml");
        output.buffer.mono=false;output.save(file);VirtualMicOutput restored;
        check(restored.restore(file,"Speakers").isEmpty() && !restored.buffer.mono && !restored.connected,
              "Disconnected destination and stereo mode survive settings round-trip");
        XmlElement missing("VL_VIRTUAL_MIC");missing.setAttribute("type","CoreAudio");missing.setAttribute("name","BlackHole missing-test-device");missing.writeTo(file);
        check(restored.restore(file,"Speakers").isNotEmpty() && !restored.connected,"Missing saved cable reports an error without opening a default output");
        file.deleteFile();
    }
    for(double source: {44100.0,48000.0,96000.0}) for(double drift:{-.0005,0.0,.0005})
    {
        VirtualMicBuffer bridge;bridge.setSourceRate(source);bridge.setEnabled(true);bridge.mono=false;
        AudioBuffer<float> input(2,1024),output(2,256);double budget=0;int sample=0,zeros=0,crossings=0;
        float previous=0;double sum=0;int measured=0;bool finite=true;
        bridge.render(output.getArrayOfWritePointers(),2,256,48000);
        for(int block=0;block<4000;++block)
        {
            budget+=256*source/48000*(1.0+drift);const int n=(int)budget;budget-=n;
            for(int i=0;i<n;++i){const float v=.2f*std::sin((float)(MathConstants<double>::twoPi*440*(sample++)/source));input.setSample(0,i,v);input.setSample(1,i,-v);}
            bridge.push(input.getReadPointer(0),input.getReadPointer(1),n);
            bridge.render(output.getArrayOfWritePointers(),2,256,48000);
            if(block>1000)
            {
                if(output.getMagnitude(0,256)==0)++zeros;
                for(int i=0;i<256;++i)
                {
                    float v=output.getSample(0,i);finite=finite && std::isfinite(v) && std::abs(v+output.getSample(1,i))<.000001f;
                    sum+=v*v;++measured;if(previous<0 && v>=0)++crossings;previous=v;
                }
            }
        }
        const double rms=std::sqrt(sum/measured),hz=crossings*48000.0/measured;
        check(finite && zeros==0 && std::abs(rms-.14142)<.003 && std::abs(hz-440)<1 && bridge.overruns==0 && bridge.underruns==0,
              "Continuous stereo resampling "+String(source,0)+" -> 48000 Hz / clock drift "+String(drift*1e6,0)+" ppm ("+String(hz,2)+" Hz)");
    }
    {
        Engine e;e.prepare(48000,64);e.live=true;e.virtualMic.connected=true;e.monitorMuted=true;
        e.slots[0].plugin=std::make_unique<TestEffect>(3,2);e.slots[0].plugin->prepareToPlay(48000,64);e.outputGain=.4f;
        AudioBuffer<float> input(1,64),hardware(2,64),chat(2,64);
        for(int i=0;i<64;++i)input.setSample(0,i,.125f);
        auto run=[&]{e.process(input.getArrayOfReadPointers(),1,hardware.getArrayOfWritePointers(),2,64);e.virtualMic.buffer.render(chat.getArrayOfWritePointers(),2,64,48000);};
        for(int block=0;block<100;++block)run();
        check(hardware.getMagnitude(0,64)==0 && std::abs(chat.getSample(0,63)-.1f)<.00001f && std::abs(chat.getSample(1,63)-.1f)<.00001f,
              "Processed plug-in and master gain reach Discord while hardware monitoring is muted");
        e.extraSource=(int)Engine::ExtraSource::audio;e.extraChannel=0;e.extraTrim=2;e.extraGain=.5f;
        for(int block=0;block<100;++block)run();
        check(std::abs(chat.getSample(0,63)-.15f)<.00001f,"CHANNEL 2 is included in the processed Discord master mix");
        e.live=false;run();
        const auto stopLeft=chat.getMagnitude(0,64),stopRight=chat.getMagnitude(1,64);
        check(stopLeft==0 && stopRight==0,"STOP AUDIO discards buffered speech and immediately sends silence (L="+String(stopLeft,8)+", R="+String(stopRight,8)+", enabled="+String((int)e.virtualMic.buffer.isEnabled())+", queued="+String(e.virtualMic.buffer.bufferedSamples())+")");
        e.live=true;for(int block=0;block<100;++block)run();
        check(std::abs(chat.getSample(0,63)-.15f)<.00001f,"Restart re-primes the cable without stale audio");
        e.virtualMic.connected=false;run();
        check(chat.getMagnitude(0,64)==0,"Disconnecting the virtual destination produces silence");
    }
    {
        VirtualMicBuffer bridge;AudioBuffer<float> input(2,2048),output(2,256);
        for(int i=0;i<2048;++i){input.setSample(0,i,.2f);input.setSample(1,i,.4f);}
        bridge.setEnabled(true);bridge.render(output.getArrayOfWritePointers(),2,256,48000);
        bridge.push(input.getReadPointer(0),input.getReadPointer(1),2048);bridge.render(output.getArrayOfWritePointers(),2,256,48000);
        check(std::abs(output.getSample(0,255)-.3f)<.00001f && output.getSample(0,255)==output.getSample(1,255),"Mono chat mode sends both stereo sides to both cable channels");
        for(int i=0;i<100;++i)bridge.render(output.getArrayOfWritePointers(),2,256,48000);
        check(output.getMagnitude(0,256)==0 && bridge.underruns>0,"No producer: cable sends silence, never repeats the last speech block");
        for(int i=0;i<40;++i)bridge.push(input.getReadPointer(0),input.getReadPointer(1),2048);
        bridge.render(output.getArrayOfWritePointers(),2,256,48000);
        check(output.getMagnitude(0,256)==0 && bridge.overruns>0 && bridge.bufferedSamples()==0,"Overflow recovery drops stale backlog with bounded fixed storage");
        bridge.setSourceRate(44100);bridge.render(output.getArrayOfWritePointers(),2,256,48000);
        bridge.push(input.getReadPointer(0),input.getReadPointer(1),2048);bridge.render(output.getArrayOfWritePointers(),2,256,48000);
        check(std::abs(output.getSample(0,255)-.3f)<.00001f,"Hardware sample-rate change re-primes the independent destination");
        const float bad[4]={NAN,INFINITY,-INFINITY,0};bridge.push(bad,bad,4);
        for(int i=0;i<20;++i)bridge.render(output.getArrayOfWritePointers(),2,256,48000);
        bool finite=true;for(int i=0;i<256;++i)finite=finite&&std::isfinite(output.getSample(0,i));
        check(finite,"Non-finite plug-in samples never reach the chat output");
    }
    return report;
}
