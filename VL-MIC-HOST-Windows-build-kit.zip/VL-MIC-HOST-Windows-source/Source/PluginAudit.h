// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include "Engine.h"

// This entry point is run in a disposable worker, never in the live audio host.
inline void runPluginAuditWorker(const juce::StringArray& args)
{
    using namespace juce;
#if JUCE_MAC
    Process::setDockIconVisible(false);
#endif
    if(args.size()!=3)std::_Exit(2);
    auto xml=XmlDocument::parse(File(args[1]));if(!xml)std::_Exit(3);
    PluginDescription d;if(!d.loadFromXml(*xml))std::_Exit(3);
    XmlElement result("PLUGIN_AUDIT");result.setAttribute("name",d.name);result.setAttribute("format",d.pluginFormatName);
    {
        Engine engine;const int slot=d.isInstrument?Engine::instrumentSlot:0;
        const auto error=engine.load(slot,d);result.setAttribute("loaded",error.isEmpty());result.setAttribute("error",error);
        if(error.isEmpty())
        {
            auto* p=engine.slots[slot].plugin.get();engine.prepare(48000,128);engine.live=true;
            if(d.isInstrument){engine.queueMidi(MidiMessage::noteOn(1,60,(uint8)100));}
            AudioBuffer<float> input(2,128),output(2,128);input.clear();input.setSample(0,0,.001f);
            bool finite=true;for(int block=0;block<8;++block)
            {
                engine.process(input.getArrayOfReadPointers(),2,output.getArrayOfWritePointers(),2,128);
                for(int c=0;c<2;++c)for(int n=0;n<128;++n)finite=finite&&std::isfinite(output.getSample(c,n));
            }
            result.setAttribute("rendered",finite);
            auto* editor=p->createEditorIfNeeded();const bool native=p->hasEditor();
            if(!editor)editor=new GenericAudioProcessorEditor(*p);
            result.setAttribute("nativeGUI",native);result.setAttribute("editorWidth",editor->getWidth());result.setAttribute("editorHeight",editor->getHeight());
            result.setAttribute("editorCreated",editor->getWidth()>0 && editor->getHeight()>0);
            // Publish before teardown as some third-party editors crash while closing.
            result.writeTo(File(args[2]));delete editor;
        }
        else result.writeTo(File(args[2]));
    }
    result.setAttribute("closed",true);const bool written=result.writeTo(File(args[2]));std::_Exit(written?0:4);
}
