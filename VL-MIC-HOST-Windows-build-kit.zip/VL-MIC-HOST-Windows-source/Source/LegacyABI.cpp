// SPDX-License-Identifier: AGPL-3.0-only
#include <cstddef>
#include <cstdint>
namespace LegacyABI {
struct AEffect;
#include <pluginterfaces/vst2.x/aeffect.h>
#include <pluginterfaces/vst2.x/aeffectx.h>
static_assert(sizeof(void*)==8,"64-bit host required");
static_assert(offsetof(AEffect,uniqueID)==112 && offsetof(AEffect,processReplacing)==120,"VST2 x64 effect ABI");
static_assert(sizeof(AEffect)==192,"VST2 effect extension storage");
static_assert(sizeof(VstSpeakerProperties)==112 && sizeof(VstSpeakerArrangement)==904,"JUCE expects eight inline speaker entries");
static_assert(sizeof(VstEvents)==32 && sizeof(VstPinProperties)==128,"VST2 event / pin storage ABI");
static_assert(sizeof(MidiKeyName)==72 && sizeof(VstTimeInfo)==88,"VST2 MIDI note / time ABI");
}
