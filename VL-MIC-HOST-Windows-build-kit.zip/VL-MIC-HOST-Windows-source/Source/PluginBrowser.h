// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include "Engine.h"

class PluginPicker final : public juce::Component, private juce::ListBoxModel, private juce::ChangeListener
{
public:
    PluginPicker(Engine& engine, std::function<void(juce::PluginDescription)> onLoad,
                 std::function<void()> onScan, std::function<void()> onMore) : known(engine.known), load(std::move(onLoad))
    {
        known.addChangeListener(this);
        addAndMakeVisible(search);addAndMakeVisible(results);addAndMakeVisible(add);addAndMakeVisible(scan);addAndMakeVisible(count);addAndMakeVisible(more);
        more.setButtonText("More...");more.onClick=std::move(onMore);
        search.setTextToShowWhenEmpty("Search name, manufacturer or format...",juce::Colours::grey);
        search.onTextChange=[this]{filter();};search.onReturnKey=[this]{commit();};
        results.setModel(this);results.setRowHeight(38);
        add.setButtonText("Load selected");add.onClick=[this]{commit();};
        scan.setButtonText("Scan / manage plug-ins");scan.onClick=std::move(onScan);
        setSize(680,500);changeListenerCallback(nullptr);
    }
    ~PluginPicker() override {known.removeChangeListener(this);results.setModel(nullptr);}
    void resized() override
    {
        search.setBounds(12,12,getWidth()-24,32);count.setBounds(12,48,getWidth()-24,24);
        results.setBounds(12,76,getWidth()-24,juce::jmax(0,getHeight()-130));
        scan.setBounds(12,getHeight()-42,220,30);more.setBounds(244,getHeight()-42,90,30);add.setBounds(getWidth()-170,getHeight()-42,158,30);
    }
private:
    juce::KnownPluginList& known;
    void changeListenerCallback(juce::ChangeBroadcaster*) override
    {
        all.clear();for(auto d:known.getTypes())if(!d.isInstrument && d.numInputChannels>0)all.add(d);
        std::sort(all.begin(),all.end(),[](const auto& a,const auto& b){return (a.name+a.pluginFormatName).compareIgnoreCase(b.name+b.pluginFormatName)<0;});filter();
    }
    juce::Array<juce::PluginDescription> all,filtered;
    juce::TextEditor search;juce::ListBox results;juce::TextButton add,scan,more;juce::Label count;
    std::function<void(juce::PluginDescription)> load;
    void filter()
    {
        filtered.clear();auto words=juce::StringArray::fromTokens(search.getText().trim(),false);words.removeEmptyStrings();
        for(auto d:all){auto text=d.name+" "+d.manufacturerName+" "+d.pluginFormatName;bool match=true;for(auto word:words)match=match&&text.containsIgnoreCase(word);if(match)filtered.add(d);}
        results.deselectAllRows();results.updateContent();if(!filtered.isEmpty())results.selectRow(0);
        add.setEnabled(!filtered.isEmpty());count.setText(juce::String(filtered.size())+" effects found"+(all.isEmpty()?" — scan your plug-ins first":""),juce::dontSendNotification);results.repaint();
    }
    int getNumRows() override {return filtered.size();}
    void paintListBoxItem(int row,juce::Graphics& g,int w,int h,bool selected) override
    {
        if(!juce::isPositiveAndBelow(row,filtered.size()))return;
        if(selected)g.fillAll(juce::Colour(0xff29463f));g.setColour(juce::Colours::whitesmoke);g.setFont(15.0f);
        const auto& d=filtered.getReference(row);g.drawText(d.name+"  ["+d.pluginFormatName+"]",10,0,w-20,h/2,juce::Justification::centredLeft);
        g.setColour(juce::Colours::grey);g.setFont(12.0f);g.drawText(d.manufacturerName,10,h/2,w-20,h/2,juce::Justification::centredLeft);
    }
    void listBoxItemDoubleClicked(int,const juce::MouseEvent&) override {commit();}
    void returnKeyPressed(int) override {commit();}
    void commit(){auto row=results.getSelectedRow();if(juce::isPositiveAndBelow(row,filtered.size()))load(filtered[row]);}
};
