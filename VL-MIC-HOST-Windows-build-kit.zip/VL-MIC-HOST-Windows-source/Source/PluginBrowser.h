// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include "Engine.h"

inline bool pluginMatchesSearch(const juce::PluginDescription& d, const juce::String& query)
{
    auto words=juce::StringArray::fromTokens(query.trim(),false);words.removeEmptyStrings();
    auto text=d.name+" "+d.descriptiveName+" "+d.manufacturerName+" "+d.pluginFormatName+" "+d.category;
    for(auto word:words)if(!text.containsIgnoreCase(word))return false;
    return true;
}

inline bool pluginMatchesSlot(const juce::PluginDescription& d, bool instrumentSlot)
{
    // VST3 moduleinfo.json discovery leaves both channel counts at zero.
    // Classify by plug-in type; Engine::configure checks the real buses on load.
    return d.isInstrument == instrumentSlot;
}

class PluginPicker final : public juce::Component, private juce::ListBoxModel, private juce::ChangeListener
{
public:
    PluginPicker(juce::KnownPluginList& library, std::function<void(juce::PluginDescription)> onLoad,
                 std::function<void()> onScan, std::function<void()> onMore, bool instruments = false, bool catalog = false) : known(library), load(std::move(onLoad)), instrumentsOnly(instruments), catalogMode(catalog)
    {
        known.addChangeListener(this);
        addAndMakeVisible(search);addAndMakeVisible(results);addAndMakeVisible(add);addAndMakeVisible(scan);addAndMakeVisible(count);addAndMakeVisible(more);
        more.setButtonText("More...");more.onClick=std::move(onMore);
        more.setVisible(!catalogMode);add.setVisible(!catalogMode);
        search.setTextToShowWhenEmpty("Search any name, manufacturer, format or category...",juce::Colours::grey);
        search.onTextChange=[this]{filter();};search.onReturnKey=[this]{commit();};
        results.setModel(this);results.setRowHeight(38);
        add.setButtonText("Load selected");add.onClick=[this]{commit();};
        scan.setButtonText("Scan / manage plug-ins");scan.onClick=std::move(onScan);
        setSize(680,500);changeListenerCallback(nullptr);
    }
    std::optional<juce::PluginDescription> selectedPlugin() const { const int row=results.getSelectedRow();return juce::isPositiveAndBelow(row,filtered.size())?std::optional<juce::PluginDescription>(filtered[row]):std::nullopt; }
    ~PluginPicker() override {known.removeChangeListener(this);results.setModel(nullptr);}
    void resized() override
    {
        search.setBounds(12,12,getWidth()-24,32);count.setBounds(12,48,getWidth()-24,24);
        results.setBounds(12,76,getWidth()-24,juce::jmax(0,getHeight()-130));
        scan.setBounds(12,getHeight()-42,220,30);more.setBounds(244,getHeight()-42,90,30);add.setBounds(getWidth()-170,getHeight()-42,158,30);
    }
private:
    juce::KnownPluginList& known;
    void changeListenerCallback(juce::ChangeBroadcaster*) override
    {
        all.clear();for(auto d:known.getTypes())if(catalogMode || pluginMatchesSlot(d,instrumentsOnly))all.add(d);
        std::sort(all.begin(),all.end(),[](const auto& a,const auto& b){return (a.name+a.pluginFormatName).compareIgnoreCase(b.name+b.pluginFormatName)<0;});filter();
    }
    juce::Array<juce::PluginDescription> all,filtered;
    juce::TextEditor search;juce::ListBox results;juce::TextButton add,scan,more;juce::Label count;
    std::function<void(juce::PluginDescription)> load;
    bool instrumentsOnly, catalogMode;
    void filter()
    {
        filtered.clear();for(auto d:all)if(pluginMatchesSearch(d,search.getText()))filtered.add(d);
        results.deselectAllRows();results.updateContent();if(!filtered.isEmpty())results.selectRow(0);
        add.setEnabled(!filtered.isEmpty());count.setText(juce::String(filtered.size())+(catalogMode?" plug-ins found (all manufacturers)":instrumentsOnly?" instruments found":" effects found")+(all.isEmpty()?" — scan your plug-ins first":""),juce::dontSendNotification);results.repaint();
    }
    int getNumRows() override {return filtered.size();}
    void paintListBoxItem(int row,juce::Graphics& g,int w,int h,bool selected) override
    {
        if(!juce::isPositiveAndBelow(row,filtered.size()))return;
        if(selected)g.fillAll(juce::Colour(0xff29463f));g.setColour(juce::Colours::whitesmoke);g.setFont(15.0f);
        const auto& d=filtered.getReference(row);g.drawText(d.name+"  ["+d.pluginFormatName+"]",10,0,w-20,h/2,juce::Justification::centredLeft);
        g.setColour(juce::Colours::grey);g.setFont(12.0f);g.drawText(d.manufacturerName+" / "+(d.isInstrument?"Instrument":"Effect"),10,h/2,w-20,h/2,juce::Justification::centredLeft);
    }
    void listBoxItemDoubleClicked(int row,const juce::MouseEvent&) override {results.selectRow(row);commit();}
    void returnKeyPressed(int) override {commit();}
    void commit(){auto row=results.getSelectedRow();if(load && juce::isPositiveAndBelow(row,filtered.size()))load(filtered[row]);}
};
