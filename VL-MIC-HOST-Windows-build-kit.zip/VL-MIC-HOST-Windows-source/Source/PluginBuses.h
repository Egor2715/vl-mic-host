// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include <JuceHeader.h>
#include <algorithm>
#include <vector>

inline juce::String describePluginBuses(const juce::AudioProcessor::BusesLayout& layout)
{
    using namespace juce;
    StringArray directions;
    for(bool input:{true,false})
    {
        StringArray buses;
        for(const auto& bus:layout.getBuses(input))
            buses.add(String(bus.size())+"ch "+(bus.isDisabled()?String("disabled"):bus.getDescription()));
        directions.add(String(input?"input [":"output [")+buses.joinIntoString(", ")+"]");
    }
    return directions.joinIntoString(" / ");
}

inline bool isHostablePluginLayout(const juce::AudioProcessor::BusesLayout& layout,bool instrument)
{
    const int in=layout.getMainInputChannels(),out=layout.getMainOutputChannels();
    int totalIn=0,totalOut=0;
    for(const auto& bus:layout.inputBuses)totalIn+=bus.size();
    for(const auto& bus:layout.outputBuses)totalOut+=bus.size();
    return (out==1||out==2) && (in==1||in==2||(instrument&&in==0))
        && totalIn<=32 && totalOut<=32;
}

// A channel count is not a speaker arrangement. Keep a fixed mono component's
// own channel set (e.g. Left, Centre or discrete) instead of replacing it with
// canonical Mono. Some VST3 effects also require their auxiliary bus to remain
// enabled. Its input receives silence; only the main output enters the mixer.
inline bool negotiatePluginBuses(juce::AudioPluginInstance& plugin,bool instrument,juce::String& report)
{
    using namespace juce;
    plugin.releaseResources(); // Layout changes must occur while VST3 is inactive.
    const auto original=plugin.getBusesLayout();
    report="Declared: "+describePluginBuses(original)+"\n";
    if(original.outputBuses.isEmpty()||(!instrument&&original.inputBuses.isEmpty()))return false;

    auto native=original;
    for(bool input:{true,false})
    {
        auto& buses=native.getBuses(input);
        if(buses.isEmpty())continue;
        if(buses[0].isDisabled())
        {
            auto* bus=plugin.getBus(input,0);
            auto enabled=bus->getLastEnabledLayout();
            if(enabled.isDisabled())enabled=bus->getDefaultLayout();
            buses.getReference(0)=enabled.isDisabled()?AudioChannelSet::stereo():enabled;
        }
    }
    auto mainOnly=native;
    auto auxiliaries=native;
    for(bool input:{true,false})
        for(int i=1;i<plugin.getBusCount(input);++i)
        {
            // AU instruments such as Kontakt may accept disabled audio inputs
            // but render silence. Keep their input buses valid and feed silence.
            mainOnly.getBuses(input).getReference(i)=input&&instrument
                ?plugin.getBus(input,i)->getLastEnabledLayout():AudioChannelSet::disabled();
            if(auxiliaries.getBuses(input)[i].isDisabled())
                auxiliaries.getBuses(input).getReference(i)=plugin.getBus(input,i)->getLastEnabledLayout();
        }

    std::vector<AudioProcessor::BusesLayout> tried;
    auto attempt=[&](const AudioProcessor::BusesLayout& candidate,const String& label)
    {
        if(!isHostablePluginLayout(candidate,instrument))return false;
        if(std::find(tried.begin(),tried.end(),candidate)!=tried.end())return false;
        tried.push_back(candidate);
        const bool ok=plugin.setBusesLayout(candidate)&&isHostablePluginLayout(plugin.getBusesLayout(),instrument);
        report+=label+": "+describePluginBuses(candidate)+(ok?" / accepted\n":" / rejected\n");
        return ok;
    };
    // Native layouts precede canonical guesses, including mandatory sidechains.
    for(const auto& base:{mainOnly,native,auxiliaries})
        if(attempt(base,"Native buses"))return true;

    for(const auto& base:{mainOnly,native,auxiliaries})
        for(auto pair:{std::pair<int,int>{2,2},{1,1},{1,2},{2,1}})
        {
            auto candidate=base;
            if(!candidate.inputBuses.isEmpty())
                candidate.inputBuses.getReference(0)=AudioChannelSet::canonicalChannelSet(pair.first);
            candidate.outputBuses.getReference(0)=AudioChannelSet::canonicalChannelSet(pair.second);
            if(attempt(candidate,"Negotiated buses"))return true;
        }
    return false;
}
