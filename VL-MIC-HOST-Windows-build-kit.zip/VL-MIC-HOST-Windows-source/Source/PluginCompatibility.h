// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include <JuceHeader.h>
#if JUCE_MAC

inline constexpr juce::uint32 macHostCpu()
{
   #if JUCE_ARM
    return 0x0100000c; // CPU_TYPE_ARM64
   #else
    return 0x01000007; // CPU_TYPE_X86_64, including a Rosetta process
   #endif
}

inline juce::String macBinaryProblemForCpu(juce::InputStream& stream, juce::uint32 wantedCpu)
{
    using namespace juce;
    const auto mismatch=wantedCpu==0x01000007
        ? "This plug-in has no Intel x86_64 binary: install its Intel / Universal version"
        : "This plug-in has no Apple Silicon arm64 binary: install its Apple Silicon / Universal version, or run the host with Rosetta";
    stream.setPosition(0);
    if(stream.getTotalLength()<4)return "Plug-in binary header is truncated";
    const auto magic=(uint32)stream.readInt();
    if(magic==0xfeedfacf || magic==0xfeedface || magic==0xcffaedfe || magic==0xcefaedfe)
    {
        const bool bigEndian=magic==0xcffaedfe || magic==0xcefaedfe;
        const bool is64Bit=magic==0xfeedfacf || magic==0xcffaedfe;
        if(stream.getTotalLength()<(is64Bit?32:28))return "Mach-O header is truncated";
        const auto cpu=(uint32)(bigEndian?stream.readIntBigEndian():stream.readInt());
        return is64Bit && cpu==wantedCpu?String():String(mismatch);
    }
    const bool fat32=magic==0xbebafeca || magic==0xcafebabe;
    const bool fat64=magic==0xbfbafeca || magic==0xcafebabf;
    if(fat32 || fat64)
    {
        if(stream.getTotalLength()<8)return "Universal Mach-O header is truncated";
        const bool bigEndian=magic==0xbebafeca || magic==0xbfbafeca;
        const auto count=(uint32)(bigEndian?stream.readIntBigEndian():stream.readInt());
        const int entrySize=fat64?32:20;
        if(count==0 || count>128 || (int64)count*entrySize>stream.getTotalLength()-8)
            return "Universal Mach-O architecture table is invalid or truncated";
        bool found=false;
        for(uint32 i=0;i<count;++i)
        {
            const auto cpu=(uint32)(bigEndian?stream.readIntBigEndian():stream.readInt());
            found=found || cpu==wantedCpu;
            stream.skipNextBytes(entrySize-4);
        }
        return found?String():String(mismatch);
    }
    // Let the format loader diagnose files that do not have a Mach-O header.
    return {};
}

juce::File macPluginExecutable(const juce::File& bundle);
#endif

inline juce::String pluginBinaryProblem(const juce::String& identifier)
{
    using namespace juce;
    if(!File::isAbsolutePath(identifier))return {};
    File candidate(identifier);if(!candidate.exists())return "Plug-in file is missing";
#if JUCE_MAC
    if(candidate.isDirectory())
    {
        candidate=macPluginExecutable(candidate);
        if(!candidate.existsAsFile())return "Cannot find the plug-in bundle executable (CFBundleExecutable)";
    }
    FileInputStream stream(candidate);if(!stream.openedOk())return "Cannot read the plug-in binary";
    return macBinaryProblemForCpu(stream,macHostCpu());
#elif JUCE_WINDOWS
    if(candidate.isDirectory())
    {
        auto files=candidate.getChildFile("Contents/x86_64-win").findChildFiles(File::findFiles,false,"*.vst3");
        if(files.isEmpty())return "VST3 bundle has no x64 Windows module";candidate=files[0];
    }
    FileInputStream stream(candidate);if(!stream.openedOk())return "Cannot read the plug-in binary";
    if((uint16)stream.readShort()==0x5a4d)
    {
        stream.setPosition(0x3c);auto offset=(uint32)stream.readInt();
        if(offset<stream.getTotalLength()-6){stream.setPosition(offset);if((uint32)stream.readInt()==0x4550 && (uint16)stream.readShort()!=0x8664)return "32-bit / ARM plug-in: this host requires Windows x64 plug-ins";}
    }
#endif
    return {};
}
