// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include <JuceHeader.h>

inline juce::String pluginBinaryProblem(const juce::String& identifier)
{
    using namespace juce;
    if(!File::isAbsolutePath(identifier))return {};
    File candidate(identifier);if(!candidate.exists())return "Plug-in file is missing";
#if JUCE_MAC
    if(candidate.isDirectory())
    {
        auto files=candidate.getChildFile("Contents/MacOS").findChildFiles(File::findFiles,false);
        if(files.isEmpty())return {};candidate=files[0];
    }
    FileInputStream stream(candidate);if(!stream.openedOk())return "Cannot read the plug-in binary";
    auto magic=(uint32)stream.readInt();
    if(magic==0xfeedfacf||magic==0xfeedface)
    {
        const auto cpu=(uint32)stream.readInt();if(cpu!=0x0100000c)return "Intel-only plug-in: install the Apple Silicon / Universal version";
    }
    else if(magic==0xbebafeca||magic==0xbfbafeca)
    {
        const int count=stream.readIntBigEndian();bool arm=false;
        for(int i=0;i<jlimit(0,128,count);++i)
        {
            const auto cpu=(uint32)stream.readIntBigEndian();arm=arm||cpu==0x0100000c;
            // Always read this field even when an earlier slice matches.
            // Each fat_arch entry is 20 bytes; fat_arch_64 is 32 bytes.
            stream.skipNextBytes(magic==0xbfbafeca?28:16);
        }
        if(!arm)return "Intel-only plug-in: install the Apple Silicon / Universal version";
    }
#elif JUCE_WINDOWS
    if(candidate.isDirectory())
    {
        auto files=candidate.getChildFile("Contents/x86_64-win").findChildFiles(File::findFiles,false,"*.vst3");
        if(files.isEmpty())return "VST3 bundle has no x64 Windows module";candidate=files[0];
    }
    FileInputStream stream(candidate);if(!stream.openedOk())return "Cannot read the plug-in binary";
    if((uint16)stream.readShort()==0x5a4d)
    {
        stream.setPosition(0x3c);auto offset=(uint32)stream.readInt();
        if(offset<stream.getTotalLength()-6){stream.setPosition(offset);if((uint32)stream.readInt()==0x4550 && (uint16)stream.readShort()!=0x8664)return "32-bit / ARM plug-in: this host requires Windows x64 plug-ins";}
    }
#endif
    return {};
}
