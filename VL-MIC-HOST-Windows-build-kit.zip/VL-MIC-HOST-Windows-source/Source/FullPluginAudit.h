// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include "Engine.h"
#include "PluginDiscovery.h"

// Timer-driven: always keep the host responsive while a worker is scanning or
// loading a third-party module. Reports are separate from the user's catalog.
class FullPluginAudit final : public juce::Component, private juce::Timer
{
public:
    explicit FullPluginAudit(Engine& e,const juce::String& filter={}):engine(e)
    {
        using namespace juce;
        directory=engine.dataFolder().getChildFile("Full-audit-reports");directory.createDirectory();
        for(auto* format:engine.formats.getFormats())if(format->getName()=="VST"||format->getName()=="VST3")
        {
            PluginLocations paths(engine.dataFolder().getChildFile("plugin-locations.xml"));
            auto found=format->searchPathsForPlugins(paths.forFormat(*format),true,false);found.removeDuplicates(false);
            for(auto id:found)if(filter.isEmpty()||id.containsIgnoreCase(filter))candidates.push_back({format->getName(),id});
        }
        addAndMakeVisible(progress);progress.setMultiLine(true);progress.setReadOnly(true);setSize(840,540);startTimer(100);
    }
    ~FullPluginAudit()override{stopTimer();if(process.isRunning()){process.kill();process.waitForProcessToFinish(2000);}}
    void resized()override{progress.setBounds(getLocalBounds().reduced(12));}
    bool complete=false;
private:
    struct Candidate {juce::String format,identifier;};
    std::vector<Candidate> candidates;juce::OwnedArray<juce::PluginDescription> descriptions;
    Engine& engine;juce::TextEditor progress;juce::ChildProcess process;juce::File directory,job,request,response;
    int index=0,plugin=0;bool waiting=false,auditing=false;double deadline=0;juce::String report;
    void append(const juce::String& line)
    {
        report+=line+"\n";progress.setText(report);progress.moveCaretToEnd();
        directory.getChildFile("Report.txt").replaceWithText(report);
    }
    void launch(bool audit)
    {
        using namespace juce;
        job=directory.getChildFile("Job");job.createDirectory();request=job.getChildFile("request.xml");response=job.getChildFile("response.xml");response.deleteFile();
        if(audit)descriptions[plugin]->createXml()->writeTo(request);
        else {XmlElement xml("SCAN");xml.setAttribute("format",candidates[index].format);xml.setAttribute("identifier",candidates[index].identifier);xml.writeTo(request);}
        auditing=audit;waiting=process.start(StringArray{File::getSpecialLocation(File::currentExecutableFile).getFullPathName(),audit?"--audit-worker":"--scan-worker",request.getFullPathName(),response.getFullPathName()},0);
        deadline=Time::getMillisecondCounterHiRes()+(audit?30000:candidates[index].identifier.containsIgnoreCase("WaveShell")?300000:120000);
        if(!waiting){append("FAIL worker could not start");++index;descriptions.clear();}
    }
    void timerCallback()override
    {
        using namespace juce;
        if(waiting)
        {
            if(process.isRunning()&&Time::getMillisecondCounterHiRes()<deadline)return;
            const bool timeout=process.isRunning();if(timeout){process.kill();process.waitForProcessToFinish(2000);}
            const auto exit=process.getExitCode();waiting=false;
            auto result=XmlDocument::parse(response);
            if(auditing)
            {
                const bool pass=!timeout&&exit==0&&result&&result->getBoolAttribute("loaded")&&result->getBoolAttribute("rendered")&&result->getBoolAttribute("editorCreated")&&result->getBoolAttribute("closed");
                String reason="load, process, editor created, close; native drawing not verified";
                if(!pass)
                {
                    reason=timeout?"timeout / possible license dialog":result?result->getStringAttribute("error"):"worker crashed";
                    if(reason.isEmpty())reason=!result->getBoolAttribute("loaded")?"load failed":!result->getBoolAttribute("rendered")?"non-finite audio output":!result->getBoolAttribute("editorCreated")?"editor creation failed":"GUI / plug-in teardown failed";
                }
                append(String(pass?"PASS ":"FAIL ")+descriptions[plugin]->name+" ["+descriptions[plugin]->pluginFormatName+"] / "+reason);
                ++plugin;
            }
            else
            {
                descriptions.clear();plugin=0;
                if(result)for(auto* xml:result->getChildIterator()){auto d=std::make_unique<PluginDescription>();if(d->loadFromXml(*xml))descriptions.add(d.release());}
                auto reason=timeout?String("timeout"):result&&result->hasAttribute("error")?result->getStringAttribute("error"):descriptions.isEmpty()?String(result?"no compatible classes published":"scanner crashed before publishing"):String();
                if(timeout){auto stage=job.getChildFile("scan-stage.txt").loadFileAsString();if(stage.isNotEmpty())reason+=" / "+stage;}
                append(String(index+1)+"/"+String((int)candidates.size())+" "+candidates[index].identifier+" / "+String(descriptions.size())+" classes"+(reason.isNotEmpty()?" / "+reason:String()));
                if(descriptions.isEmpty())++index;
            }
            job.deleteRecursively();
        }
        if(index>=(int)candidates.size()){append("AUDIT COMPLETE");complete=true;stopTimer();return;}
        if(!descriptions.isEmpty())
        {
            if(plugin<descriptions.size()){launch(true);return;}
            descriptions.clear();++index;
            if(index>=(int)candidates.size()){append("AUDIT COMPLETE");complete=true;stopTimer();return;}
        }
        launch(false);
    }
};
