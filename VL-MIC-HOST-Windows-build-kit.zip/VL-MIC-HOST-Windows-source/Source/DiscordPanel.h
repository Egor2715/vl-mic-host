// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include "Engine.h"

class DiscordPanel final : public juce::Component, private juce::Timer
{
public:
    explicit DiscordPanel(Engine& e):engine(e)
    {
        title.setText("DISCORD / VIRTUAL MIC",juce::dontSendNotification);
        title.setFont(juce::FontOptions(23.0f,juce::Font::bold));title.setColour(juce::Label::textColourId,juce::Colour(0xff91e4d2));
        addAndMakeVisible(title);addAndMakeVisible(destinations);
        destinations.setName("Discord virtual microphone output");
        destinations.setTextWhenNothingSelected("Install a virtual cable, then Refresh");
        destinations.onChange=[this]{updateMessage();};
        channels.addItem("Mono for Discord",1);channels.addItem("Stereo for OBS / recording",2);
        channels.setSelectedId(engine.virtualMic.buffer.mono?1:2,juce::dontSendNotification);
        channels.onChange=[this]{engine.virtualMic.buffer.mono=channels.getSelectedId()==1;save();};addAndMakeVisible(channels);
        refresh.setButtonText("Refresh");refresh.onClick=[this]{scan();};addAndMakeVisible(refresh);
        connect.setButtonText("Connect");connect.onClick=[this]{
            const int index=destinations.getSelectedId()-1;
            if(!juce::isPositiveAndBelow(index,available.size())){message="Install BlackHole 2ch (Mac) or VB-CABLE (Windows), then Refresh.";return;}
            auto hardware=engine.devices.getAudioDeviceSetup();
            auto error=engine.virtualMic.open(available[index],hardware.outputDeviceName,hardware.inputDeviceName);
            message=error.isEmpty()?"Connected. Press START AUDIO in the mixer, then test your microphone in Discord.":error;
            save();
        };addAndMakeVisible(connect);
        disconnect.setButtonText("Disconnect");disconnect.onClick=[this]{engine.virtualMic.close();save();message="Virtual microphone disconnected. Hardware monitoring is unchanged.";};addAndMakeVisible(disconnect);
        download.setButtonText("Get virtual cable");download.onClick=[]{
#if JUCE_MAC
            juce::URL("https://existential.audio/blackhole/").launchInDefaultBrowser();
#else
            juce::URL("https://vb-audio.com/Cable/").launchInDefaultBrowser();
#endif
        };addAndMakeVisible(download);
        guide.setMultiLine(true);guide.setReadOnly(true);guide.setCaretVisible(false);
        guide.setText(
            "1. Install BlackHole 2ch on Mac or VB-CABLE on Windows. The cable driver is installed separately. Restart if its installer asks.\n\n"
            "2. In VL Audio setup keep your microphone / interface as INPUT and your headphones / interface as OUTPUT. Windows: ASIO remains available for the main interface.\n\n"
            "3. Choose the virtual output above and press Connect, then START AUDIO in the mixer. The processed MIC, CHANNEL 2 and FX mix is sent before MUTE MONITORING.\n\n"
            "4. Discord > User Settings > Voice & Video:\n"
            "   Mac Input Device: BlackHole 2ch.\n"
            "   Windows Input Device: CABLE Output (VB-Audio Virtual Cable).\n"
            "   Output Device: your headphones / interface. Do not choose the virtual cable for Discord's output.\n\n"
            "5. Run Discord's Mic Test. If Discord removes your reverb or instruments, use Custom audio processing and try turning off noise suppression / Krisp, echo cancellation and automatic gain control. Adjust input sensitivity if notes are cut off. Use headphones to avoid acoustic feedback.\n\n"
            "MUTE MONITORING: only your own headphone monitoring is muted.\n"
            "MUTE MIC / MUTE CH 2: the corresponding mixer channel is muted in Discord too.\n"
            "STOP AUDIO: all processed audio sent to Discord stops.\n\n"
            "No aggregate device is required. Keep system playback and Discord output on your physical headphones so other voices are not sent back. Mono for Discord sends the complete mix to both cable channels; Stereo is available for recording.\n\n"
            "Discord can apply its own processing or mono voice transmission. This feature does not bypass Discord's settings or network latency.");
        addAndMakeVisible(guide);scan();setSize(740,680);startTimerHz(12);
    }
    ~DiscordPanel() override {stopTimer();}
    void paint(juce::Graphics& g) override
    {
        g.fillAll(juce::Colour(0xff0c1119));
        g.setColour(engine.virtualMic.connected?juce::Colour(0xff91e4d2):juce::Colour(0xffa2adbc));g.setFont(13.0f);
        auto info=engine.virtualMic.connected?"Connected: "+engine.virtualMic.name()+" / "+juce::String(engine.virtualMic.rate()/1000,1)+" kHz":"Virtual microphone off";
        g.drawText(info,24,151,692,22,juce::Justification::centredLeft);
        g.drawText(message,24,177,692,34,juce::Justification::centredLeft);
        g.setColour(juce::Colour(0xff243242));g.fillRoundedRectangle(24,218,692,6,3);
        g.setColour(juce::Colour(0xff91e4d2));g.fillRoundedRectangle(24,218,juce::jmax(1.0f,692*juce::jlimit(0.0f,1.0f,(juce::Decibels::gainToDecibels(level,-60.0f)+60)/60)),6,3);
    }
    void resized() override
    {
        title.setBounds(20,16,getWidth()-40,38);destinations.setBounds(24,62,getWidth()-160,32);refresh.setBounds(getWidth()-124,62,100,32);
        channels.setBounds(24,106,254,32);connect.setBounds(290,106,102,32);disconnect.setBounds(402,106,110,32);download.setBounds(524,106,getWidth()-548,32);
        guide.setBounds(24,239,getWidth()-48,getHeight()-263);
    }
private:
    Engine& engine;
    juce::Label title;juce::ComboBox destinations,channels;
    juce::TextButton refresh,connect,disconnect,download;juce::TextEditor guide;
    juce::Array<VirtualMicOutput::Destination> available;
    juce::String message;float level=0;
    void save(){engine.virtualMic.save(engine.dataFolder().getChildFile("virtual-mic.xml"));}
    void updateMessage()
    {
        const int index=destinations.getSelectedId()-1;
        if(juce::isPositiveAndBelow(index,available.size()))
            message="Discord INPUT: "+VirtualMicOutput::inputName(available[index].name);
    }
    void scan()
    {
        auto old=destinations.getText();available=engine.virtualMic.destinations();destinations.clear(juce::dontSendNotification);
        int id=0;
        for(int i=0;i<available.size();++i)
        {
            destinations.addItem(available[i].name,i+1);
            if(available[i].name==engine.virtualMic.name()||available[i].name==old)id=i+1;
        }
        if(id==0 && !available.isEmpty())id=1;
        destinations.setSelectedId(id,juce::dontSendNotification);
        connect.setEnabled(id>0);
        message=id==0?"No virtual cable found. Get virtual cable, install it, then press Refresh.":"Select a cable and press Connect.";
        if(id>0)updateMessage();
    }
    void timerCallback() override
    {
        level=juce::jmax(engine.virtualMic.buffer.peak.exchange(0),level*.85f);
        disconnect.setEnabled(engine.virtualMic.connected.load());
        if(engine.virtualMic.connected && !engine.virtualMic.isOpen())
        {engine.virtualMic.close();message="Virtual device disconnected. Reconnect it, then Refresh and Connect.";}
        repaint();
    }
};
