// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include <JuceHeader.h>
#include <array>

// One hardware callback produces; one virtual-device callback consumes.
// Storage is fixed. Independent device clocks are bridged without blocking DSP.
class VirtualMicBuffer final
{
public:
    static constexpr int capacity = 32768;
    VirtualMicBuffer() : samples(2, capacity) { samples.clear(); }
    void setSourceRate(double rate) noexcept
    {
        const auto valid = std::isfinite(rate) && rate >= 8000 && rate <= 384000 ? rate : 48000.0;
        if (sourceRate.exchange(valid) != valid) generation.fetch_add(1);
    }
    void setEnabled(bool value) noexcept
    {
        if (enabled.exchange(value) != value) generation.fetch_add(1);
    }
    bool isEnabled() const noexcept { return enabled.load(); }
    void invalidate() noexcept { generation.fetch_add(1); }
    void push(const float* left, const float* right, int count) noexcept
    {
        if (!enabled.load() || count <= 0) return;
        const auto w = write.load(std::memory_order_relaxed);
        const auto r = read.load(std::memory_order_acquire);
        if (count > capacity - 1 || w - r + (uint64_t)count >= capacity)
        {
            overruns.fetch_add(1); generation.fetch_add(1); return;
        }
        for (int i = 0; i < count; ++i)
        {
            const auto slot = (int)((w + (uint64_t)i) % capacity);
            const float l = std::isfinite(left[i]) ? left[i] : 0.0f;
            const float rSample = std::isfinite(right[i]) ? right[i] : 0.0f;
            samples.setSample(0, slot, l); samples.setSample(1, slot, rSample);
        }
        write.store(w + (uint64_t)count, std::memory_order_release);
    }
    void render(float* const* output, int channels, int count, double destinationRate) noexcept
    {
        const auto clearOutput=[&]() noexcept
        {
            for (int c = 0; c < channels; ++c) if (output[c])
                for (int i = 0; i < count; ++i) output[c][i] = 0.0f;
        };
        clearOutput();
        auto r = read.load(std::memory_order_relaxed);
        const auto w = write.load(std::memory_order_acquire);
        const auto epoch = generation.load();
        if (!enabled.load() || epoch != observedGeneration || !std::isfinite(destinationRate) || destinationRate <= 0)
        {
            read.store(w, std::memory_order_release);
            observedGeneration = epoch; primed = false; phase = 0; fade = 0; previous = {}; correction = 0;
            return;
        }
        const double src = sourceRate.load(), nominal = src / destinationRate;
        const int needed = (int)std::ceil(count * nominal) + 4;
        const int target = juce::jlimit(8, capacity / 2, juce::jmax((int)std::ceil(src * .012), needed * 2));
        if (!primed)
        {
            if (w - r < (uint64_t)target) return;
            primed = true; phase = 0; fade = 0;
            for (int c = 0; c < 2; ++c) previous[c] = samples.getSample(c, (int)(r % capacity));
        }
        // Smooth a bounded rate correction instead of dropping samples as clocks drift.
        const auto desired = juce::jlimit(-.005, .005, ((double)(w - r) - target) / src * .1);
        correction += .02 * (desired - correction);
        const double step = nominal * (1.0 + correction);
        float blockPeak = 0;
        for (int i = 0; i < count; ++i)
        {
            const int consumed = (int)std::floor(phase + step);
            if (w - r < (uint64_t)juce::jmax(3, consumed + 2))
            {
                underruns.fetch_add(1); primed = false; phase = 0; fade = 0; break;
            }
            float value[2];
            fade = juce::jmin(1.0f, fade + (float)(1.0 / (destinationRate * .002)));
            for (int c = 0; c < 2; ++c)
            {
                const float a = previous[c], b = samples.getSample(c, (int)(r % capacity));
                const float d = samples.getSample(c, (int)((r + 1) % capacity));
                const float e = samples.getSample(c, (int)((r + 2) % capacity));
                // Cubic interpolation; unity rate retains the original samples.
                value[c] = (float)(b + .5 * phase * (d - a + phase * (2*a - 5*b + 4*d - e + phase * (3*(b-d) + e-a)))) * fade;
                if (!std::isfinite(value[c])) value[c] = 0;
            }
            const float chat = .5f * (value[0] + value[1]);
            for (int c = 0; c < juce::jmin(2, channels); ++c) if (output[c])
            {
                const auto sample = mono.load() || channels == 1 ? chat : value[c];
                output[c][i] = sample;
                blockPeak = juce::jmax(blockPeak, std::abs(sample));
            }
            phase += step;
            if (consumed > 0)
            {
                for (int c = 0; c < 2; ++c) previous[c] = samples.getSample(c, (int)((r + consumed - 1) % capacity));
                r += (uint64_t)consumed; phase -= consumed;
            }
        }
        read.store(r, std::memory_order_release);
        // STOP AUDIO can arrive while this independent device callback is
        // rendering. Never let the remainder of an in-flight block leak into
        // Discord after the route has been disabled or reset.
        const auto finalGeneration=generation.load();
        if (!enabled.load() || finalGeneration != epoch)
        {
            clearOutput();
            read.store(write.load(std::memory_order_acquire),std::memory_order_release);
            observedGeneration=finalGeneration;primed=false;phase=0;fade=0;previous={};correction=0;
            return;
        }
        peak.store(juce::jmax(peak.load(), blockPeak));
    }
    int bufferedSamples() const noexcept { return (int)(write.load() - read.load()); }
    std::atomic<bool> mono {true};
    std::atomic<float> peak {0};
    std::atomic<int> underruns {0}, overruns {0};
private:
    juce::AudioBuffer<float> samples;
    std::atomic<uint64_t> read {0}, write {0}, generation {0};
    std::atomic<double> sourceRate {48000};
    std::atomic<bool> enabled {false};
    uint64_t observedGeneration = 0;
    bool primed = false;
    double phase = 0, correction = 0;
    float fade = 0;
    std::array<float,2> previous {};
};

class VirtualMicOutput final : private juce::AudioIODeviceCallback
{
public:
    struct Destination { juce::String type, name; };
    VirtualMicBuffer buffer;
    std::atomic<bool> connected {false};
    VirtualMicOutput();
    ~VirtualMicOutput() override { close(); }
    juce::Array<Destination> destinations();
    juce::String open(const Destination&, const juce::String& hardwareOutput, const juce::String& hardwareInput = {});
    void close();
    bool isOpen() const { return device && device->isOpen() && device->isPlaying(); }
    juce::String name() const { return device ? device->getName() : juce::String{}; }
    juce::String error() const { return device ? device->getLastError() : juce::String{}; }
    double rate() const { return outputRate.load(); }
    static bool isVirtualName(const juce::String&);
    static juce::String inputName(const juce::String& output);
    void save(const juce::File&);
    juce::String restore(const juce::File&, const juce::String& hardwareOutput, const juce::String& hardwareInput = {});
private:
    juce::OwnedArray<juce::AudioIODeviceType> types;
    std::unique_ptr<juce::AudioIODevice> device;
    Destination selected;
    std::atomic<double> outputRate {48000};
    void audioDeviceAboutToStart(juce::AudioIODevice* d) override { buffer.invalidate();outputRate=d->getCurrentSampleRate();connected=true; }
    void audioDeviceStopped() override { connected=false;buffer.setEnabled(false); }
    void audioDeviceIOCallbackWithContext(const float* const*, int, float* const* out, int channels, int n,
                                         const juce::AudioIODeviceCallbackContext&) override
    { buffer.render(out,channels,n,outputRate.load()); }
};
