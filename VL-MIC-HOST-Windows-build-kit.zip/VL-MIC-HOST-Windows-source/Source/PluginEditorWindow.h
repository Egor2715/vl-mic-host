// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include <JuceHeader.h>

// Native AU/VST views must not inherit JUCE's asynchronous, layer-backed
// CoreGraphics peer. In particular, some Waves editors can otherwise stay white.
// Create the peer after construction so our style flags apply from the start.
class PluginEditorWindow final : public juce::DocumentWindow
{
public:
    PluginEditorWindow(juce::String title, juce::AudioProcessorEditor* editor,
                       bool compatibleRendering = true)
        : DocumentWindow(title, juce::Colours::black, closeButton, false),
          synchronousRendering(compatibleRendering)
    {
        setUsingNativeTitleBar(true);
        if(editor->getWidth() <= 1 || editor->getHeight() <= 1)
            editor->setSize(640,480);
        setContentOwned(editor,true);
        setResizable(editor->isResizable(),false);
        centreWithSize(editor->getWidth(),editor->getHeight());
        addToDesktop(getDesktopWindowStyleFlags());
        setVisible(true);
        toFront(true);
    }

    void closeButtonPressed() override
    {
        setVisible(false);
        // Release the native view/GPU resources, not the processor or its state.
        // The GUI button creates a fresh editor on the next open.
        clearContentComponent();
    }

    bool usesCompatibleRendering() const
    {
       #if JUCE_MAC
        return getPeer() != nullptr &&
            (getPeer()->getStyleFlags() & juce::ComponentPeer::windowRequiresSynchronousCoreGraphicsRendering) != 0;
       #else
        return true;
       #endif
    }

private:
    int getDesktopWindowStyleFlags() const override
    {
        auto flags=DocumentWindow::getDesktopWindowStyleFlags();
       #if JUCE_MAC
        if(synchronousRendering)
            flags |= juce::ComponentPeer::windowRequiresSynchronousCoreGraphicsRendering;
       #endif
        return flags;
    }
    bool synchronousRendering;
};
