// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include "Engine.h"
#include "PluginIdentity.h"

inline juce::String validateShellPlugin(const juce::File& fixture)
{
    using namespace juce;
    String report;auto check=[&](bool ok,const String& label){report+=(ok?"PASS ":"FAIL ")+label+"\n";};
    check(fixture.exists(),"Reordering VST3 shell fixture is present");
    if(!fixture.exists())return report;
    // These are stable class IDs, equivalent to cached moduleinfo.json metadata.
    // Do not scan the fixture first: the regression occurs on a cold factory.
    auto describe=[&](int id,const String& name){
        PluginDescription d;d.name=d.descriptiveName=name;d.manufacturerName="VL test fixture";
        d.pluginFormatName="VST3";d.fileOrIdentifier=fixture.getFullPathName();d.category="Fx";
        uint32 hash=0;for(uint32 word:{0x564c5445u,0x53545348u,0x454c4c00u,(uint32)id})hash=hash*31+word;
        d.uniqueId=(int)hash;return d;
    };
    const auto mono=describe(1,"VL Fixture Mono"),stereo=describe(2,"VL Fixture Stereo");
    for(auto d:{mono,stereo})
    {
        Engine e;e.prepare(48000,64);auto error=e.load(0,d);
        check(error.isEmpty(),"Cold shell selects exact class "+d.name+": "+error);
        if(error.isNotEmpty())continue;
        const int channels=d.uniqueId==mono.uniqueId?1:2;
        check(e.slots[0].plugin->getName()==d.name && e.slots[0].plugin->getTotalNumInputChannels()==channels,
              "Selected class name and native channel count agree: "+d.name);
        e.live=true;AudioBuffer<float> input(1,64),output(2,64);
        for(int n=0;n<64;++n)input.setSample(0,n,0.125f);
        e.process(input.getArrayOfReadPointers(),1,output.getArrayOfWritePointers(),2,64);
        const float expected=channels==1?0.25f:0.375f;
        check(std::abs(output.getSample(0,63)-expected)<0.00001f && std::abs(output.getSample(1,63)-expected)<0.00001f,
              "Audio is processed by selected shell class: "+d.name);
        auto preset=e.preset();e.remove(0);error=e.restore(*preset);
        check(error.isEmpty() && e.slots[0].plugin && e.slots[0].plugin->getName()==d.name,
              "Preset recalls the same shell class: "+d.name+": "+error);
    }
    auto wrong=describe(3,"VL Fixture Surround 6.1");
    check(pluginIdentityProblem(mono,wrong).isNotEmpty(),"Wrong surround class is rejected by identity guard");
    wrong=mono;wrong.uniqueId=stereo.uniqueId;
    check(pluginIdentityProblem(mono,wrong).isNotEmpty(),"Same name with a different class ID is rejected");
    check(pluginIdentityProblem(mono,mono).isEmpty(),"Exact class identity is accepted");
    return report;
}
