// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 VL MIC HOST contributors

#pragma once
#include <JuceHeader.h>

// Deterministic processor used only by Diagnostics to test mixer routing.
class TestEffect final : public juce::AudioPluginInstance
{
public:
    TestEffect(int delay=3, float amount=2):AudioPluginInstance(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true).withOutput("Output",juce::AudioChannelSet::stereo(),true)){buffer.setSize(2,delay);setLatencySamples(delay);multiplier=amount;}
    const juce::String getName() const override{return "VL mixer test";}
    void fillInPluginDescription(juce::PluginDescription& d)const override{d.name=getName();}
    void prepareToPlay(double,int)override{buffer.clear();position=0;}
    void releaseResources()override{}
    void processBlock(juce::AudioBuffer<float>& b,juce::MidiBuffer&)override
    {
        for(int n=0;n<b.getNumSamples();++n){for(int c=0;c<2;++c){float v=b.getSample(c,n);b.setSample(c,n,multiplier*buffer.getSample(c,position));buffer.setSample(c,position,v);}position=(position+1)%buffer.getNumSamples();}
    }
    bool acceptsMidi()const override{return false;}bool producesMidi()const override{return false;}
    double getTailLengthSeconds()const override{return 0;}
    bool hasEditor()const override{return false;}juce::AudioProcessorEditor* createEditor()override{return nullptr;}
    int getNumPrograms()override{return 1;}int getCurrentProgram()override{return 0;}void setCurrentProgram(int)override{}
    const juce::String getProgramName(int)override{return {};}
    void changeProgramName(int,const juce::String&)override{}
    void getStateInformation(juce::MemoryBlock&)override{}void setStateInformation(const void*,int)override{}
private:
    juce::AudioBuffer<float> buffer{2,3};int position=0;float multiplier=2;
};

// Models fixed speaker sets and mandatory sidechains rather than just counts.
// The active-layout guard reproduces the VST3 lifecycle rule on every platform.
class TestBusEffect final : public juce::AudioPluginInstance
{
public:
    TestBusEffect(juce::AudioChannelSet input,juce::AudioChannelSet output,int sidechain=0,
                  bool optional=false,bool enabled=true,int extraOutputs=0,bool changeOnPrepare=false)
        :AudioPluginInstance(properties(input,output,sidechain,enabled,extraOutputs)),
         fixedInput(input),fixedOutput(output),sidechainChannels(sidechain),optionalSidechain(optional),
         activationChangesLayout(changeOnPrepare) {}
    bool active=true,sidechainSilent=true;
    int releaseCount=0;
    const juce::String getName()const override{return "VL bus compatibility test";}
    void fillInPluginDescription(juce::PluginDescription& d)const override{d.name=getName();}
    bool isBusesLayoutSupported(const BusesLayout& layout)const override
    {
        if(layout.getMainInputChannelSet()!=fixedInput||layout.getMainOutputChannelSet()!=fixedOutput)return false;
        if(sidechainChannels>0)
        {
            const auto sc=layout.getChannelSet(true,1);
            if(sc.size()!=sidechainChannels&&!(optionalSidechain&&sc.isDisabled()))return false;
        }
        return true;
    }
    bool canApplyBusesLayout(const BusesLayout& layout)const override{return !active&&isBusesLayoutSupported(layout);}
    void prepareToPlay(double,int)override
    {
        if(activationChangesLayout)
        {
            auto layout=getBusesLayout();fixedOutput=juce::AudioChannelSet::create5point1();
            layout.outputBuses.getReference(0)=fixedOutput;setBusesLayout(layout);
        }
        active=true;sidechainSilent=true;
    }
    void releaseResources()override{active=false;++releaseCount;}
    void processBlock(juce::AudioBuffer<float>& b,juce::MidiBuffer&)override
    {
        const int inputs=getMainBusNumInputChannels(),outputs=getMainBusNumOutputChannels();
        for(int c=inputs;c<getTotalNumInputChannels();++c)
            sidechainSilent=sidechainSilent&&b.getMagnitude(c,0,b.getNumSamples())==0;
        for(int n=0;n<b.getNumSamples();++n)
        {
            float value=b.getSample(0,n);
            if(inputs==2)value=(value+b.getSample(1,n))*.5f;
            for(int c=0;c<outputs;++c)b.setSample(c,n,value*2);
        }
    }
    bool acceptsMidi()const override{return false;}bool producesMidi()const override{return false;}
    double getTailLengthSeconds()const override{return 0;}bool hasEditor()const override{return false;}
    juce::AudioProcessorEditor* createEditor()override{return nullptr;}
    int getNumPrograms()override{return 1;}int getCurrentProgram()override{return 0;}void setCurrentProgram(int)override{}
    const juce::String getProgramName(int)override{return {};}
    void changeProgramName(int,const juce::String&)override{}
    void getStateInformation(juce::MemoryBlock&)override{}void setStateInformation(const void*,int)override{}
private:
    static BusesProperties properties(juce::AudioChannelSet in,juce::AudioChannelSet out,int sc,bool enabled,int extra)
    {
        auto result=BusesProperties().withInput("Input",in,enabled).withOutput("Output",out,enabled);
        if(sc>0)result=result.withInput("Sidechain",juce::AudioChannelSet::canonicalChannelSet(sc),enabled);
        if(extra>0)result=result.withOutput("Aux",juce::AudioChannelSet::discreteChannels(extra),true);
        return result;
    }
    juce::AudioChannelSet fixedInput,fixedOutput;
    int sidechainChannels=0;bool optionalSidechain=false,activationChangesLayout=false;
};

// Synthetic instrument: no external libraries or hardware needed for MIDI tests.
class TestInstrument final : public juce::AudioPluginInstance
{
public:
    TestInstrument():AudioPluginInstance(BusesProperties().withOutput("Output",juce::AudioChannelSet::stereo(),true)){}
    bool sounding=false,sustain=false;int lastPitch=8192;
    const juce::String getName()const override{return "VL MIDI test";}
    void fillInPluginDescription(juce::PluginDescription& d)const override{d.name=getName();d.isInstrument=true;}
    void prepareToPlay(double,int)override{sounding=false;sustain=false;}
    void releaseResources()override{}
    bool isBusesLayoutSupported(const BusesLayout& layout)const override{return layout.getMainOutputChannelSet()==juce::AudioChannelSet::stereo();}
    void processBlock(juce::AudioBuffer<float>& b,juce::MidiBuffer& midi)override
    {
        auto it=midi.begin();
        for(int n=0;n<b.getNumSamples();++n)
        {
            while(it!=midi.end() && (*it).samplePosition<=n)
            {
                auto m=(*it).getMessage();
                if(m.isNoteOn())sounding=true;
                if(m.isNoteOff() && !sustain)sounding=false;
                if(m.isController() && m.getControllerNumber()==64){sustain=m.getControllerValue()>=64;if(!sustain)sounding=false;}
                if(m.isAllNotesOff()||m.isAllSoundOff())sounding=false;
                if(m.isPitchWheel())lastPitch=m.getPitchWheelValue();
                ++it;
            }
            for(int c=0;c<b.getNumChannels();++c)b.setSample(c,n,sounding?0.15f:0);
        }
    }
    bool acceptsMidi()const override{return true;}bool producesMidi()const override{return false;}
    double getTailLengthSeconds()const override{return 0;}
    bool hasEditor()const override{return false;}juce::AudioProcessorEditor* createEditor()override{return nullptr;}
    int getNumPrograms()override{return 1;}int getCurrentProgram()override{return 0;}void setCurrentProgram(int)override{}
    const juce::String getProgramName(int)override{return {};}
    void changeProgramName(int,const juce::String&)override{}
    void getStateInformation(juce::MemoryBlock&)override{}void setStateInformation(const void*,int)override{}
};
