// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 VL MIC HOST contributors

#pragma once
#include <JuceHeader.h>

// Deterministic processor used only by Diagnostics to test mixer routing.
class TestEffect final : public juce::AudioPluginInstance
{
public:
    TestEffect():AudioPluginInstance(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true).withOutput("Output",juce::AudioChannelSet::stereo(),true)){setLatencySamples(3);}
    const juce::String getName() const override{return "VL mixer test";}
    void fillInPluginDescription(juce::PluginDescription& d)const override{d.name=getName();}
    void prepareToPlay(double,int)override{buffer.clear();position=0;}
    void releaseResources()override{}
    void processBlock(juce::AudioBuffer<float>& b,juce::MidiBuffer&)override
    {
        for(int n=0;n<b.getNumSamples();++n){for(int c=0;c<2;++c){float v=b.getSample(c,n);b.setSample(c,n,2*buffer.getSample(c,position));buffer.setSample(c,position,v);}position=(position+1)%3;}
    }
    bool acceptsMidi()const override{return false;}bool producesMidi()const override{return false;}
    double getTailLengthSeconds()const override{return 0;}
    bool hasEditor()const override{return false;}juce::AudioProcessorEditor* createEditor()override{return nullptr;}
    int getNumPrograms()override{return 1;}int getCurrentProgram()override{return 0;}void setCurrentProgram(int)override{}
    const juce::String getProgramName(int)override{return {};}
    void changeProgramName(int,const juce::String&)override{}
    void getStateInformation(juce::MemoryBlock&)override{}void setStateInformation(const void*,int)override{}
private:
    juce::AudioBuffer<float> buffer{2,3};int position=0;
};
