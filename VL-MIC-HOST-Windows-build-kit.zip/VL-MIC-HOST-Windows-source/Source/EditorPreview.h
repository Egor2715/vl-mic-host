// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include "Engine.h"
#include "PluginEditorWindow.h"

#if defined(VL_HOST_VALIDATION)
// A single isolated host for visual testing. Does not open an audio device or
// edit the user's presets/catalog. Native pixels are verified separately via UI.
class EditorPreview final : public juce::Component
{
public:
    explicit EditorPreview(const juce::XmlElement& xml)
    {
        for(auto* child:xml.getChildIterator())
        {
            juce::PluginDescription d;
            if(d.loadFromXml(*child))descriptions.add(d);
        }
        for(int i=0;i<descriptions.size();++i)
            choices.addItem(descriptions[i].name+" ["+descriptions[i].pluginFormatName+"]",i+1);
        choices.onChange=[this]{load();};addAndMakeVisible(choices);
        next.setButtonText("Next plug-in");next.onClick=[this]{choices.setSelectedId(choices.getSelectedId()%descriptions.size()+1);};addAndMakeVisible(next);
        open.setButtonText("Open / recreate GUI");open.onClick=[this]{showEditor();};addAndMakeVisible(open);
        close.setButtonText("Close GUI");close.onClick=[this]{if(window)window->closeButtonPressed();};addAndMakeVisible(close);
        legacy.setButtonText("Compare old asynchronous renderer");legacy.onClick=[this]{showEditor();};addAndMakeVisible(legacy);
        report.setMultiLine(true);report.setReadOnly(true);addAndMakeVisible(report);
        setSize(720,180);choices.setSelectedId(1);
    }
    ~EditorPreview() override {window.reset();}
    void resized() override
    {
        choices.setBounds(12,12,getWidth()-156,28);next.setBounds(getWidth()-134,12,122,28);
        open.setBounds(12,50,190,30);close.setBounds(212,50,110,30);
        legacy.setBounds(332,50,370,30);report.setBounds(12,90,getWidth()-24,getHeight()-102);
    }
private:
    Engine engine;
    juce::Array<juce::PluginDescription> descriptions;
    juce::ComboBox choices;
    juce::TextButton open,close,next;
    juce::ToggleButton legacy;
    juce::TextEditor report;
    std::unique_ptr<PluginEditorWindow> window;
    void load()
    {
        window.reset();auto i=choices.getSelectedId()-1;if(i<0)return;
        auto error=engine.load(0,descriptions[i]);
        report.setText(error.isEmpty()?"Loaded. Audio device remains closed.":error);
        if(error.isEmpty())showEditor();
    }
    void showEditor()
    {
        window.reset();auto* p=engine.slots[0].plugin.get();if(!p)return;
        auto* editor=p->createEditorIfNeeded();if(!editor){report.setText("No native editor");return;}
        window=std::make_unique<PluginEditorWindow>("VL / GUI check / "+p->getName(),editor,!legacy.getToggleState());
        auto text=p->getName()+" / "+choices.getText()+"\nPeer: "+
            juce::String(window->usesCompatibleRendering()?"synchronous compatible":"legacy asynchronous")+
            " / "+juce::String(editor->getWidth())+" x "+juce::String(editor->getHeight())+
            "\nNative editor showing: "+juce::String(editor->isShowing()?"yes":"no")+
            ". Pixel rendering requires visual inspection.";
        report.setText(text);engine.dataFolder().getChildFile("editor-preview-report.txt").replaceWithText(text);
    }
};
#endif
