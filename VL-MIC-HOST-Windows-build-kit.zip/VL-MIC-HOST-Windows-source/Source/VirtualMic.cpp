// SPDX-License-Identifier: AGPL-3.0-only
#include "VirtualMic.h"
using namespace juce;

VirtualMicOutput::VirtualMicOutput()
{
#if JUCE_MAC
    if (auto* type=AudioIODeviceType::createAudioIODeviceType_CoreAudio()) types.add(type);
#elif JUCE_WINDOWS
    // Shared WASAPI remains available while the main interface uses ASIO.
    if (auto* type=AudioIODeviceType::createAudioIODeviceType_WASAPI(WASAPIDeviceMode::shared)) types.add(type);
#endif
}
bool VirtualMicOutput::isVirtualName(const String& name)
{
    return name.containsIgnoreCase("BlackHole") || name.containsIgnoreCase("VB-Audio")
        || name.containsIgnoreCase("CABLE Input") || name.containsIgnoreCase("CABLE-A Input")
        || name.containsIgnoreCase("CABLE-B Input") || name.containsIgnoreCase("CABLE-C Input")
        || name.containsIgnoreCase("CABLE-D Input") || name.containsIgnoreCase("Voicemeeter")
        || name.containsIgnoreCase("Loopback") || name.containsIgnoreCase("VL Virtual Mic");
}
String VirtualMicOutput::inputName(const String& output)
{
    if (output.containsIgnoreCase("CABLE") && output.containsIgnoreCase("Input"))
        return output.replace("Input","Output",true);
    if (output.containsIgnoreCase("Voicemeeter"))
        return "The matching Voicemeeter Output (recording device)";
    return output;
}
Array<VirtualMicOutput::Destination> VirtualMicOutput::destinations()
{
    Array<Destination> result;
    for (auto* type:types)
    {
        type->scanForDevices();
        for (const auto& name:type->getDeviceNames(false)) if(isVirtualName(name)) result.add({type->getTypeName(),name});
    }
    return result;
}
void VirtualMicOutput::close()
{
    connected=false;buffer.setEnabled(false);
    if(device){device->stop();device->close();device.reset();}
    selected={};
}
String VirtualMicOutput::open(const Destination& target,const String& hardwareOutput,const String& hardwareInput)
{
    if(!isVirtualName(target.name))return "Choose a virtual audio cable output, such as BlackHole 2ch or CABLE Input.";
    if(target.name==hardwareOutput)return "Use your audio interface for MONITOR / Audio setup, then choose a separate virtual cable for Discord.";
    if(target.name==hardwareInput || inputName(target.name)==hardwareInput)return "Choose your physical microphone in Audio setup. Feeding this cable back into VL would create an audio loop.";
    close();
    for(auto* type:types) if(type->getTypeName()==target.type)
    {
        type->scanForDevices();
        // Do not let a stale saved device name fall back to any default endpoint.
        if(!type->getDeviceNames(false).contains(target.name))break;
        device.reset(type->createDevice(target.name,{}));
        if(!device)break;
        auto rates=device->getAvailableSampleRates();
        double wanted=48000;
        if(!rates.isEmpty() && !rates.contains(wanted))wanted=rates[0];
        BigInteger output;output.setRange(0,jmin(2,device->getOutputChannelNames().size()),true);
        if(output.isZero()){close();return "The virtual device has no available output channels.";}
        auto error=device->open({},output,wanted,device->getDefaultBufferSize());
        if(error.isNotEmpty()){close();return "Could not open the virtual microphone output: "+error;}
        selected=target;device->start(this);
        if(!device->isPlaying()){close();return "The virtual device did not start. Reconnect it and press Refresh.";}
        connected=true;
        return {};
    }
    close();return "Virtual cable not found. Install BlackHole 2ch (Mac) or VB-CABLE (Windows), then press Refresh.";
}
void VirtualMicOutput::save(const File& file)
{
    XmlElement x("VL_VIRTUAL_MIC");x.setAttribute("type",selected.type);x.setAttribute("name",selected.name);x.setAttribute("mono",buffer.mono.load());x.writeTo(file);
}
String VirtualMicOutput::restore(const File& file,const String& hardwareOutput,const String& hardwareInput)
{
    auto x=XmlDocument::parse(file);if(!x||!x->hasTagName("VL_VIRTUAL_MIC"))return {};
    buffer.mono=x->getBoolAttribute("mono",true);
    auto name=x->getStringAttribute("name");if(name.isEmpty())return {};
    return open({x->getStringAttribute("type"),name},hardwareOutput,hardwareInput);
}
