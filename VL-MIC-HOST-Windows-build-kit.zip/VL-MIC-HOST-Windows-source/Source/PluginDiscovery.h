// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include <JuceHeader.h>

inline void forcePluginRescan(juce::KnownPluginList& known)
{
    // JUCE's scan dialog skips unchanged entries even after clearing the blacklist.
    // Invalidate scan metadata, keeping the catalog available if a retry fails.
    for(auto d:known.getTypes())
    {
        d.lastFileModTime=juce::Time(0);d.version.clear();known.addType(d);
    }
    known.clearBlacklistedFiles();known.sendChangeMessage();
}

// Standard format locations plus user-selected folders, never vendor allowlists.
class PluginLocations
{
public:
    explicit PluginLocations(juce::File settings) : file(std::move(settings))
    {
        if(auto xml=juce::XmlDocument::parse(file);xml && xml->hasTagName("VL_PLUGIN_LOCATIONS"))
            for(auto* path:xml->getChildIterator())if(path->hasTagName("VST3"))
            {
                auto value=path->getStringAttribute("path");
                if(juce::File::isAbsolutePath(value))custom.add(juce::File(value));
            }
    }
    bool addVst3Folder(const juce::File& directory)
    {
        if(!directory.isDirectory())return false;
        custom.add(directory);custom.removeRedundantPaths();
        juce::XmlElement xml("VL_PLUGIN_LOCATIONS");
        for(int i=0;i<custom.getNumPaths();++i)xml.createNewChildElement("VST3")->setAttribute("path",custom[i].getFullPathName());
        return xml.writeTo(file);
    }
    juce::FileSearchPath forFormat(juce::AudioPluginFormat& format) const
    {
        auto paths=format.getDefaultLocationsToSearch();
        if(format.getName()=="VST3")
        {
#if JUCE_MAC
            paths.add(juce::File("/Library/Audio/Plug-Ins/VST3"));
            paths.add(juce::File::getSpecialLocation(juce::File::userHomeDirectory).getChildFile("Library/Audio/Plug-Ins/VST3"));
#elif JUCE_WINDOWS
            auto common=juce::SystemStats::getEnvironmentVariable("CommonProgramW6432",{});
            if(common.isNotEmpty())paths.add(juce::File(common).getChildFile("VST3"));
            auto commonCurrent=juce::SystemStats::getEnvironmentVariable("CommonProgramFiles",{});
            if(commonCurrent.isNotEmpty())paths.add(juce::File(commonCurrent).getChildFile("VST3"));
            paths.add(juce::File::getSpecialLocation(juce::File::windowsLocalAppData).getChildFile("Programs/Common/VST3"));
#endif
            for(int i=0;i<custom.getNumPaths();++i)paths.add(custom[i]);
        }
        paths.removeRedundantPaths();return paths;
    }
private:
    juce::File file;
    juce::FileSearchPath custom;
};
