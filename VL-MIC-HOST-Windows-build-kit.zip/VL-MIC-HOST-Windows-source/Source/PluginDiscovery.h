// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include <JuceHeader.h>

inline void forcePluginRescan(juce::KnownPluginList& known)
{
    for(auto d:known.getTypes()){d.lastFileModTime=juce::Time(0);d.version.clear();known.addType(d);}
    known.clearBlacklistedFiles();known.sendChangeMessage();
}

// Search both modern and legacy formats. User paths apply to both, including
// external disks. Never restrict discovery to a manufacturer or a product name.
class PluginLocations
{
public:
    explicit PluginLocations(juce::File settings):file(std::move(settings))
    {
        if(auto xml=juce::XmlDocument::parse(file);xml && xml->hasTagName("VL_PLUGIN_LOCATIONS"))
            for(auto* path:xml->getChildIterator())
                if(path->hasTagName("PATH")||path->hasTagName("VST3"))
                {
                    auto value=path->getStringAttribute("path");
                    if(juce::File::isAbsolutePath(value))custom.add(juce::File(value));
                }
    }
    bool addVst3Folder(const juce::File& directory)
    {
        if(!directory.isDirectory())return false;
        custom.add(directory);custom.removeRedundantPaths();
        juce::XmlElement xml("VL_PLUGIN_LOCATIONS");
        for(int i=0;i<custom.getNumPaths();++i)xml.createNewChildElement("PATH")->setAttribute("path",custom[i].getFullPathName());
        return xml.writeTo(file);
    }
    juce::FileSearchPath forFormat(juce::AudioPluginFormat& format) const
    {
        auto paths=format.getDefaultLocationsToSearch();
        const auto name=format.getName();
        if(name=="VST3"||name=="VST")
        {
            const bool legacy=name=="VST";
#if JUCE_MAC
            paths.add(juce::File(legacy?"/Library/Audio/Plug-Ins/VST":"/Library/Audio/Plug-Ins/VST3"));
            paths.add(juce::File::getSpecialLocation(juce::File::userHomeDirectory).getChildFile(legacy?"Library/Audio/Plug-Ins/VST":"Library/Audio/Plug-Ins/VST3"));
#elif JUCE_WINDOWS
            juce::StringArray commons;
            for(auto var:{"CommonProgramW6432","CommonProgramFiles"})commons.addIfNotAlreadyThere(juce::SystemStats::getEnvironmentVariable(var,{}));
            for(auto common:commons)if(common.isNotEmpty())paths.add(juce::File(common).getChildFile(legacy?"Steinberg/VST2":"VST3"));
            auto local=juce::File::getSpecialLocation(juce::File::windowsLocalAppData);
            paths.add(local.getChildFile(legacy?"Programs/Common/VST2":"Programs/Common/VST3"));
            paths.add(local.getChildFile(legacy?"VSTPlugins":"VST3"));
            if(legacy)
            {
                for(auto var:{"ProgramW6432","ProgramFiles"})
                {
                    auto value=juce::SystemStats::getEnvironmentVariable(var,{});if(value.isEmpty())continue;
                    for(auto sub:{"VSTPlugins","Steinberg/VstPlugins","Common Files/VST2"})paths.add(juce::File(value).getChildFile(sub));
                }
                for(auto key:{"HKEY_LOCAL_MACHINE\\SOFTWARE\\VST\\VSTPluginsPath","HKEY_CURRENT_USER\\SOFTWARE\\VST\\VSTPluginsPath"})
                {
                    auto value=juce::WindowsRegistry::getValue(key);if(juce::File::isAbsolutePath(value))paths.add(juce::File(value));
                }
            }
#endif
            for(int i=0;i<custom.getNumPaths();++i)paths.add(custom[i]);
        }
        paths.removeRedundantPaths();return paths;
    }
private:
    juce::File file;juce::FileSearchPath custom;
};
