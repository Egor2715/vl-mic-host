// SPDX-License-Identifier: AGPL-3.0-only
// Include Apple headers before JUCE's optional global namespace import.
#include <CoreFoundation/CoreFoundation.h>
#include "PluginCompatibility.h"

juce::File macPluginExecutable(const juce::File& bundle)
{
    // The first Contents/MacOS file may be a helper for another architecture.
    // CFBundle honours CFBundleExecutable in XML and binary Info.plist files.
    const auto path=bundle.getFullPathName();
    auto url=CFURLCreateFromFileSystemRepresentation(kCFAllocatorDefault,
        reinterpret_cast<const UInt8*>(path.toRawUTF8()),path.getNumBytesAsUTF8(),true);
    if(url==nullptr)return {};
    auto cfBundle=CFBundleCreate(kCFAllocatorDefault,url);CFRelease(url);
    if(cfBundle==nullptr)return {};
    auto executable=CFBundleCopyExecutableURL(cfBundle);CFRelease(cfBundle);
    if(executable==nullptr)return {};
    UInt8 bytes[4096]{};
    const bool ok=CFURLGetFileSystemRepresentation(executable,true,bytes,sizeof(bytes));
    CFRelease(executable);
    return ok?juce::File(juce::String::fromUTF8(reinterpret_cast<const char*>(bytes))):juce::File();
}

#if defined(VL_HOST_VALIDATION)
juce::MemoryBlock macBinaryPlistForTest(const juce::String& xml)
{
    juce::MemoryBlock result;
    auto input=CFDataCreate(kCFAllocatorDefault,reinterpret_cast<const UInt8*>(xml.toRawUTF8()),xml.getNumBytesAsUTF8());
    if(input==nullptr)return result;
    auto plist=CFPropertyListCreateWithData(kCFAllocatorDefault,input,kCFPropertyListImmutable,nullptr,nullptr);CFRelease(input);
    if(plist==nullptr)return result;
    auto binary=CFPropertyListCreateData(kCFAllocatorDefault,plist,kCFPropertyListBinaryFormat_v1_0,0,nullptr);CFRelease(plist);
    if(binary!=nullptr){result.append(CFDataGetBytePtr(binary),(size_t)CFDataGetLength(binary));CFRelease(binary);}
    return result;
}
#endif
