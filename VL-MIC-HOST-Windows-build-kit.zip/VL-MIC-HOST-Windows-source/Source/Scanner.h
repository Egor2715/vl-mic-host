// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 VL MIC HOST contributors

#pragma once
#include <JuceHeader.h>

// One short-lived process per candidate. A plugin's static initialisers,
// scan-time UI, crashes and teardown cannot take down the audio host.
class IsolatedScanner final : public juce::KnownPluginList::CustomScanner
{
public:
    explicit IsolatedScanner(juce::File folder) : root(std::move(folder)) {}
    bool findPluginTypesFor(juce::AudioPluginFormat& format,
                            juce::OwnedArray<juce::PluginDescription>& result,
                            const juce::String& identifier) override
    {
        using namespace juce;
        auto dir=root.getChildFile("scan-jobs").getChildFile(Uuid().toString());
        dir.createDirectory();auto request=dir.getChildFile("request.xml"),response=dir.getChildFile("response.xml");
        XmlElement xml("SCAN");xml.setAttribute("format",format.getName());xml.setAttribute("identifier",identifier);
        if(!xml.writeTo(request))return false;
        auto executable=File::getSpecialLocation(File::currentExecutableFile);
        ChildProcess process;
        String reason;
        if(!process.start(StringArray{executable.getFullPathName(),"--scan-worker",request.getFullPathName(),response.getFullPathName()},0))
            reason="Could not start scanner";
        else
        {
            auto deadline=Time::getMillisecondCounterHiRes()+60000.0;
            while(process.isRunning() && !shouldExit() && Time::getMillisecondCounterHiRes()<deadline)
            {
                if(MessageManager::getInstance()->isThisTheMessageThread())MessageManager::getInstance()->runDispatchLoopUntil(40);
                else Thread::sleep(40);
            }
            if(process.isRunning()){process.kill();process.waitForProcessToFinish(2000);reason=shouldExit()?"Cancelled":"Timed out after 60 seconds";}
            else if(auto found=XmlDocument::parse(response);found && found->hasTagName("SCAN_RESULT"))
            {
                for(auto* e:found->getChildIterator())
                {auto d=std::make_unique<PluginDescription>();if(d->loadFromXml(*e))result.add(d.release());}
                if(result.isEmpty())reason="No compatible plugin found (architecture, license or initialization)";
            }
            else reason="Scanner crashed or failed; exit code "+String(process.getExitCode());
        }
        root.getChildFile("scan-log.txt").appendText(Time::getCurrentTime().toISO8601(true)+" | "+identifier+" | "+(reason.isEmpty()?"OK":reason)+"\n");
        dir.deleteRecursively();
        return reason.isEmpty() || reason=="Cancelled";
    }
private:
    juce::File root;
};

inline void runScanWorker(const juce::StringArray& args)
{
    using namespace juce;
    
#if JUCE_MAC
        Process::setDockIconVisible(false);
#endif

    if(args.size()!=3)std::_Exit(2);
    auto request=XmlDocument::parse(File(args[1]));if(!request||!request->hasTagName("SCAN"))std::_Exit(3);
    // Diagnostic fault injection: validates recovery from an abnormal worker exit.
    if(request->getStringAttribute("identifier")=="__vl_scanner_failure_test__")std::_Exit(86);
    if(request->getStringAttribute("format")=="AudioUnit")
    {
        // AU creation may complete through the macOS run loop. Keep the worker
        // responsive until the callback instead of waiting synchronously on it.
        auto manager=std::make_shared<AudioPluginFormatManager>();manager->addDefaultFormats();
        PluginDescription d;d.pluginFormatName="AudioUnit";d.fileOrIdentifier=request->getStringAttribute("identifier");
        manager->createPluginInstanceAsync(d,44100,512,[manager,destination=File(args[2])](std::unique_ptr<AudioPluginInstance> p,const String&)
        {
            XmlElement result("SCAN_RESULT");if(p)result.addChildElement(p->getPluginDescription().createXml().release());
            bool written=result.writeTo(destination);std::_Exit(written?0:4);
        });
        return;
    }
    AudioPluginFormatManager formats;formats.addDefaultFormats();
    XmlElement result("SCAN_RESULT");
    for(auto* format:formats.getFormats())if(format->getName()==request->getStringAttribute("format"))
    {
        OwnedArray<PluginDescription> descriptions;
        format->findAllTypesForFile(descriptions,request->getStringAttribute("identifier"));
        for(auto* d:descriptions)result.addChildElement(d->createXml().release());
    }
    bool written=result.writeTo(File(args[2]));
    // The process owns no user state. Avoid executing delayed third-party
    // run-loop callbacks after returning the completed discovery result.
    std::_Exit(written?0:4);
}
