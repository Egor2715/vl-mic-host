// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 VL MIC HOST contributors

#pragma once
#include <JuceHeader.h>
#include "PluginCompatibility.h"

// One short-lived process per candidate. A plugin's static initialisers,
// scan-time UI, crashes and teardown cannot take down the audio host.
class IsolatedScanner final : public juce::KnownPluginList::CustomScanner
{
public:
    explicit IsolatedScanner(juce::File folder) : root(std::move(folder)) {}
    bool findPluginTypesFor(juce::AudioPluginFormat& format,
                            juce::OwnedArray<juce::PluginDescription>& result,
                            const juce::String& identifier) override
    {
        using namespace juce;
        if(auto problem=pluginBinaryProblem(identifier);problem.isNotEmpty())
        {root.getChildFile("scan-log.txt").appendText(format.getName()+" | "+identifier+" | "+problem+"\n");return false;}
        auto dir=root.getChildFile("scan-jobs").getChildFile(Uuid().toString());
        dir.createDirectory();auto request=dir.getChildFile("request.xml"),response=dir.getChildFile("response.xml");
        XmlElement xml("SCAN");xml.setAttribute("format",format.getName());xml.setAttribute("identifier",identifier);
        if(!xml.writeTo(request))return false;
        auto executable=File::getSpecialLocation(File::currentExecutableFile);
        ChildProcess process;
        String reason;
        if(!process.start(StringArray{executable.getFullPathName(),"--scan-worker",request.getFullPathName(),response.getFullPathName()},0))
            reason="Could not start scanner";
        else
        {
            // Shell modules enumerate many plug-in classes in one file.
            const double timeout=identifier.containsIgnoreCase("WaveShell")?300000.0:120000.0;
            auto deadline=Time::getMillisecondCounterHiRes()+timeout;
            while(process.isRunning() && !shouldExit() && Time::getMillisecondCounterHiRes()<deadline)
            {
                if(MessageManager::getInstance()->isThisTheMessageThread())MessageManager::getInstance()->runDispatchLoopUntil(40);
                else Thread::sleep(40);
            }
            if(process.isRunning()){process.kill();process.waitForProcessToFinish(2000);reason=shouldExit()?"Cancelled":"Timed out after "+String((int)(timeout/1000))+" seconds";}
            else if(auto found=XmlDocument::parse(response);found && found->hasTagName("SCAN_RESULT"))
            {
                for(auto* e:found->getChildIterator())
                {auto d=std::make_unique<PluginDescription>();if(d->loadFromXml(*e))result.add(d.release());}
                if(result.isEmpty())reason=found->getStringAttribute("error","No compatible plug-in found: check format, architecture, license and installation");
            }
            else reason="Scanner crashed or failed before publishing a result";
        }
        StringArray names;for(auto* d:result)names.add(d->name);
        root.getChildFile("scan-log.txt").appendText(Time::getCurrentTime().toISO8601(true)+" | "+format.getName()+" | "+identifier+" | "+(reason.isEmpty()?"OK / "+String(result.size())+" classes / "+names.joinIntoString(", "):reason)+"\n");
        dir.deleteRecursively();
        return reason.isEmpty() || reason=="Cancelled";
    }
private:
    juce::File root;
};

inline void runScanWorker(const juce::StringArray& args)
{
    using namespace juce;
    
#if JUCE_MAC
        Process::setDockIconVisible(false);
#endif

    if(args.size()!=3)std::_Exit(2);
    auto request=XmlDocument::parse(File(args[1]));if(!request||!request->hasTagName("SCAN"))std::_Exit(3);
    // Diagnostic fault injection: validates recovery from an abnormal worker exit.
    if(request->getStringAttribute("identifier")=="__vl_scanner_failure_test__")std::_Exit(86);
    if(auto problem=pluginBinaryProblem(request->getStringAttribute("identifier"));problem.isNotEmpty())
    {XmlElement result("SCAN_RESULT");result.setAttribute("error",problem);result.writeTo(File(args[2]));std::_Exit(0);}
    if(request->getStringAttribute("format")=="VST")
    {
        auto stage=File(args[2]).getSiblingFile("scan-stage.txt");stage.replaceWithText("Creating VST2 instance");
        // Create asynchronously and publish before third-party teardown. JUCE's
        // legacy findAllTypesForFile sends an extra effOpen to ordinary effects;
        // some plug-ins block on that second call. Shells still enumerate all IDs.
        auto manager=std::make_shared<AudioPluginFormatManager>();manager->addDefaultFormats();
        PluginDescription d;d.pluginFormatName="VST";d.fileOrIdentifier=request->getStringAttribute("identifier");
        manager->createPluginInstanceAsync(d,44100,512,[manager,d,stage,destination=File(args[2])](std::unique_ptr<AudioPluginInstance> p,const String& error)
        {
            stage.replaceWithText("Reading VST2 metadata");
            if(!p){XmlElement result("SCAN_RESULT");result.setAttribute("error",error);result.writeTo(destination);std::_Exit(0);}
            auto description=p->getPluginDescription();
            stage.replaceWithText("Publishing VST2 metadata");
            if(description.category!="Shell")
            {XmlElement result("SCAN_RESULT");result.addChildElement(description.createXml().release());result.writeTo(destination);std::_Exit(0);}
            // A shell's UID is chosen through the host callback at creation.
            struct ShellJob:std::enable_shared_from_this<ShellJob>
            {
                std::shared_ptr<AudioPluginFormatManager> manager;PluginDescription prototype;File destination;
                StringArray names;Array<int> ids;int index=0;XmlElement result{"SCAN_RESULT"};
                void next()
                {
                    if(index>=ids.size()){result.writeTo(destination);std::_Exit(0);}
                    auto desc=prototype;desc.uniqueId=desc.deprecatedUid=ids[index];auto self=shared_from_this();
                    manager->createPluginInstanceAsync(desc,44100,512,[self](std::unique_ptr<AudioPluginInstance> instance,const String&)
                    {
                        if(instance){auto found=instance->getPluginDescription();found.name=self->names[self->index];found.hasSharedContainer=true;self->result.addChildElement(found.createXml().release());}
                        ++self->index;self->next();
                    });
                }
            };
            auto job=std::make_shared<ShellJob>();job->manager=manager;job->prototype=d;job->destination=destination;
            for(int count=0;count<4096;++count)
            {
                char name[256]{};const int uid=(int)VSTPluginFormat::dispatcher(p.get(),70,0,0,name,0);
                if(uid==0)break;job->ids.add(uid);job->names.add(String::fromUTF8(name));
            }
            // Retain the shell until completion; all workers exit without running
            // a delayed shell destructor after the final response.
            p.release();job->next();
        });return;
    }
    if(request->getStringAttribute("format")=="AudioUnit")
    {
        // AU creation may complete through the macOS run loop. Keep the worker
        // responsive until the callback instead of waiting synchronously on it.
        auto manager=std::make_shared<AudioPluginFormatManager>();manager->addDefaultFormats();
        PluginDescription d;d.pluginFormatName="AudioUnit";d.fileOrIdentifier=request->getStringAttribute("identifier");
        manager->createPluginInstanceAsync(d,44100,512,[manager,destination=File(args[2])](std::unique_ptr<AudioPluginInstance> p,const String& error)
        {
            XmlElement result("SCAN_RESULT");if(p)result.addChildElement(p->getPluginDescription().createXml().release());
            else result.setAttribute("error",error.isNotEmpty()?error:"Audio Unit initialization failed");
            bool written=result.writeTo(destination);std::_Exit(written?0:4);
        });
        return;
    }
    AudioPluginFormatManager formats;formats.addDefaultFormats();
    XmlElement result("SCAN_RESULT");
    for(auto* format:formats.getFormats())if(format->getName()==request->getStringAttribute("format"))
    {
        OwnedArray<PluginDescription> descriptions;
        format->findAllTypesForFile(descriptions,request->getStringAttribute("identifier"));
        for(auto* d:descriptions)result.addChildElement(d->createXml().release());
    }
    bool written=result.writeTo(File(args[2]));
    // The process owns no user state. Avoid executing delayed third-party
    // run-loop callbacks after returning the completed discovery result.
    std::_Exit(written?0:4);
}
