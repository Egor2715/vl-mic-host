// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include <JuceHeader.h>

// A shell's class index is not an identity. Check the instantiated VST3 against
// the scanned class before applying state or connecting it to an audio channel.
inline juce::String pluginIdentityProblem(const juce::PluginDescription& requested,
                                          const juce::PluginDescription& loaded)
{
    if(requested.pluginFormatName != "VST3") return {};
    const bool idMatches = loaded.uniqueId == requested.uniqueId
        || (requested.deprecatedUid != 0 && loaded.uniqueId == requested.deprecatedUid)
        || (loaded.deprecatedUid != 0 && loaded.deprecatedUid == requested.uniqueId)
        || (loaded.deprecatedUid != 0 && requested.deprecatedUid != 0
            && loaded.deprecatedUid == requested.deprecatedUid);
    if(loaded.pluginFormatName == "VST3" && requested.name == loaded.name && idMatches) return {};
    return "Plug-in identity mismatch. Selected: " + requested.name + " (" + juce::String(requested.uniqueId)
        + "), loaded: " + loaded.name + " (" + juce::String(loaded.uniqueId)
        + "). The incorrect plug-in was not connected. Rescan this module and try again.";
}
