// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 VL MIC HOST contributors

#pragma once
#include <JuceHeader.h>
#include <array>

// CoreAudio is only the transport. Chain processing has no device dependency;
// a future VL MIC transport can feed the same process() entry point.
class Engine final : public juce::AudioIODeviceCallback, private juce::ChangeListener
{
public:
    static constexpr int mainSlots = 6, slotCount = 8;
    struct Slot { std::unique_ptr<juce::AudioPluginInstance> plugin; juce::PluginDescription description; bool bypass = false; };
    Engine();
    ~Engine() override;
    juce::AudioPluginFormatManager formats;
    juce::KnownPluginList known;
    juce::AudioDeviceManager devices;
    std::array<Slot, slotCount> slots;
    juce::CriticalSection lock;
    std::atomic<float> inputGain { 1 }, outputGain { 1 }, inputPeak { 0 }, outputPeak { 0 };
    std::atomic<float> dryGain {1}, sendGain {0.25f}, returnGain {1}, dryPeak {0}, fxPeak {0};
    std::atomic<bool> dryMute {false}, fxMute {false}, fxSolo {false}, fxLatencyOverflow {false};
    std::atomic<bool> live { false }, mono { false };
    std::atomic<int> micChannel { 0 }, outputChannel { 0 }, contentionBlocks { 0 };
    double sampleRate = 48000;
    int blockSize = 256;
    juce::File dataFolder() const;
    juce::String start();
    juce::String load(int, const juce::PluginDescription&);
    void remove(int);
    void move(int, int);
    void transfer(int,int);
    void bypass(int, bool);
    void prepare(double, int);
    void process(const float* const*, int, float* const*, int, int);
    std::unique_ptr<juce::XmlElement> preset();
    juce::String restore(const juce::XmlElement&);
    void audioDeviceAboutToStart(juce::AudioIODevice*) override;
    void audioDeviceStopped() override;
    void audioDeviceIOCallbackWithContext(const float* const* i, int ni, float* const* o, int no, int n, const juce::AudioIODeviceCallbackContext&) override { process(i, ni, o, no, n); }
    juce::String selfTest();
private:
    void changeListenerCallback(juce::ChangeBroadcaster*) override
    { if(auto x=known.createXml())x->writeTo(dataFolder().getChildFile("plugins.xml")); }
    struct LivePlayHead final : juce::AudioPlayHead
    {
        int64_t samples=0;double rate=48000;
        juce::Optional<PositionInfo> getPosition() const override
        {
            PositionInfo p;p.setTimeInSamples(samples);p.setTimeInSeconds(samples/rate);
            p.setBpm(120.0);p.setTimeSignature(TimeSignature{4,4});p.setPpqPosition(samples/rate*2.0);p.setIsPlaying(true);return p;
        }
    } playHead;
    juce::AudioBuffer<float> scratch, fxBuffer, dryDelay;
    static constexpr int delayCapacity = 262144;
    int delayPosition=0;
    float previousDry=1, previousSend=0.25f, previousReturn=1;
    void processSlots(juce::AudioBuffer<float>&,int,int,int);
    juce::MidiBuffer midi;
    float previousInput = 1, previousOutput = 1;
    juce::String configure(juce::AudioPluginInstance&);
};
