// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include "PluginCompatibility.h"
#if JUCE_MAC && defined(VL_HOST_VALIDATION)
juce::MemoryBlock macBinaryPlistForTest(const juce::String&);
#endif

inline juce::String validateMacPluginBinaries()
{
    using namespace juce;
    String report;
   #if JUCE_MAC && defined(VL_HOST_VALIDATION)
    auto check=[&](bool ok,const String& label){report+=(ok?"PASS ":"FAIL ")+label+"\n";};
    constexpr uint32 intel=0x01000007,arm=0x0100000c;
    auto thin=[](uint32 cpu,bool big=false,bool is64=true){
        MemoryOutputStream out;
        auto word=[&](uint32 x){if(big)out.writeIntBigEndian((int)x);else out.writeInt((int)x);};
        word(is64?0xfeedfacf:0xfeedface);word(cpu);
        for(int i=0;i<(is64?6:5);++i)word(0);
        return out.getMemoryBlock();
    };
    auto problem=[](const MemoryBlock& data,uint32 cpu){
        MemoryInputStream in(data,false);return macBinaryProblemForCpu(in,cpu);
    };
    check(problem(thin(intel),intel).isEmpty(),"Intel-only Mach-O is accepted by an Intel host");
    check(problem(thin(arm),arm).isEmpty(),"ARM-only Mach-O is accepted by an Apple Silicon host");
    check(problem(thin(intel),arm).isNotEmpty(),"Intel-only Mach-O is rejected by a native ARM host");
    check(problem(thin(arm),intel).isNotEmpty(),"ARM-only Mach-O is rejected by an Intel host");
    check(problem(thin(intel,true),intel).isEmpty(),"Byte-swapped Intel Mach-O header is recognised");
    check(problem(thin(7,false,false),intel).isNotEmpty(),"32-bit Intel plug-ins are rejected");
    for(bool wide:{false,true})for(bool big:{false,true})
    {
        auto fat=[&](std::initializer_list<uint32> cpus){
            MemoryOutputStream out;
            auto word=[&](uint32 x){if(big)out.writeIntBigEndian((int)x);else out.writeInt((int)x);};
            word(wide?0xcafebabf:0xcafebabe);word((uint32)cpus.size());
            for(auto cpu:cpus){word(cpu);for(int i=0;i<(wide?7:4);++i)word(0);}
            return out.getMemoryBlock();
        };
        const auto label=String(wide?"fat64":"fat32")+" / "+String(big?"big endian":"little endian");
        check(problem(fat({arm,intel}),intel).isEmpty() && problem(fat({intel,arm}),arm).isEmpty(),
              "Universal slices are accepted independently of order: "+label);
        check(problem(fat({intel}),arm).isNotEmpty() && problem(fat({arm}),intel).isNotEmpty(),
              "Universal file without the host CPU is rejected: "+label);
        auto truncated=fat({arm,intel});truncated.setSize(truncated.getSize()-1);
        check(problem(truncated,intel).contains("truncated"),"Truncated Universal table is rejected: "+label);
    }
    auto truncated=thin(intel);truncated.setSize(7);
    check(problem(truncated,intel).contains("truncated"),"Truncated thin Mach-O is rejected");
    auto folder=File::getSpecialLocation(File::tempDirectory).getChildFile("VL-binary-test-"+Uuid().toString());
    auto bundle=folder.getChildFile("Fixture.vst3");auto binaries=bundle.getChildFile("Contents/MacOS");
    binaries.createDirectory();
    auto actual=binaries.getChildFile("RealPlugin");auto data=thin(macHostCpu());
    actual.replaceWithData(data.getData(),data.getSize());
    auto helper=thin(macHostCpu()==intel?arm:intel);
    binaries.getChildFile("000-wrong-architecture-helper").replaceWithData(helper.getData(),helper.getSize());
    auto plist=bundle.getChildFile("Contents/Info.plist");
    plist.replaceWithText("<?xml version=\"1.0\"?><plist version=\"1.0\"><dict><key>CFBundleExecutable</key><string>RealPlugin</string><key>CFBundlePackageType</key><string>BNDL</string><key>CFBundleIdentifier</key><string>audio.vl.binary-fixture</string></dict></plist>");
    check(macPluginExecutable(bundle)==actual && pluginBinaryProblem(bundle.getFullPathName()).isEmpty(),
          "Bundle selects CFBundleExecutable instead of an incompatible helper");
    // CoreFoundation also resolves bundles whose Info.plist is a binary plist.
    auto binary=macBinaryPlistForTest(plist.loadFileAsString());
    auto binaryBundle=folder.getChildFile("BinaryFixture.vst3");bundle.copyDirectoryTo(binaryBundle);
    binaryBundle.getChildFile("Contents/Info.plist").replaceWithData(binary.getData(),binary.getSize());
    check(binary.getSize()>0 && macPluginExecutable(binaryBundle)==binaryBundle.getChildFile("Contents/MacOS/RealPlugin") && pluginBinaryProblem(binaryBundle.getFullPathName()).isEmpty(),
          "Binary Info.plist resolves the correct bundle executable");
    check(pluginBinaryProblem("AudioUnit:Effects/aufx,TEST,VLxx").isEmpty(),"AU identifiers remain delegated to the AU loader");
    check(pluginBinaryProblem(folder.getChildFile("Missing.vst3").getFullPathName()).isNotEmpty(),"Missing plug-in file is reported");
    folder.deleteRecursively();
   #endif
    return report;
}
