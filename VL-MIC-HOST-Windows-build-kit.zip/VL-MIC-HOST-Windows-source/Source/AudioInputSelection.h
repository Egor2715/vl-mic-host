// SPDX-License-Identifier: AGPL-3.0-only
#pragma once
#include <JuceHeader.h>

// JUCE passes active device inputs to the callback in this packed order.
// A missing input must not erase the requested route: an interface may appear
// after a one-input headset, or its second input may be enabled in Audio setup.
inline void rebuildChannel2Input(juce::ComboBox& selector,
                                std::atomic<int>& requestedInput,
                                const juce::StringArray& activeNames)
{
    const int stored = requestedInput.load();
    const int requested = stored < 0 ? 1 : stored;
    selector.clear(juce::dontSendNotification);
    for (int i = 0; i < activeNames.size(); ++i)
        selector.addItem(activeNames[i], i + 1);
    requestedInput = requested;
    selector.setSelectedId(juce::isPositiveAndBelow(requested, activeNames.size())
                              ? requested + 1 : 0,
                          juce::dontSendNotification);
    selector.setTextWhenNothingSelected("Select audio input");
}
