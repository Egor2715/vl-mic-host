// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 VL MIC HOST contributors

#include "Engine.h"
#include "Scanner.h"
#include "TestEffect.h"
using namespace juce;

Engine::Engine()
{
    formats.addDefaultFormats();
    scratch.setSize(32, blockSize);
    fxBuffer.setSize(32,blockSize);dryDelay.setSize(2,delayCapacity);dryDelay.clear();
    midi.ensureSize(4096);
    if (auto xml = XmlDocument::parse(dataFolder().getChildFile("plugins.xml"))) known.recreateFromXml(*xml);
    known.setCustomScanner(std::make_unique<IsolatedScanner>(dataFolder()));
    known.addChangeListener(this);
}
Engine::~Engine()
{
    known.removeChangeListener(this);
    devices.removeAudioCallback(this);
    devices.closeAudioDevice();
    for(auto& s:slots)if(s.plugin){s.plugin->setPlayHead(nullptr);s.plugin->releaseResources();s.plugin.reset();}
    if (auto xml = known.createXml()) xml->writeTo(dataFolder().getChildFile("plugins.xml"));
}
File Engine::dataFolder() const
{
    #if JUCE_MAC
    auto f = File::getSpecialLocation(File::userApplicationDataDirectory).getChildFile("Application Support/VL MIC HOST");
#else
    auto f = File::getSpecialLocation(File::userApplicationDataDirectory).getChildFile("VL MIC HOST");
#endif
    f.createDirectory(); return f;
}
String Engine::start()
{
    auto xml = XmlDocument::parse(dataFolder().getChildFile("device.xml"));
    auto error = devices.initialise(2, 2, xml.get(), true);
    if(error.isEmpty() && !xml)
    {
        if(auto* type=devices.getCurrentDeviceTypeObject())
        {
            type->scanForDevices();auto setup=devices.getAudioDeviceSetup();
            String input,output;
            for(auto& n:type->getDeviceNames(true))if(n.containsIgnoreCase("iD4")){input=n;break;}
            for(auto& n:type->getDeviceNames(false))if(n.containsIgnoreCase("iD4")){output=n;break;}
            if(input.isNotEmpty() && output.isNotEmpty())
            {
                setup.inputDeviceName=input;setup.outputDeviceName=output;setup.sampleRate=48000;setup.bufferSize=128;
                setup.useDefaultInputChannels=false;setup.inputChannels.clear();setup.inputChannels.setRange(0,2,true);
                setup.useDefaultOutputChannels=false;setup.outputChannels.clear();setup.outputChannels.setRange(0,4,true);
                error=devices.setAudioDeviceSetup(setup,true);
            }
        }
    }
    if (error.isEmpty()) devices.addAudioCallback(this);
    return error;
}
String Engine::configure(AudioPluginInstance& p)
{
    p.setPlayHead(&playHead);
    p.enableAllBuses();
    auto layout = p.getBusesLayout();
    // Keep auxiliary buses enabled: some AU effects require valid buffers for
    // their sidechain even when it is not in use. process() supplies silence.
    if (layout.inputBuses.isEmpty() || layout.outputBuses.isEmpty()) return "Only audio effects with an input and output are supported.";
    bool accepted = false;
    for (int channels : { 2, 1 })
    {
        layout.inputBuses.getReference(0) = AudioChannelSet::canonicalChannelSet(channels);
        layout.outputBuses.getReference(0) = AudioChannelSet::canonicalChannelSet(channels);
        if (p.setBusesLayout(layout)) { accepted = true; break; }
    }
    if (! accepted || p.getTotalNumInputChannels() > 32 || p.getTotalNumOutputChannels() > 32)
        return "This effect does not support a mono or stereo main bus.";
    p.setRateAndBufferSizeDetails(sampleRate, blockSize);
    p.prepareToPlay(sampleRate, blockSize);
    return {};
}
String Engine::load(int index, const PluginDescription& d)
{
    if (! isPositiveAndBelow(index, slotCount)) return "Invalid slot";
    const ScopedLock guard(lock);
    String error;
    auto p = formats.createPluginInstance(d, sampleRate, blockSize, error);
    if (!p) return error.isEmpty() ? "Could not load plug-in" : error;
    if (auto e = configure(*p); e.isNotEmpty()) return e;
    if (slots[index].plugin) slots[index].plugin->releaseResources();
    slots[index] = { std::move(p), d, false }; return {};
}
void Engine::remove(int i) { const ScopedLock g(lock); if (slots[i].plugin) slots[i].plugin->releaseResources(); slots[i] = {}; }
void Engine::move(int a, int b) { if (!isPositiveAndBelow(b,slotCount) || (a<mainSlots)!=(b<mainSlots)) return; const ScopedLock g(lock); std::swap(slots[a],slots[b]); }
void Engine::transfer(int a,int b)
{
    if(!isPositiveAndBelow(a,slotCount)||!isPositiveAndBelow(b,slotCount))return;
    const ScopedLock g(lock);if(!slots[b].plugin){std::swap(slots[a],slots[b]);dryDelay.clear();delayPosition=0;}
}
void Engine::bypass(int i, bool b) { const ScopedLock g(lock); slots[i].bypass = b; }
void Engine::prepare(double sr, int bs)
{
    const ScopedLock g(lock);
    sampleRate = sr; blockSize = jmax(1,bs); scratch.setSize(32,blockSize);scratch.clear();
    fxBuffer.setSize(32,blockSize);fxBuffer.clear();dryDelay.clear();delayPosition=0;
    playHead.rate=sr;playHead.samples=0;
    for (auto& s : slots) if (s.plugin) { s.plugin->releaseResources(); s.plugin->setRateAndBufferSizeDetails(sr,blockSize); s.plugin->prepareToPlay(sr,blockSize); }
    previousInput=inputGain.load(); previousOutput=outputGain.load();
    previousDry=dryMute?0:dryGain.load();previousSend=sendGain.load();previousReturn=fxMute?0:returnGain.load();
}
void Engine::processSlots(AudioBuffer<float>& buffer,int first,int end,int n)
{
    auto* l=buffer.getWritePointer(0);auto* r=buffer.getWritePointer(1);
    for(int i=first;i<end;++i)if(auto& s=slots[i];s.plugin&&!s.bypass)
    {
        int mainChannels=s.plugin->getMainBusNumInputChannels();
        int channels=jmax(s.plugin->getTotalNumInputChannels(),s.plugin->getTotalNumOutputChannels());
        if(mainChannels==1){FloatVectorOperations::add(l,r,n);FloatVectorOperations::multiply(l,0.5f,n);}
        for(int c=mainChannels;c<channels;++c)buffer.clear(c,0,n);
        AudioBuffer<float> block(buffer.getArrayOfWritePointers(),channels,n);midi.clear();s.plugin->processBlock(block,midi);
        if(s.plugin->getMainBusNumOutputChannels()==1)FloatVectorOperations::copy(r,l,n);
    }
}
void Engine::audioDeviceAboutToStart(AudioIODevice* d) { prepare(d->getCurrentSampleRate(),d->getCurrentBufferSizeSamples()); }
void Engine::audioDeviceStopped() { inputPeak=0; outputPeak=0; }
void Engine::process(const float* const* in, int ni, float* const* out, int no, int count)
{
    // The callback never waits for UI/plugin loading and never resizes buffers.
    const ScopedTryLock guard(lock);
    for (int c=0;c<no;++c) if(out[c]) FloatVectorOperations::clear(out[c],count);
    if (!guard.isLocked()) { ++contentionBlocks; return; }
    const int mic=micChannel.load(), dest=outputChannel.load();
    float peakIn=0, peakOut=0, peakDry=0, peakFx=0;
    int fxLatency=0;bool hasFx=false;
    for(int i=mainSlots;i<slotCount;++i)if(slots[i].plugin&&!slots[i].bypass){hasFx=true;fxLatency+=jmax(0,slots[i].plugin->getLatencySamples());}
    fxLatencyOverflow=fxLatency>=delayCapacity;
    if(fxLatencyOverflow){hasFx=false;fxLatency=0;}
    for (int offset=0;offset<count;offset+=blockSize)
    {
        int n=jmin(blockSize,count-offset);
        auto* l=scratch.getWritePointer(0); auto* r=scratch.getWritePointer(1);
        if (mic<ni && mic>=0 && in[mic]) FloatVectorOperations::copy(l,in[mic]+offset,n); else FloatVectorOperations::clear(l,n);
        const float ig=inputGain.load(), og=outputGain.load();
        scratch.applyGainRamp(0,0,n,previousInput,ig); previousInput=ig;
        peakIn=jmax(peakIn,scratch.getMagnitude(0,0,n));
        if (!live.load()) continue;
        FloatVectorOperations::copy(r,l,n);
        processSlots(scratch,0,mainSlots,n);
        const float dg=dryMute?0:dryGain.load(),sg=sendGain.load(),rg=(fxMute||!hasFx)?0:returnGain.load();
        for(int c=0;c<2;++c)
        {
            scratch.applyGainRamp(c,0,n,previousDry,dg);
            fxBuffer.copyFrom(c,0,scratch,c,0,n);fxBuffer.applyGainRamp(c,0,n,previousSend,sg);
        }
        previousDry=dg;previousSend=sg;
        peakDry=jmax(peakDry,jmax(scratch.getMagnitude(0,0,n),scratch.getMagnitude(1,0,n)));
        if(hasFx)processSlots(fxBuffer,mainSlots,slotCount,n);else fxBuffer.clear();
        for(int c=0;c<2;++c)fxBuffer.applyGainRamp(c,0,n,previousReturn,rg);
        previousReturn=rg;
        peakFx=jmax(peakFx,jmax(fxBuffer.getMagnitude(0,0,n),fxBuffer.getMagnitude(1,0,n)));
        // Align dry audio with plugin-reported FX latency (not reverb pre-delay).
        // Muting a return still processes it, so existing reverb tails advance.
        for(int j=0;j<n;++j)
        {
            int read=(delayPosition+delayCapacity-fxLatency)%delayCapacity;
            for(int c=0;c<2;++c)
            {
                dryDelay.setSample(c,delayPosition,scratch.getSample(c,j));
                scratch.setSample(c,j,(fxSolo?0:dryDelay.getSample(c,read))+fxBuffer.getSample(c,j));
            }
            delayPosition=(delayPosition+1)%delayCapacity;
        }
        scratch.applyGainRamp(0,0,n,previousOutput,og); scratch.applyGainRamp(1,0,n,previousOutput,og); previousOutput=og;
        if (mono.load()) { FloatVectorOperations::add(l,r,n); FloatVectorOperations::multiply(l,0.5f,n); FloatVectorOperations::copy(r,l,n); }
        for(int c=0;c<2;++c) for(int j=0;j<n;++j) if(!std::isfinite(scratch.getSample(c,j))) scratch.setSample(c,j,0);
        peakOut=jmax(peakOut,jmax(scratch.getMagnitude(0,0,n),scratch.getMagnitude(1,0,n)));
        if(dest>=0 && dest<no && out[dest]) FloatVectorOperations::copy(out[dest]+offset,l,n);
        if(dest+1<no && dest>=0 && out[dest+1]) FloatVectorOperations::copy(out[dest+1]+offset,r,n);
        playHead.samples+=n;
    }
    inputPeak.store(jmax(inputPeak.load(),peakIn)); outputPeak.store(jmax(outputPeak.load(),peakOut));
    dryPeak.store(jmax(dryPeak.load(),peakDry));fxPeak.store(jmax(fxPeak.load(),peakFx));
}
std::unique_ptr<XmlElement> Engine::preset()
{
    const ScopedLock g(lock);
    auto x=std::make_unique<XmlElement>("VL_MIC_HOST"); x->setAttribute("version",2);
    x->setAttribute("dryGain",(double)dryGain.load());x->setAttribute("sendGain",(double)sendGain.load());x->setAttribute("returnGain",(double)returnGain.load());
    x->setAttribute("dryMute",dryMute.load());x->setAttribute("fxMute",fxMute.load());x->setAttribute("fxSolo",fxSolo.load());
    x->setAttribute("inputGain",(double)inputGain.load()); x->setAttribute("outputGain",(double)outputGain.load()); x->setAttribute("mono",mono.load());
    for(int i=0;i<slotCount;++i)
    {
        auto* e=x->createNewChildElement("SLOT"); e->setAttribute("index",i); e->setAttribute("bypass",slots[i].bypass);
        if(auto* p=slots[i].plugin.get()) { e->addChildElement(slots[i].description.createXml().release()); MemoryBlock state; p->getStateInformation(state); e->createNewChildElement("STATE")->addTextElement(state.toBase64Encoding()); }
    }
    return x;
}
String Engine::restore(const XmlElement& x)
{
    if(!x.hasTagName("VL_MIC_HOST") || (x.getIntAttribute("version")!=1 && x.getIntAttribute("version")!=2)) return "Unsupported VL MIC HOST preset";
    const ScopedLock g(lock);
    // Stage the entire chain; any missing/failed effect leaves the existing chain intact.
    std::array<Slot,slotCount> staged;
    std::array<bool,slotCount> seen{};
    for(auto* e:x.getChildIterator())
    {
        if(!e->hasTagName("SLOT")) continue;
        int i=e->getIntAttribute("index",-1); if(!isPositiveAndBelow(i,slotCount)||seen[i]) return "Invalid preset slot"; seen[i]=true;
        if(auto* d=e->getChildByName("PLUGIN"))
        {
            PluginDescription desc; if(!desc.loadFromXml(*d)) return "Invalid plug-in description";
            String error; auto p=formats.createPluginInstance(desc,sampleRate,blockSize,error);
            if(!p) return desc.name+": "+error;
            if(auto err=configure(*p);err.isNotEmpty()) return desc.name+": "+err;
            if(auto* state=e->getChildByName("STATE")) { MemoryBlock bytes; if(!bytes.fromBase64Encoding(state->getAllSubText())) return "Invalid plug-in state"; p->setStateInformation(bytes.getData(),(int)bytes.getSize()); }
            staged[i]={std::move(p),desc,e->getBoolAttribute("bypass")};
        }
    }
    live=false;
    for(auto& s:slots) if(s.plugin) s.plugin->releaseResources();
    slots.swap(staged);
    inputGain=(float)jlimit(0.0,15.85,x.getDoubleAttribute("inputGain",1)); outputGain=(float)jlimit(0.0,3.982,x.getDoubleAttribute("outputGain",1)); mono=x.getBoolAttribute("mono");
    dryGain=(float)jlimit(0.0,3.982,x.getDoubleAttribute("dryGain",1));sendGain=(float)jlimit(0.0,1.0,x.getDoubleAttribute("sendGain",0.25));returnGain=(float)jlimit(0.0,3.982,x.getDoubleAttribute("returnGain",1));
    dryMute=x.getBoolAttribute("dryMute");fxMute=x.getBoolAttribute("fxMute");fxSolo=x.getBoolAttribute("fxSolo");dryDelay.clear();delayPosition=0;
    return {};
}

String Engine::selfTest()
{
    String report="VL MIC HOST 0.3.0 / platform validation\n";
    auto check=[&](bool ok,String name){report+=(ok?"PASS ":"FAIL ")+name+"\n";dataFolder().getChildFile("validation-progress.txt").replaceWithText(report);};
    prepare(48000,64); live=true;
    AudioBuffer<float> in(2,257),out(4,257);in.clear();out.clear();
    for(int n=0;n<257;++n){in.setSample(0,n,0.2f);in.setSample(1,n,0.4f);}
    process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(std::abs(out.getSample(0,256)-0.2f)<0.0001f && out.getSample(1,256)==out.getSample(0,256),"Empty chain, mono to stereo, oversized callback chunking");
    micChannel=1;outputChannel=2;process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(out.getMagnitude(0,0,257)==0 && std::abs(out.getSample(2,256)-0.4f)<0.0001f,"Selected microphone and output route; unused channels silent");
    live=false;process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);check(out.getMagnitude(0,257)==0,"Stopped output silent");
    live=true;micChannel=0;outputChannel=0;inputGain=0.5f;outputGain=0.5f;
    process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(std::abs(out.getSample(0,256)-0.05f)<0.0001f,"Input and output gain ramps settle correctly");
    inputGain=1;outputGain=1;
    slots[6].plugin=std::make_unique<TestEffect>();prepare(48000,64);
    for(int n=0;n<257;++n)in.setSample(0,n,0.2f);
    sendGain=0.5f;returnGain=0.25f;dryGain=0.5f;
    process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(std::abs(out.getSample(0,256)-0.125f)<0.0001f,"Parallel post-fader send + independent return gain");
    fxMute=true;process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(std::abs(out.getSample(0,256)-0.1f)<0.0001f,"FX mute preserves microphone level");
    fxMute=false;fxSolo=true;process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(std::abs(out.getSample(0,256)-0.025f)<0.0001f,"FX solo isolates return");
    dryMute=true;process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(std::abs(out.getSample(0,256))<0.0001f,"Mic mute also stops post-fader send");
    dryMute=false;fxSolo=false;dryGain=1;sendGain=1;returnGain=1;prepare(48000,64);
    in.clear();in.setSample(0,0,0.2f);process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(out.getSample(0,0)==0 && std::abs(out.getSample(0,3)-0.6f)<0.0001f,"Dry and FX align at reported plugin latency");
    bypass(6,true);in.clear();for(int n=0;n<257;++n)in.setSample(0,n,0.2f);
    process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(std::abs(out.getSample(0,256)-0.2f)<0.0001f,"All-bypassed FX return cannot double dry voice");
    remove(6);dryGain=1;sendGain=0.25f;returnGain=1;prepare(48000,64);
    for(auto* format:formats.getFormats())
    {
        String identifier;
        if(format->getName()=="VST3")
        {
            auto ids=format->searchPathsForPlugins(format->getDefaultLocationsToSearch(),true,false);
            for(auto& id:ids)if(id.containsIgnoreCase("FabFilter Pro-Q 4")){identifier=id;break;}
        }
        else if(format->getName()=="AudioUnit")
        {
            auto ids=format->searchPathsForPlugins(format->getDefaultLocationsToSearch(),true,false);
            for(auto& id:ids)if(id.contains("aumf,FQ4p,FabF")){identifier=id;break;}
            if(identifier.isEmpty())for(auto& id:ids)if(id.contains("aufx,dcmp,appl")){identifier=id;break;}
        }
        if(identifier.isEmpty()){report<<"SKIP: optional "+format->getName()+" test effect not installed\n";continue;}
        IsolatedScanner scanner(dataFolder());
        OwnedArray<PluginDescription> invalid;
        check(!scanner.findPluginTypesFor(*format,invalid,"__vl_scanner_failure_test__"),format->getName()+" failed worker is contained");
        OwnedArray<PluginDescription> found;scanner.findPluginTypesFor(*format,found,identifier);
        check(!found.isEmpty(),format->getName()+" discovery: "+identifier);
        for(auto* d:found)known.addType(*d);
        if(found.isEmpty())continue;
        auto err=load(0,*found[0]);check(err.isEmpty(),format->getName()+" instance: "+err);if(err.isNotEmpty())continue;
        auto& params=slots[0].plugin->getParameters();
        int parameterIndex=-1;
        for(int i=0;i<params.size();++i)if(params[i]->getNumSteps()>128 && !params[i]->isMetaParameter() && params[i]->isAutomatable()){parameterIndex=i;break;}
        float savedParameter=0;bool hasParameter=parameterIndex>=0;
        if(hasParameter){params[parameterIndex]->setValueNotifyingHost(0.31f);savedParameter=params[parameterIndex]->getValue();}
        if(auto* editor=slots[0].plugin->createEditorIfNeeded()){check(editor->getWidth()>0,format->getName()+" native editor created");delete editor;}else check(false,format->getName()+" native editor unavailable");
        for(int n=0;n<257;++n)in.setSample(0,n,0.1f*std::sin((float)n*0.09f));
        live=true;for(int b=0;b<16;++b)process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
        check(std::isfinite(out.getMagnitude(0,257)) && out.getMagnitude(0,257)>0,format->getName()+" signal processing");
        bypass(0,true);process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
        check(std::abs(out.getSample(0,120)-in.getSample(0,120))<0.0001f,format->getName()+" bypass passes dry signal");
        move(0,5);check(slots[5].plugin!=nullptr && slots[0].plugin==nullptr,"Reorder to slot 6");
        if(hasParameter)savedParameter=slots[5].plugin->getParameters()[parameterIndex]->getValue();
        auto x=preset();String serialized=x->toString();auto parsed=XmlDocument::parse(serialized);remove(5);
        err=restore(*parsed);check(err.isEmpty() && slots[5].plugin!=nullptr && slots[5].bypass,format->getName()+" serialized preset/state round-trip: "+err);
        if(hasParameter && slots[5].plugin)check(std::abs(slots[5].plugin->getParameters()[parameterIndex]->getValue()-savedParameter)<0.0001f,"Plug-in parameter restored: "+slots[5].plugin->getParameters()[parameterIndex]->getName(80)+" before="+String(savedParameter,6)+" after="+String(slots[5].plugin->getParameters()[parameterIndex]->getValue(),6));
        prepare(44100,128);live=true;bypass(5,false);process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);check(std::isfinite(out.getMagnitude(0,257)),"Reprepare 44.1 kHz / 128");
        remove(5);check(!slots[5].plugin,"Remove effect");
        for(int i=0;i<mainSlots;++i){err=load(i,*found[0]);if(err.isNotEmpty())break;}
        live=true;process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
        check(err.isEmpty() && std::isfinite(out.getMagnitude(0,257)),format->getName()+" six simultaneous serial instances");
        for(int i=0;i<slotCount;++i)remove(i);
    }
    for(auto* format:formats.getFormats())if(format->getName()=="VST3")
    {
        IsolatedScanner scanner(dataFolder());OwnedArray<PluginDescription> found;
        String identifier;
        for(auto& id:format->searchPathsForPlugins(format->getDefaultLocationsToSearch(),true,false))
            if(id.containsIgnoreCase("ValhallaVintageVerb")){identifier=id;break;}
        if(identifier.isEmpty()){report<<"SKIP: optional ValhallaVintageVerb not installed\n";continue;}
        scanner.findPluginTypesFor(*format,found,identifier);
        for(auto* d:found)known.addType(*d);
        check(!found.isEmpty(),"Valhalla VintageVerb discovery");
        if(!found.isEmpty())
        {
            auto err=load(6,*found[0]);check(err.isEmpty(),"Valhalla load on FX return: "+err);
            if(err.isEmpty())
            {
                for(auto* p:slots[6].plugin->getParameters())if(p->getName(100).equalsIgnoreCase("Mix"))p->setValueNotifyingHost(1.0f);
                dryGain=0.75f;sendGain=0.37f;returnGain=0.42f;fxMute=true;
                auto state=preset();remove(6);err=restore(*state);
                check(err.isEmpty()&&slots[6].plugin&&std::abs(sendGain.load()-0.37f)<0.0001f&&std::abs(returnGain.load()-0.42f)<0.0001f&&fxMute,"FX plugin + mixer settings preset recall");
                fxMute=false;fxSolo=true;live=true;in.clear();in.setSample(0,0,0.5f);float energy=0;
                for(int b=0;b<180;++b){process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);energy+=out.getMagnitude(0,257);in.clear();}
                check(std::isfinite(energy)&&energy>0.001f,"Valhalla return produces a reverb tail");
                if(auto* editor=slots[6].plugin->createEditorIfNeeded()){check(editor->getWidth()>0,"Valhalla native editor");delete editor;}
                remove(6);
            }
        }
    }
    XmlElement legacy("VL_MIC_HOST");legacy.setAttribute("version",1);
    auto legacyError=restore(legacy);check(legacyError.isEmpty()&&!slots[6].plugin&&!fxSolo&&!fxMute,"Version 1 presets remain compatible");
    return report;
}
