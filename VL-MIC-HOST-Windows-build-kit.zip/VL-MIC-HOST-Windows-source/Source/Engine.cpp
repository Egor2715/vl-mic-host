// SPDX-License-Identifier: AGPL-3.0-only
// Copyright (C) 2026 VL MIC HOST contributors

#include "Engine.h"
#include "Scanner.h"
#include "TestEffect.h"
using namespace juce;

Engine::Engine()
{
    formats.addDefaultFormats();
    scratch.setSize(32, blockSize);
    fxBuffer.setSize(32,blockSize);dryDelay.setSize(2,delayCapacity);dryDelay.clear();
    midi.ensureSize(65536); instrumentMidi.ensureSize(65536);
    extraBuffer.setSize(32, blockSize);
    midiCollector.ensureStorageAllocated(65536); midiCollector.reset(sampleRate);
    keyboard.addListener(&midiCollector);
    if (auto xml = XmlDocument::parse(dataFolder().getChildFile("plugins.xml"))) known.recreateFromXml(*xml);
    known.setCustomScanner(std::make_unique<IsolatedScanner>(dataFolder()));
    known.addChangeListener(this);
}
Engine::~Engine()
{
    if (midiInput) midiInput->stop();
    keyboard.removeListener(&midiCollector);
    known.removeChangeListener(this);
    devices.removeAudioCallback(this);
    devices.closeAudioDevice();
    for(auto& s:slots)if(s.plugin){s.plugin->setPlayHead(nullptr);s.plugin->releaseResources();s.plugin.reset();}
    if (auto xml = known.createXml()) xml->writeTo(dataFolder().getChildFile("plugins.xml"));
}
File Engine::dataFolder() const
{
    auto overridePath=SystemStats::getEnvironmentVariable("VL_MIC_HOST_DATA_DIR",{});
    if(overridePath.isNotEmpty()){File folder(overridePath);folder.createDirectory();return folder;}
#if defined(VL_HOST_VALIDATION)
    auto validationFolder=File::getSpecialLocation(File::currentApplicationFile).getSiblingFile("ValidationData");
    validationFolder.createDirectory();return validationFolder;
#endif
    #if JUCE_MAC
    auto f = File::getSpecialLocation(File::userApplicationDataDirectory).getChildFile("Application Support/VL MIC HOST");
#else
    auto f = File::getSpecialLocation(File::userApplicationDataDirectory).getChildFile("VL MIC HOST");
#endif
    f.createDirectory(); return f;
}
String Engine::start()
{
    auto xml = XmlDocument::parse(dataFolder().getChildFile("device.xml"));
    auto error = devices.initialise(2, 2, xml.get(), true);
    if(error.isEmpty() && !xml)
    {
        if(auto* type=devices.getCurrentDeviceTypeObject())
        {
            type->scanForDevices();auto setup=devices.getAudioDeviceSetup();
            String input,output;
            for(auto& n:type->getDeviceNames(true))if(n.containsIgnoreCase("iD4")){input=n;break;}
            for(auto& n:type->getDeviceNames(false))if(n.containsIgnoreCase("iD4")){output=n;break;}
            if(input.isNotEmpty() && output.isNotEmpty())
            {
                setup.inputDeviceName=input;setup.outputDeviceName=output;setup.sampleRate=48000;setup.bufferSize=128;
                setup.useDefaultInputChannels=false;setup.inputChannels.clear();setup.inputChannels.setRange(0,2,true);
                setup.useDefaultOutputChannels=false;setup.outputChannels.clear();setup.outputChannels.setRange(0,4,true);
                error=devices.setAudioDeviceSetup(setup,true);
            }
        }
    }
    if (error.isEmpty()) devices.addAudioCallback(this);
    return error;
}
void Engine::queueMidi(MidiMessage message)
{
    message.setTimeStamp(Time::getMillisecondCounterHiRes() * 0.001);
    midiCollector.addMessageToQueue(message);
}
void Engine::panic()
{
    const ScopedLock guard(lock);
    midiCollector.reset(sampleRate);keyboard.allNotesOff(0);panicPending = true;
}
void Engine::setExtraSource(ExtraSource source)
{
    panic(); extraSource = (int)source;
}
String Engine::selectMidiInput(const String& identifier)
{
    if (midiInput) midiInput->stop();
    midiInput.reset(); midiIdentifier.clear(); panic();
    if (identifier.isEmpty()) return {};
    auto opened = MidiInput::openDevice(identifier, &midiCollector);
    if (!opened) return "Could not open MIDI input. Reconnect the keyboard and choose it again.";
    midiIdentifier = identifier; midiInput = std::move(opened); midiInput->start();
    return {};
}
String Engine::configure(AudioPluginInstance& p, bool instrument)
{
    p.setPlayHead(&playHead);
    if (instrument)
    {
        // Kontakt may advertise many outputs. Only its main output is hosted.
        p.disableNonMainBuses();
        // AU synths with audio/sidechain inputs may accept a disabled layout but
        // fail to render it. Keep their input buses valid and feed silence.
        for(int bus=0;bus<p.getBusCount(true);++bus)p.getBus(true,bus)->enable(true);
        if (!p.acceptsMidi()) return "Choose an AU or VST3 instrument that accepts MIDI.";
    }
    else p.enableAllBuses();
    auto layout = p.getBusesLayout();
    if (layout.outputBuses.isEmpty() || (!instrument && layout.inputBuses.isEmpty()))
        return "The plug-in needs a mono or stereo main output (and an input for effects).";
    bool accepted = false;
    for (int channels : { 2, 1 })
    {
        if (!layout.inputBuses.isEmpty())
            layout.inputBuses.getReference(0) = AudioChannelSet::canonicalChannelSet(channels);
        layout.outputBuses.getReference(0) = AudioChannelSet::canonicalChannelSet(channels);
        if (p.setBusesLayout(layout)) { accepted = true; break; }
    }
    // Some instruments insist on an enabled audio input even without audio input data.
    if (!accepted && instrument && !layout.inputBuses.isEmpty())
    {
        layout.inputBuses.getReference(0) = AudioChannelSet::stereo();
        layout.outputBuses.getReference(0) = AudioChannelSet::stereo();
        accepted = p.setBusesLayout(layout);
    }
    if (!accepted || p.getTotalNumInputChannels() > 32 || p.getTotalNumOutputChannels() > 32)
        return "This plug-in does not support a mono or stereo main bus.";
    p.setRateAndBufferSizeDetails(sampleRate, blockSize);
    p.prepareToPlay(sampleRate, blockSize);
    return {};
}
String Engine::load(int index, const PluginDescription& d)
{
    if (! isPositiveAndBelow(index, slotCount)) return "Invalid slot";
    const ScopedLock guard(lock);
    String error;
    auto p = formats.createPluginInstance(d, sampleRate, blockSize, error);
    if (!p) return error.isEmpty() ? "Could not load plug-in" : error;
    if (d.isInstrument != (index == instrumentSlot)) return index == instrumentSlot ? "Choose an instrument for the INSTRUMENT slot." : "Load instruments in the dedicated INSTRUMENT slot.";
    if (auto e = configure(*p, index == instrumentSlot); e.isNotEmpty()) return e;
    if (slots[index].plugin) slots[index].plugin->releaseResources();
    slots[index] = { std::move(p), d, false };
    if(index==instrumentSlot)setExtraSource(ExtraSource::midi);
    return {};
}
void Engine::remove(int i) { if(!isPositiveAndBelow(i,slotCount))return; const ScopedLock g(lock); if (slots[i].plugin) slots[i].plugin->releaseResources(); slots[i] = {}; }
void Engine::move(int a, int b) { auto group=[](int i){return i<mainSlots?0:i<fxEnd?1:i==instrumentSlot?2:3;}; if (!isPositiveAndBelow(a,slotCount) || !isPositiveAndBelow(b,slotCount) || group(a)!=group(b) || a==instrumentSlot) return; const ScopedLock g(lock); std::swap(slots[a],slots[b]); }
void Engine::transfer(int a,int b)
{
    if(!isPositiveAndBelow(a,slotCount)||!isPositiveAndBelow(b,slotCount)||a==instrumentSlot||b==instrumentSlot)return;
    const ScopedLock g(lock);if(!slots[b].plugin){std::swap(slots[a],slots[b]);dryDelay.clear();delayPosition=0;}
}
void Engine::bypass(int i, bool b) { if(!isPositiveAndBelow(i,slotCount))return; const ScopedLock g(lock); slots[i].bypass = b; if(i==instrumentSlot) panicPending=true; }
void Engine::prepare(double sr, int bs)
{
    const ScopedLock g(lock);
    sampleRate = sr; blockSize = jmax(1,bs); scratch.setSize(32,blockSize);scratch.clear();
    fxBuffer.setSize(32,blockSize);fxBuffer.clear();extraBuffer.setSize(32,blockSize);extraBuffer.clear();dryDelay.clear();delayPosition=0;
    midiCollector.reset(sr); panicPending=true;
    previousExtraTrim=extraTrim; previousExtraGain=extraMute?0:extraGain.load();previousExtraSend=extraSend;
    playHead.rate=sr;playHead.samples=0;
    for (auto& s : slots) if (s.plugin) { s.plugin->releaseResources(); s.plugin->setRateAndBufferSizeDetails(sr,blockSize); s.plugin->prepareToPlay(sr,blockSize); }
    previousInput=inputGain.load(); previousOutput=outputGain.load();
    previousDry=dryMute?0:dryGain.load();previousSend=sendGain.load();previousReturn=fxMute?0:returnGain.load();
}
void Engine::processSlots(AudioBuffer<float>& buffer,int first,int end,int n)
{
    auto* l=buffer.getWritePointer(0);auto* r=buffer.getWritePointer(1);
    for(int i=first;i<end;++i)if(auto& s=slots[i];s.plugin&&!s.bypass)
    {
        int mainChannels=s.plugin->getMainBusNumInputChannels();
        int channels=jmax(s.plugin->getTotalNumInputChannels(),s.plugin->getTotalNumOutputChannels());
        if(mainChannels==1){FloatVectorOperations::add(l,r,n);FloatVectorOperations::multiply(l,0.5f,n);}
        for(int c=mainChannels;c<channels;++c)buffer.clear(c,0,n);
        AudioBuffer<float> block(buffer.getArrayOfWritePointers(),channels,n);midi.clear();s.plugin->processBlock(block,midi);
        if(s.plugin->getMainBusNumOutputChannels()==1)FloatVectorOperations::copy(r,l,n);
    }
}
void Engine::processInstrument(int n, bool audible)
{
    extraBuffer.clear(); instrumentMidi.clear();
    midiCollector.removeNextBlockOfMessages(instrumentMidi,n);
    const int filter=midiChannel.load();
    if (filter>0)
    {
        midi.clear();
        for (const auto event:instrumentMidi) if(event.getMessage().getChannel()==filter || event.getMessage().getChannel()==0)
            midi.addEvent(event.getMessage(),event.samplePosition);
        instrumentMidi.swapWith(midi);
    }
    const bool reset=panicPending.exchange(false) || (wasLive && !live.load());
    if (reset || !audible)
    {
        midi.clear();
        if(audible)midi.swapWith(instrumentMidi);
        else instrumentMidi.clear();
        for(int channel=1;channel<=16;++channel)
        {
            instrumentMidi.addEvent(MidiMessage::controllerEvent(channel,64,0),0);
            instrumentMidi.addEvent(MidiMessage::allNotesOff(channel),0);
            instrumentMidi.addEvent(MidiMessage::allSoundOff(channel),0);
        }
    }
    if(reset && audible)instrumentMidi.addEvents(midi,0,n,0);
    auto& slot=slots[instrumentSlot];
    if (slot.plugin && (audible || reset || instrumentWasAudible))
    {
        const int channels=jmax(2,jmax(slot.plugin->getTotalNumInputChannels(),slot.plugin->getTotalNumOutputChannels()));
        AudioBuffer<float> block(extraBuffer.getArrayOfWritePointers(),channels,n);
        slot.plugin->processBlock(block,instrumentMidi);
        if(slot.plugin->getMainBusNumOutputChannels()==1)extraBuffer.copyFrom(1,0,extraBuffer,0,0,n);
        if(!audible)extraBuffer.clear();
    }
    instrumentWasAudible=audible;
}
void Engine::audioDeviceAboutToStart(AudioIODevice* d) { prepare(d->getCurrentSampleRate(),d->getCurrentBufferSizeSamples()); }
void Engine::audioDeviceStopped() { inputPeak=0; outputPeak=0; extraPeak=0; panicPending=true; }
void Engine::process(const float* const* in, int ni, float* const* out, int no, int count)
{
    // The callback never waits for UI/plugin loading and never resizes buffers.
    const ScopedTryLock guard(lock);
    for (int c=0;c<no;++c) if(out[c]) FloatVectorOperations::clear(out[c],count);
    if (!guard.isLocked()) { ++contentionBlocks; return; }
    const int mic=micChannel.load(), dest=outputChannel.load();
    float peakIn=0, peakOut=0, peakDry=0, peakFx=0, peakExtra=0;
    int fxLatency=0;bool hasFx=false;
    for(int i=fxFirst;i<fxEnd;++i)if(slots[i].plugin&&!slots[i].bypass){hasFx=true;fxLatency+=jmax(0,slots[i].plugin->getLatencySamples());}
    fxLatencyOverflow=fxLatency>=delayCapacity;
    if(fxLatencyOverflow){hasFx=false;fxLatency=0;}
    for (int offset=0;offset<count;offset+=blockSize)
    {
        int n=jmin(blockSize,count-offset);
        auto* l=scratch.getWritePointer(0); auto* r=scratch.getWritePointer(1);
        if (mic<ni && mic>=0 && in[mic]) FloatVectorOperations::copy(l,in[mic]+offset,n); else FloatVectorOperations::clear(l,n);
        const float ig=inputGain.load(), og=outputGain.load();
        scratch.applyGainRamp(0,0,n,previousInput,ig); previousInput=ig;
        peakIn=jmax(peakIn,scratch.getMagnitude(0,0,n));
        const int source=extraSource.load();
        processInstrument(n,live.load() && source==(int)ExtraSource::midi && !slots[instrumentSlot].bypass);
        wasLive=live.load();
        if (!live.load()) continue;
        if (source==(int)ExtraSource::audio)
        {
            extraBuffer.clear(); const int input=extraChannel.load();
            if(input>=0 && input<ni && in[input]) extraBuffer.copyFrom(0,0,in[input]+offset,n);
            extraBuffer.copyFrom(1,0,extraBuffer,0,0,n);
        }
        if (source!=(int)ExtraSource::off)
        {
            const float trim=extraTrim.load(), level=extraMute?0:extraGain.load();
            for(int c=0;c<2;++c) extraBuffer.applyGainRamp(c,0,n,previousExtraTrim,trim);
            previousExtraTrim=trim;
            processSlots(extraBuffer,extraFirst,slotCount,n);
            for(int c=0;c<2;++c) extraBuffer.applyGainRamp(c,0,n,previousExtraGain,level);
            previousExtraGain=level;
            peakExtra=jmax(peakExtra,jmax(extraBuffer.getMagnitude(0,0,n),extraBuffer.getMagnitude(1,0,n)));
        }
        else extraBuffer.clear();
        FloatVectorOperations::copy(r,l,n);
        processSlots(scratch,0,mainSlots,n);
        const float dg=dryMute?0:dryGain.load(),sg=sendGain.load(),rg=(fxMute||!hasFx)?0:returnGain.load();
        for(int c=0;c<2;++c)
        {
            scratch.applyGainRamp(c,0,n,previousDry,dg);
            fxBuffer.copyFrom(c,0,scratch,c,0,n);fxBuffer.applyGainRamp(c,0,n,previousSend,sg);
            for(int j=0;j<n;++j)fxBuffer.addSample(c,j,extraBuffer.getSample(c,j)*(previousExtraSend+(extraSend.load()-previousExtraSend)*(float)(j+1)/(float)n));
            
        }
        previousDry=dg;previousSend=sg;previousExtraSend=extraSend;
        peakDry=jmax(peakDry,jmax(scratch.getMagnitude(0,0,n),scratch.getMagnitude(1,0,n)));
        if(hasFx)processSlots(fxBuffer,fxFirst,fxEnd,n);else fxBuffer.clear();
        for(int c=0;c<2;++c)fxBuffer.applyGainRamp(c,0,n,previousReturn,rg);
        previousReturn=rg;
        peakFx=jmax(peakFx,jmax(fxBuffer.getMagnitude(0,0,n),fxBuffer.getMagnitude(1,0,n)));
        for(int c=0;c<2;++c)scratch.addFrom(c,0,extraBuffer,c,0,n);
        // Align dry audio with plugin-reported FX latency (not reverb pre-delay).
        // Muting a return still processes it, so existing reverb tails advance.
        for(int j=0;j<n;++j)
        {
            int read=(delayPosition+delayCapacity-fxLatency)%delayCapacity;
            for(int c=0;c<2;++c)
            {
                dryDelay.setSample(c,delayPosition,scratch.getSample(c,j));
                scratch.setSample(c,j,(fxSolo?0:dryDelay.getSample(c,read))+fxBuffer.getSample(c,j));
            }
            delayPosition=(delayPosition+1)%delayCapacity;
        }
        scratch.applyGainRamp(0,0,n,previousOutput,og); scratch.applyGainRamp(1,0,n,previousOutput,og); previousOutput=og;
        if (mono.load()) { FloatVectorOperations::add(l,r,n); FloatVectorOperations::multiply(l,0.5f,n); FloatVectorOperations::copy(r,l,n); }
        for(int c=0;c<2;++c) for(int j=0;j<n;++j) if(!std::isfinite(scratch.getSample(c,j))) scratch.setSample(c,j,0);
        peakOut=jmax(peakOut,jmax(scratch.getMagnitude(0,0,n),scratch.getMagnitude(1,0,n)));
        const float monitorGain=monitorMuted?0.0f:1.0f;
        for(int c=0;c<2;++c) if(dest>=0 && dest+c<no && out[dest+c])
            for(int j=0;j<n;++j)
                out[dest+c][offset+j]=scratch.getSample(c,j)*(previousMonitor+(monitorGain-previousMonitor)*(float)(j+1)/(float)n);
        previousMonitor=monitorGain;
        // Stream is independent of monitor mute; overlapping routes are rejected.
        const int stream=streamChannel.load();
        if(stream>=0 && stream+1<no && (stream+1<dest || stream>dest+1))
        {
            if(out[stream]) FloatVectorOperations::copy(out[stream]+offset,l,n);
            if(out[stream+1]) FloatVectorOperations::copy(out[stream+1]+offset,r,n);
        }
        playHead.samples+=n;
    }
    inputPeak.store(jmax(inputPeak.load(),peakIn)); outputPeak.store(jmax(outputPeak.load(),peakOut));
    extraPeak.store(jmax(extraPeak.load(),peakExtra));
    dryPeak.store(jmax(dryPeak.load(),peakDry));fxPeak.store(jmax(fxPeak.load(),peakFx));
}
std::unique_ptr<XmlElement> Engine::preset()
{
    const ScopedLock g(lock);
    auto x=std::make_unique<XmlElement>("VL_MIC_HOST"); x->setAttribute("version",3);
    x->setAttribute("midiInput",midiIdentifier);
    x->setAttribute("extraSource",extraSource.load());x->setAttribute("extraChannel",extraChannel.load());x->setAttribute("midiChannel",midiChannel.load());
    x->setAttribute("extraTrim",(double)extraTrim.load());x->setAttribute("extraGain",(double)extraGain.load());x->setAttribute("extraSend",(double)extraSend.load());x->setAttribute("extraMute",extraMute.load());
    x->setAttribute("dryGain",(double)dryGain.load());x->setAttribute("sendGain",(double)sendGain.load());x->setAttribute("returnGain",(double)returnGain.load());
    x->setAttribute("dryMute",dryMute.load());x->setAttribute("fxMute",fxMute.load());x->setAttribute("fxSolo",fxSolo.load());
    x->setAttribute("inputGain",(double)inputGain.load()); x->setAttribute("outputGain",(double)outputGain.load()); x->setAttribute("mono",mono.load());
    for(int i=0;i<slotCount;++i)
    {
        auto* e=x->createNewChildElement("SLOT"); e->setAttribute("index",i); e->setAttribute("bypass",slots[i].bypass);
        if(auto* p=slots[i].plugin.get()) { e->addChildElement(slots[i].description.createXml().release()); MemoryBlock state; p->getStateInformation(state); e->createNewChildElement("STATE")->addTextElement(state.toBase64Encoding()); }
    }
    return x;
}
String Engine::restore(const XmlElement& x)
{
    if(!x.hasTagName("VL_MIC_HOST") || (x.getIntAttribute("version")<1 || x.getIntAttribute("version")>3)) return "Unsupported VL MIC HOST preset";
    const ScopedLock g(lock);
    // Stage the entire chain; any missing/failed effect leaves the existing chain intact.
    std::array<Slot,slotCount> staged;
    std::array<bool,slotCount> seen{};
    for(auto* e:x.getChildIterator())
    {
        if(!e->hasTagName("SLOT")) continue;
        int i=e->getIntAttribute("index",-1); if(!isPositiveAndBelow(i,slotCount)||seen[i]) return "Invalid preset slot"; seen[i]=true;
        if(auto* d=e->getChildByName("PLUGIN"))
        {
            PluginDescription desc; if(!desc.loadFromXml(*d)) return "Invalid plug-in description";
            String error; auto p=formats.createPluginInstance(desc,sampleRate,blockSize,error);
            if(!p) return desc.name+": "+error;
            if(desc.isInstrument!=(i==instrumentSlot))return "Invalid preset: instrument belongs in the INSTRUMENT slot.";
            if(auto err=configure(*p,i==instrumentSlot);err.isNotEmpty()) return desc.name+": "+err;
            if(auto* state=e->getChildByName("STATE")) { MemoryBlock bytes; if(!bytes.fromBase64Encoding(state->getAllSubText())) return "Invalid plug-in state"; p->setStateInformation(bytes.getData(),(int)bytes.getSize()); }
            staged[i]={std::move(p),desc,e->getBoolAttribute("bypass")};
        }
    }
    live=false;
    for(auto& s:slots) if(s.plugin) s.plugin->releaseResources();
    slots.swap(staged); panic();
    if(x.hasAttribute("midiInput"))
    {
        auto id=x.getStringAttribute("midiInput");bool available=id.isEmpty();
        for(auto info:MidiInput::getAvailableDevices())if(info.identifier==id)available=true;
        selectMidiInput(available?id:String{});
    }
    extraSource=jlimit(0,2,x.getIntAttribute("extraSource",0));extraChannel=jlimit(-1,31,x.getIntAttribute("extraChannel",1));midiChannel=jlimit(0,16,x.getIntAttribute("midiChannel",0));
    extraTrim=(float)jlimit(0.0,15.85,x.getDoubleAttribute("extraTrim",1));extraGain=(float)jlimit(0.0,3.982,x.getDoubleAttribute("extraGain",1));extraSend=(float)jlimit(0.0,1.0,x.getDoubleAttribute("extraSend",0));extraMute=x.getBoolAttribute("extraMute");
    inputGain=(float)jlimit(0.0,15.85,x.getDoubleAttribute("inputGain",1)); outputGain=(float)jlimit(0.0,3.982,x.getDoubleAttribute("outputGain",1)); mono=x.getBoolAttribute("mono");
    dryGain=(float)jlimit(0.0,3.982,x.getDoubleAttribute("dryGain",1));sendGain=(float)jlimit(0.0,1.0,x.getDoubleAttribute("sendGain",0.25));returnGain=(float)jlimit(0.0,3.982,x.getDoubleAttribute("returnGain",1));
    dryMute=x.getBoolAttribute("dryMute");fxMute=x.getBoolAttribute("fxMute");fxSolo=x.getBoolAttribute("fxSolo");dryDelay.clear();delayPosition=0;
    return {};
}

String Engine::selfTest()
{
    String report="VL MIC HOST 0.4.0 / platform validation\n";
    auto check=[&](bool ok,String name){report+=(ok?"PASS ":"FAIL ")+name+"\n";dataFolder().getChildFile("validation-progress.txt").replaceWithText(report);};
    prepare(48000,64); live=true;
    AudioBuffer<float> in(2,257),out(4,257);in.clear();out.clear();
    for(int n=0;n<257;++n){in.setSample(0,n,0.2f);in.setSample(1,n,0.4f);}
    process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(std::abs(out.getSample(0,256)-0.2f)<0.0001f && out.getSample(1,256)==out.getSample(0,256),"Empty chain, mono to stereo, oversized callback chunking");
    micChannel=1;outputChannel=2;process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(out.getMagnitude(0,0,257)==0 && std::abs(out.getSample(2,256)-0.4f)<0.0001f,"Selected microphone and output route; unused channels silent");
    live=false;process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);check(out.getMagnitude(0,257)==0,"Stopped output silent");
    live=true;micChannel=0;outputChannel=0;inputGain=0.5f;outputGain=0.5f;
    process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(std::abs(out.getSample(0,256)-0.05f)<0.0001f,"Input and output gain ramps settle correctly");
    inputGain=1;outputGain=1;
    slots[6].plugin=std::make_unique<TestEffect>();prepare(48000,64);
    for(int n=0;n<257;++n)in.setSample(0,n,0.2f);
    sendGain=0.5f;returnGain=0.25f;dryGain=0.5f;
    process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(std::abs(out.getSample(0,256)-0.125f)<0.0001f,"Parallel post-fader send + independent return gain");
    fxMute=true;process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(std::abs(out.getSample(0,256)-0.1f)<0.0001f,"FX mute preserves microphone level");
    fxMute=false;fxSolo=true;process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(std::abs(out.getSample(0,256)-0.025f)<0.0001f,"FX solo isolates return");
    dryMute=true;process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(std::abs(out.getSample(0,256))<0.0001f,"Mic mute also stops post-fader send");
    dryMute=false;fxSolo=false;dryGain=1;sendGain=1;returnGain=1;prepare(48000,64);
    in.clear();in.setSample(0,0,0.2f);process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(out.getSample(0,0)==0 && std::abs(out.getSample(0,3)-0.6f)<0.0001f,"Dry and FX align at reported plugin latency");
    bypass(6,true);in.clear();for(int n=0;n<257;++n)in.setSample(0,n,0.2f);
    process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
    check(std::abs(out.getSample(0,256)-0.2f)<0.0001f,"All-bypassed FX return cannot double dry voice");
    remove(6);dryGain=1;sendGain=0.25f;returnGain=1;prepare(48000,64);
    for(auto* format:formats.getFormats())
    {
        String identifier;
        if(format->getName()=="VST3")
        {
            auto ids=format->searchPathsForPlugins(format->getDefaultLocationsToSearch(),true,false);
            for(auto& id:ids)if(id.containsIgnoreCase("FabFilter Pro-Q 4")){identifier=id;break;}
        }
        else if(format->getName()=="AudioUnit")
        {
            auto ids=format->searchPathsForPlugins(format->getDefaultLocationsToSearch(),true,false);
            for(auto& id:ids)if(id.contains("aumf,FQ4p,FabF")){identifier=id;break;}
            if(identifier.isEmpty())for(auto& id:ids)if(id.contains("aufx,dcmp,appl")){identifier=id;break;}
        }
        if(identifier.isEmpty()){report<<"SKIP: optional "+format->getName()+" test effect not installed\n";continue;}
        IsolatedScanner scanner(dataFolder());
        OwnedArray<PluginDescription> invalid;
        check(!scanner.findPluginTypesFor(*format,invalid,"__vl_scanner_failure_test__"),format->getName()+" failed worker is contained");
        OwnedArray<PluginDescription> found;scanner.findPluginTypesFor(*format,found,identifier);
        check(!found.isEmpty(),format->getName()+" discovery: "+identifier);
        for(auto* d:found)known.addType(*d);
        if(found.isEmpty())continue;
        auto err=load(0,*found[0]);check(err.isEmpty(),format->getName()+" instance: "+err);if(err.isNotEmpty())continue;
        auto& params=slots[0].plugin->getParameters();
        int parameterIndex=-1;
        for(int i=0;i<params.size();++i)if(params[i]->getNumSteps()>128 && !params[i]->isMetaParameter() && params[i]->isAutomatable()){parameterIndex=i;break;}
        float savedParameter=0;bool hasParameter=parameterIndex>=0;
        if(hasParameter){params[parameterIndex]->setValueNotifyingHost(0.31f);savedParameter=params[parameterIndex]->getValue();}
        if(auto* editor=slots[0].plugin->createEditorIfNeeded()){check(editor->getWidth()>0,format->getName()+" native editor created");delete editor;}else check(false,format->getName()+" native editor unavailable");
        for(int n=0;n<257;++n)in.setSample(0,n,0.1f*std::sin((float)n*0.09f));
        live=true;for(int b=0;b<16;++b)process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
        check(std::isfinite(out.getMagnitude(0,257)) && out.getMagnitude(0,257)>0,format->getName()+" signal processing");
        bypass(0,true);process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
        check(std::abs(out.getSample(0,120)-in.getSample(0,120))<0.0001f,format->getName()+" bypass passes dry signal");
        move(0,5);check(slots[5].plugin!=nullptr && slots[0].plugin==nullptr,"Reorder to slot 6");
        if(hasParameter)savedParameter=slots[5].plugin->getParameters()[parameterIndex]->getValue();
        auto x=preset();String serialized=x->toString();auto parsed=XmlDocument::parse(serialized);remove(5);
        err=restore(*parsed);check(err.isEmpty() && slots[5].plugin!=nullptr && slots[5].bypass,format->getName()+" serialized preset/state round-trip: "+err);
        if(hasParameter && slots[5].plugin)check(std::abs(slots[5].plugin->getParameters()[parameterIndex]->getValue()-savedParameter)<0.0001f,"Plug-in parameter restored: "+slots[5].plugin->getParameters()[parameterIndex]->getName(80)+" before="+String(savedParameter,6)+" after="+String(slots[5].plugin->getParameters()[parameterIndex]->getValue(),6));
        prepare(44100,128);live=true;bypass(5,false);process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);check(std::isfinite(out.getMagnitude(0,257)),"Reprepare 44.1 kHz / 128");
        remove(5);check(!slots[5].plugin,"Remove effect");
        for(int i=0;i<mainSlots;++i){err=load(i,*found[0]);if(err.isNotEmpty())break;}
        live=true;process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);
        check(err.isEmpty() && std::isfinite(out.getMagnitude(0,257)),format->getName()+" six simultaneous serial instances");
        for(int i=0;i<slotCount;++i)remove(i);
    }
    for(auto* format:formats.getFormats())if(format->getName()=="VST3")
    {
        IsolatedScanner scanner(dataFolder());OwnedArray<PluginDescription> found;
        String identifier;
        for(auto& id:format->searchPathsForPlugins(format->getDefaultLocationsToSearch(),true,false))
            if(id.containsIgnoreCase("ValhallaVintageVerb")){identifier=id;break;}
        if(identifier.isEmpty()){report<<"SKIP: optional ValhallaVintageVerb not installed\n";continue;}
        scanner.findPluginTypesFor(*format,found,identifier);
        for(auto* d:found)known.addType(*d);
        check(!found.isEmpty(),"Valhalla VintageVerb discovery");
        if(!found.isEmpty())
        {
            auto err=load(6,*found[0]);check(err.isEmpty(),"Valhalla load on FX return: "+err);
            if(err.isEmpty())
            {
                for(auto* p:slots[6].plugin->getParameters())if(p->getName(100).equalsIgnoreCase("Mix"))p->setValueNotifyingHost(1.0f);
                dryGain=0.75f;sendGain=0.37f;returnGain=0.42f;fxMute=true;
                auto state=preset();remove(6);err=restore(*state);
                check(err.isEmpty()&&slots[6].plugin&&std::abs(sendGain.load()-0.37f)<0.0001f&&std::abs(returnGain.load()-0.42f)<0.0001f&&fxMute,"FX plugin + mixer settings preset recall");
                fxMute=false;fxSolo=true;live=true;in.clear();in.setSample(0,0,0.5f);float energy=0;
                for(int b=0;b<180;++b){process(in.getArrayOfReadPointers(),2,out.getArrayOfWritePointers(),4,257);energy+=out.getMagnitude(0,257);in.clear();}
                check(std::isfinite(energy)&&energy>0.001f,"Valhalla return produces a reverb tail");
                if(auto* editor=slots[6].plugin->createEditorIfNeeded()){check(editor->getWidth()>0,"Valhalla native editor");delete editor;}
                remove(6);
            }
        }
    }
    XmlElement legacy("VL_MIC_HOST");legacy.setAttribute("version",1);
    auto legacyError=restore(legacy);check(legacyError.isEmpty()&&!slots[6].plugin&&!fxSolo&&!fxMute,"Version 1 presets remain compatible");
    return report;
}

String Engine::channelTest()
{
    String report="VL MIC HOST 0.4.0 / second channel validation\n";
    auto check=[&](bool ok,const String& name){report+=(ok?"PASS ":"FAIL ")+name+"\n";dataFolder().getChildFile("channel-progress.txt").replaceWithText(report);};
    prepare(48000,64);live=true;streamChannel=2;
    AudioBuffer<float> input(2,257),output(4,257);
    for(int n=0;n<257;++n){input.setSample(0,n,.1f);input.setSample(1,n,.2f);}
    auto run=[&]{process(input.getArrayOfReadPointers(),2,output.getArrayOfWritePointers(),4,257);};
    auto level=[&](float expected){return std::abs(output.getSample(2,256)-expected)<.0001f;};
    extraSource=(int)ExtraSource::audio;extraChannel=1;run();
    check(level(.3f),"Mic and guitar are mixed simultaneously, mono guitar to stereo");
    extraTrim=.5f;extraGain=.5f;run();check(level(.15f),"Channel 2 independent trim and fader");
    extraMute=true;run();check(level(.1f),"Muting channel 2 preserves voice");
    extraMute=false;dryMute=true;run();check(level(.05f),"Muting mic preserves channel 2");
    monitorMuted=true;run();check(level(.05f) && output.getSample(0,256)==0 && output.getSample(1,256)==0,"Monitor mute preserves both recording channels");
    monitorMuted=false;dryMute=false;extraTrim=1;extraGain=1;
    slots[extraFirst].plugin=std::make_unique<TestEffect>();prepare(48000,64);run();
    check(level(.5f),"Guitar insert processes channel 2 only");
    bypass(extraFirst,true);run();check(level(.3f),"Guitar insert bypass");
    move(extraFirst,slotCount-1);check(slots[slotCount-1].plugin!=nullptr,"Reorder inside channel 2 chain");
    move(slotCount-1,fxFirst);check(slots[slotCount-1].plugin!=nullptr && !slots[fxFirst].plugin,"Reorder cannot cross channel boundaries");remove(slotCount-1);
    slots[fxFirst].plugin=std::make_unique<TestEffect>();sendGain=0;extraSend=.5f;returnGain=.5f;prepare(48000,64);run();
    check(level(.4f),"Channel 2 post-fader send reaches shared reverb");
    extraMute=true;run();check(level(.1f),"Channel 2 mute also stops its send");remove(fxFirst);extraMute=false;extraSend=0;
    extraSource=(int)ExtraSource::midi;
    auto instrument=std::make_unique<TestInstrument>();auto* synth=instrument.get();slots[instrumentSlot].plugin=std::move(instrument);
    prepare(48000,64);run();queueMidi(MidiMessage::noteOn(1,60,(uint8)100));run();check(level(.25f),"MIDI note produces instrument + mic mix");
    queueMidi(MidiMessage::pitchWheel(1,10000));queueMidi(MidiMessage::controllerEvent(1,64,127));run();
    queueMidi(MidiMessage::noteOff(1,60));run();check(level(.25f) && synth->lastPitch==10000 && synth->sustain,"Sustain and pitch bend reach the instrument");
    panic();run();check(level(.1f) && !synth->sustain,"Panic stops sustained notes without muting mic");
    midiChannel=2;queueMidi(MidiMessage::noteOn(1,60,(uint8)100));run();check(level(.1f),"MIDI channel filter rejects other channels");
    queueMidi(MidiMessage::noteOn(2,60,(uint8)100));run();check(level(.25f),"Selected MIDI channel reaches instrument");
    live=false;run();check(output.getMagnitude(0,257)==0 && !synth->sounding,"Stop audio sends notes off and silences all outputs");live=true;
    setExtraSource(ExtraSource::audio);run();check(level(.3f) && !synth->sounding,"Switch from MIDI to guitar stops old instrument notes");
    remove(instrumentSlot);extraSource=(int)ExtraSource::midi;run();check(level(.1f),"Empty instrument slot stays silent, mic still works");
    extraSource=(int)ExtraSource::audio;extraTrim=.7f;extraGain=.8f;extraSend=.3f;extraMute=true;midiChannel=3;
    auto saved=preset();extraSource=0;extraMute=false;auto error=restore(*saved);
    check(error.isEmpty() && extraSource==1 && extraMute && std::abs(extraTrim.load()-.7f)<.0001f && midiChannel==3 && !live,"Version 3 mixer and channel settings recall with audio stopped");
    XmlElement legacy("VL_MIC_HOST");legacy.setAttribute("version",2);error=restore(legacy);
    check(error.isEmpty() && extraSource==0,"Old voice presets keep channel 2 off");
    prepare(44100,128);extraSource=1;live=true;run();check(level(.3f),"Both audio channels reprepare at 44.1 kHz / 128 samples");
    // Verify an installed synth actually produces audio from MIDI in both formats.
    for(auto description:known.getTypes())if((description.name=="Twin 3" || description.name=="Serum") && description.isInstrument)
    {
        auto error=load(instrumentSlot,description);
        check(error.isEmpty(),description.name+" "+description.pluginFormatName+" instrument loads: "+error);
        if(error.isNotEmpty())continue;
        dryMute=true;extraSource=2;midiChannel=0;extraTrim=1;extraGain=1;extraSend=0;prepare(48000,64);live=true;run();
        queueMidi(MidiMessage::noteOn(1,60,(uint8)100));float energy=0;
        for(int i=0;i<32;++i){run();energy+=output.getMagnitude(2,0,257);}
        check(std::isfinite(energy) && energy>.001f,description.name+" "+description.pluginFormatName+" MIDI generates audible stereo signal");
        // Its generated audio can pass through the second channel effect chain.
        String loadError;for(auto effect:known.getTypes())if(effect.name=="Pro-Q 4" && effect.pluginFormatName==description.pluginFormatName){loadError=load(extraFirst,effect);break;}
        run();check(loadError.isEmpty() && slots[extraFirst].plugin && output.getMagnitude(2,0,257)>0,"Instrument followed by an audio insert");remove(extraFirst);
        bypass(instrumentSlot,true);run();check(output.getMagnitude(2,0,257)==0,"Instrument bypass silences its output");
        bypass(instrumentSlot,false);panic();run();queueMidi(MidiMessage::noteOn(1,60,(uint8)100));run();
        if(description.name=="Serum" && description.pluginFormatName=="VST3")
        {
            panic();dryMute=false;extraMute=false;inputGain=1;outputGain=1;dryGain=1;sendGain=.25f;extraGain=1;extraTrim=1;
            preset()->writeTo(dataFolder().getChildFile("VL - Serum Channel 2.vlmic"));
        }
        auto state=preset();remove(instrumentSlot);error=restore(*state);
        check(error.isEmpty() && slots[instrumentSlot].plugin,description.name+" "+description.pluginFormatName+" instrument preset restore");remove(instrumentSlot);
    }
    dryMute=false;extraSource=0;midiChannel=0;
    // Actual installed plug-ins: discovery, bus layout, GUI, state and a MIDI block.
    for(auto* format:formats.getFormats())if(format->getName()=="VST3")
    {
        const auto identifier=File("/Library/Audio/Plug-Ins/VST3/Kontakt 8.vst3");
        if(!identifier.exists()){report<<"SKIP Kontakt 8: not installed\n";continue;}
        IsolatedScanner scanner(dataFolder());OwnedArray<PluginDescription> found;
        scanner.findPluginTypesFor(*format,found,identifier.getFullPathName());
        check(!found.isEmpty(),"Kontakt 8 VST3 discovery");
        for(auto* d:found)known.addType(*d);
        if(found.isEmpty())continue;
        error=load(instrumentSlot,*found[0]);check(error.isEmpty(),"Kontakt 8 loads as MIDI instrument: "+error);
        if(error.isNotEmpty())continue;
        if(auto* editor=slots[instrumentSlot].plugin->createEditorIfNeeded()){check(editor->getWidth()>0 && editor->getHeight()>0,"Kontakt 8 native editor");delete editor;}else check(false,"Kontakt 8 native editor");
        extraSource=2;queueMidi(MidiMessage::noteOn(1,60,(uint8)100));run();panic();run();
        check(std::isfinite(output.getMagnitude(0,257)),"Kontakt MIDI processing (empty rack; no sample library loaded)");
        auto state=preset();remove(instrumentSlot);error=restore(*state);
        check(error.isEmpty() && slots[instrumentSlot].plugin && extraSource==2,"Kontakt instrument state + channel preset round-trip: "+error);remove(instrumentSlot);
    }
    return report;
}
