# Windows x64 port — build pending

See WINDOWS-README.txt and Packaging/build-windows.ps1. This port uses WASAPI/DirectSound and VST3; AU/CoreAudio and ASIO are not enabled on Windows. Windows compilation and device validation remain pending. The original macOS documentation below describes the shared engine and its original platform.

# NIGHT interface — v0.3.0

Dark graphite panels, mint microphone controls, lavender FX return, custom rotary controls and faders, and a matching VL macOS icon. The audio engine and preset format are unchanged from v0.2.0.

# VL MIC HOST — 0.2.0 mixer

Native Apple Silicon macOS audio effect host, built with JUCE 8.0.6. Requires macOS 12 or later and native arm64 AU/VST3 effects. No Studio One session is required.

## Build

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_ARCHITECTURES=arm64
cmake --build build -j 6
```

CMake fetches the pinned JUCE 8.0.6 tag. For an existing checkout, pass `-DJUCE_PATH=/absolute/path/to/JUCE`. The app is created under `build/VLMicHost_artefacts/Release/VL MIC HOST.app`. Xcode Command Line Tools and CMake are required; no Projucer is needed.

## Architecture

- `Engine`: six microphone inserts plus two parallel FX-return inserts, format discovery, bus negotiation, state serialization, independent audio processing entry point.
- `AudioDeviceManager`: current CoreAudio transport; separate input/output devices, device clock and buffer controls.
- `MainPanel`: UI, native plugin windows, library scanner and file dialogs. It owns editors and closes them before replacing or removing processors.
- Future VL MIC transport can consume the processed stereo stream from the same engine. No HAL driver or virtual microphone is installed by this version.
- Mono input duplicates into the stereo chain. Stereo effects receive stereo; mono-only effects receive a fold-down which is duplicated back to stereo. Auxiliary buses receive silence (up to 32 total channels), preserving compatibility with AU effects that require valid sidechain buffers. A basic continuous playhead supplies time and a fixed 120 BPM.
- Host buffers are allocated when preparing the device, not per audio callback. Large callbacks are split into prepared-size blocks. Structural edits use a nonblocking try-lock in the callback and produce silence while the chain is being changed. Third-party plugins can have their own allocation and locking behavior.
- Gain changes use block ramps. Plugin latency is shown; bypass is dry, skips processing, cuts tails and can cause a transition click. The dry branch is delayed by the FX chain's reported latency (up to 262143 samples); reverb pre-delay is not removed.
- Presets use XML, plugin identity, base64 binary state, gain and mono output mode. Preset loading stages a replacement chain and leaves the old chain intact on a reported load failure. Device routing is intentionally configured separately.
- Startup and preset loading leave the output stopped. App shutdown saves the last chain and CoreAudio settings in `~/Library/Application Support/VL MIC HOST/`.

## Scope and known limitations

AUv2 and VST3 native Apple Silicon effects; no Intel bridge, instruments, MIDI routing or AUv3 asynchronous instantiation. Discovery uses one disposable subprocess per candidate, runs plugin initialization on its main thread, and skips crashes or 60-second timeouts. Results are saved incrementally; full paths and errors are recorded in `scan-log.txt`. The priority scan button checks installed Waves WaveShell, UAD/uaudio FabFilter and Valhalla VST3 packages. WaveShell discovery returns the individual effects. Full AU/VST3 scans remain available from Options. Previously blacklisted plugins can be removed from the blacklist using the library menu and rescanned.

Loaded effects still run inside the audio host: a plugin that crashes during actual playback can terminate the app. Stop audio before scanning. Six microphone and two FX slots are fixed; ordering uses up/down buttons. Slot menus can move an instance with its state between the microphone and FX channel. Native plugin editors are hosted in separate windows. No audio recording, limiter, automatic loudness normalization, autostart or virtual audio device is included.

This release is distributed under AGPL-3.0-only. See LICENSE and Licenses. The installer includes corresponding source and the exact JUCE 8.0.6 framework used by this build. The app is ad-hoc signed, without Developer ID or Apple notarization.

## Validation

The Diagnostics button runs a separate engine on synthetic audio (does not change the user's chain). On this development Mac it discovers FabFilter Pro-Q 4 AU and VST3, checks audio processing, native editor creation, bypass, six inserts, reorder, parameter-state recall and sample-rate/buffer changes. It requires those plugins to be installed; missing test plugins are reported explicitly. `validation.txt` and `validation-progress.txt` are saved in the application data folder. The command-line `--self-test` path is also available from an ordinary logged-in GUI terminal; restricted execution environments may not be allowed to initialize AppKit.

Diagnostics are not an acoustic round-trip measurement. Test the complete microphone → interface → host → Audient loopback → recorder route on the intended recording setup.

## References

- [JUCE source and licensing](https://github.com/juce-framework/JUCE/tree/8.0.6)
- [Audient iD4 MKII loopback routing](https://support.audient.com/hc/en-us/articles/360054621372-iD4-MKII-How-Do-I-Set-Up-Loopback)

## Mixer 0.2

The microphone inserts feed a channel fader and post-fader send. FX is processed in a separate stereo buffer, then the return fader feeds the master sum. Mic mute cuts dry audio and new sends; FX mute keeps processing tails but mutes their output. FX solo isolates the return. Empty or fully bypassed FX chains return silence. Reverb plugins must be set to 100% wet by the user. Preset schema 2 stores all eight slots, send/return/channel gains and mute/solo; schema 1 is accepted with empty FX. Diagnostics cover the parallel sum, mute/solo, latency alignment, legacy recall, Valhalla loading and an impulse/reverb-tail test.
