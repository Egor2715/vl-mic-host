Steinberg ASIO SDK 2.3 interface headers, copyright Steinberg Media Technologies GmbH.

This project uses the GPLv3 option of the original dual license, retained in
LICENSE.txt. GPLv3 full text is also included in ../../Licenses/GPL-3.0.txt.
The combined application is distributed under AGPL-3.0-only.
ASIO is a trademark of Steinberg Media Technologies GmbH.

Unmodified interfaces: asio.h, asiosys.h, iasiodrv.h.
Source of this copy: JUCE's bundled ASIO interfaces:
https://github.com/juce-framework/JUCE/tree/master/modules/juce_audio_devices/native/asio
The exact files used are included here; no separate SDK download is needed.
JUCE 8.0.6 is retained for the host, with this directory added to its include path.

This SDK supplies interface definitions, not an audio interface driver.
Users install their Windows x64 ASIO driver from their audio hardware vendor.
