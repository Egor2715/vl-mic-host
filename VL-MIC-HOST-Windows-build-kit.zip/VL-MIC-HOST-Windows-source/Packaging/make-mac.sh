#!/bin/bash
set -euo pipefail
app_bundle="${1:?Pass the built Universal .app}"
juce_root="${2:?Pass the JUCE 8.0.6 source directory}"
output_dir="${3:?Pass an output directory}"
source_root="$(cd "$(dirname "$0")/.." && pwd)"
release_version="0.6.7"
executable="$app_bundle/Contents/MacOS/VL MIC HOST"
for architecture in arm64 x86_64; do
  lipo -verify_arch "$architecture" "$executable"
  if ! otool -arch "$architecture" -l "$executable" | awk '/LC_BUILD_VERSION/{found=1} found && /minos/{print $2;exit}' | grep -qx '15.0'; then
    echo "Expected macOS 15.0 deployment target for $architecture" >&2
    exit 1
  fi
done
if [ "$(/usr/libexec/PlistBuddy -c 'Print :LSMinimumSystemVersion' "$app_bundle/Contents/Info.plist")" != '15.0' ]; then
  echo 'Info.plist must explicitly require macOS 15.0' >&2
  exit 1
fi
bash "$source_root/Packaging/make-dmg.sh" "$app_bundle" "$juce_root" "$output_dir"
output_dir="$(cd "$output_dir" && pwd)"
package_temp="$(mktemp -d "${TMPDIR:-/tmp}/vl-mac-pkg.XXXXXX")"
payload="$package_temp/Payload"
mkdir -p "$payload/Applications"
ditto "$output_dir/Installer-files/VL MIC HOST.app" "$payload/Applications/VL MIC HOST.app"
pkgbuild --analyze --root "$payload" "$package_temp/Components.plist"
/usr/libexec/PlistBuddy -c 'Set :0:BundleIsRelocatable false' "$package_temp/Components.plist"
/usr/libexec/PlistBuddy -c 'Set :0:BundleHasStrictIdentifier true' "$package_temp/Components.plist"
/usr/libexec/PlistBuddy -c 'Set :0:BundleOverwriteAction upgrade' "$package_temp/Components.plist"
pkgbuild --root "$payload" --component-plist "$package_temp/Components.plist" \
  --identifier audio.vl.michost.installer --version "$release_version" \
  --install-location / "$package_temp/VL-MIC-HOST-component.pkg"
mkdir -p "$package_temp/Resources"
cp "$source_root/LICENSE" "$package_temp/Resources/LICENSE.txt"
cp "$source_root/Packaging/Установка.txt" "$package_temp/Resources/Installation.txt"
cat > "$package_temp/Distribution.xml" <<EOF
<?xml version="1.0" encoding="utf-8"?>
<installer-gui-script minSpecVersion="2">
  <title>VL MIC HOST ${release_version} — Mac Universal</title>
  <options customize="never" hostArchitectures="arm64,x86_64" require-scripts="false"/>
  <allowed-os-versions><os-version min="15.0"/></allowed-os-versions>
  <domains enable_localSystem="true" enable_currentUserHome="false" enable_anywhere="false"/>
  <welcome file="Installation.txt" mime-type="text/plain"/>
  <license file="LICENSE.txt" mime-type="text/plain"/>
  <choices-outline><line choice="vl-host"/></choices-outline>
  <choice id="vl-host" visible="false" title="VL MIC HOST"><pkg-ref id="audio.vl.michost.installer"/></choice>
  <pkg-ref id="audio.vl.michost.installer" version="${release_version}" onConclusion="none">VL-MIC-HOST-component.pkg</pkg-ref>
</installer-gui-script>
EOF
productbuild --distribution "$package_temp/Distribution.xml" --package-path "$package_temp" \
  --resources "$package_temp/Resources" "$output_dir/VL-MIC-HOST-${release_version}-Mac-Universal.pkg"
pkgutil --check-signature "$output_dir/VL-MIC-HOST-${release_version}-Mac-Universal.pkg" || true
(cd "$output_dir" && shasum -a 256 VL-MIC-HOST-${release_version}-Mac-Universal.pkg \
  VL-MIC-HOST-${release_version}-Mac-Universal.dmg VL-MIC-HOST-${release_version}-Mac-Universal.zip > SHA256SUMS.txt)
printf 'PKG staging retained: %s\n' "$package_temp"
