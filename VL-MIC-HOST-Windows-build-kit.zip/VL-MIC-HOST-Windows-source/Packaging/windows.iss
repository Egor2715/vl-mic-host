#define AppVersion "0.5.0"
[Setup]
AppId={{EA0C7889-6C14-4C97-9376-766C38139DB4}
AppName=VL MIC HOST
AppVersion={#AppVersion}
AppPublisher=VL
DefaultDirName={localappdata}\Programs\VL MIC HOST
DefaultGroupName=VL MIC HOST
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
UninstallDisplayIcon={app}\VL MIC HOST.exe
LicenseFile=..\LICENSE
OutputDir=..\dist
OutputBaseFilename=VL-MIC-HOST-{#AppVersion}-NIGHT-Windows-x64-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
[Files]
Source: "..\build\VLMicHost_artefacts\Release\VL MIC HOST.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\LICENSE"; DestDir: "{app}"; DestName: "LICENSE.txt"
Source: "..\Licenses\*"; DestDir: "{app}\Licenses"; Flags: recursesubdirs createallsubdirs
Source: "..\WINDOWS-README.txt"; DestDir: "{app}"
Source: "..\dist\VL-MIC-HOST-Windows-Complete-Source.zip"; DestDir: "{app}\Source"
[Icons]
Name: "{group}\VL MIC HOST"; Filename: "{app}\VL MIC HOST.exe"
Name: "{group}\Uninstall VL MIC HOST"; Filename: "{uninstallexe}"
[Run]
Filename: "{app}\VL MIC HOST.exe"; Description: "Launch VL MIC HOST"; Flags: nowait postinstall skipifsilent
