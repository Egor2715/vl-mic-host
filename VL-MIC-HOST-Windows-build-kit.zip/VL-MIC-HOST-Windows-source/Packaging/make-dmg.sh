#!/bin/bash
set -euo pipefail
# Usage: make-dmg.sh /path/to/app /path/to/JUCE /path/to/output-directory
app_bundle="${1:?Pass the built .app}"
juce_root="${2:?Pass the JUCE 8.0.6 source directory}"
output_dir="${3:?Pass an output directory}"
source_root="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$output_dir"
output_dir="$(cd "$output_dir" && pwd)"
package_temp="$(mktemp -d "${TMPDIR:-/tmp}/vl-mic-package.XXXXXX")"
# Keep staging for inspection; never copy any user application-support data.
stage="$package_temp/stage"
source_stage="$package_temp/VL-MIC-HOST-0.3.0-Source"
mkdir -p "$stage" "$source_stage"
ditto "$source_root" "$source_stage"
ditto "$juce_root" "$source_stage/JUCE"
cp "$source_root/Packaging/BUILD-OFFLINE.txt" "$source_stage/BUILD.txt"
ditto -c -k --keepParent "$source_stage" "$stage/VL-MIC-HOST-0.3.0-Complete-Source.zip"
ditto "$app_bundle" "$stage/VL MIC HOST.app"
mkdir -p "$stage/VL MIC HOST.app/Contents/Resources/Licenses"
cp "$source_root/LICENSE" "$stage/LICENSE.txt"
cp "$source_root/LICENSE" "$stage/VL MIC HOST.app/Contents/Resources/Licenses/AGPL-3.0.txt"
ditto "$source_root/Licenses" "$stage/VL MIC HOST.app/Contents/Resources/Licenses"
cp "$source_root/Packaging/Установка.txt" "$stage/Установка.txt"
ln -s /Applications "$stage/Applications"
codesign --force --deep --sign - "$stage/VL MIC HOST.app"
codesign --verify --deep --strict "$stage/VL MIC HOST.app"
# makehybrid avoids the temporary disk-device requirement of hdiutil create.
hdiutil makehybrid -hfs -hfs-volume-name 'VL MIC HOST NIGHT' -o "$package_temp/installer-hybrid.dmg" "$stage"
hdiutil convert "$package_temp/installer-hybrid.dmg" -format UDZO -ov -o "$output_dir/VL-MIC-HOST-0.3.0-NIGHT-Apple-Silicon.dmg"
hdiutil verify "$output_dir/VL-MIC-HOST-0.3.0-NIGHT-Apple-Silicon.dmg"
(cd "$output_dir" && shasum -a 256 VL-MIC-HOST-0.3.0-NIGHT-Apple-Silicon.dmg > VL-MIC-HOST-0.3.0-NIGHT-Apple-Silicon.sha256)
printf 'Staging retained: %s\n' "$package_temp"
