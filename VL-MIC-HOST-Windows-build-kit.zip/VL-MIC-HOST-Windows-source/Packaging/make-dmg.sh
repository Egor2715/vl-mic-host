#!/bin/bash
set -euo pipefail
app_bundle="${1:?Pass the built .app}"
juce_root="${2:?Pass the JUCE 8.0.6 source directory}"
output_dir="${3:?Pass an output directory}"
source_root="$(cd "$(dirname "$0")/.." && pwd)"
release_version="0.4.2"
mkdir -p "$output_dir"
output_dir="$(cd "$output_dir" && pwd)"
package_temp="$(mktemp -d "${TMPDIR:-/tmp}/vl-mic-package.XXXXXX")"
stage="$package_temp/VL MIC HOST ${release_version} Mac"
source_stage="$package_temp/VL-MIC-HOST-${release_version}-Source"
mkdir -p "$stage" "$source_stage"
# Copy only the release source. Never include build trees or personal settings.
for item in Source Assets ThirdParty Packaging Licenses LICENSE README.md WINDOWS-README.txt CMakeLists.txt; do
  ditto "$source_root/$item" "$source_stage/$item"
done
if [ -d "$source_root/Presets" ]; then ditto "$source_root/Presets" "$source_stage/Presets"; fi
ditto "$juce_root" "$source_stage/JUCE"
cp "$source_root/Packaging/BUILD-OFFLINE.txt" "$source_stage/BUILD.txt"
ditto -c -k --keepParent "$source_stage" "$stage/VL-MIC-HOST-${release_version}-Complete-Source.zip"
ditto "$app_bundle" "$stage/VL MIC HOST.app"
mkdir -p "$stage/VL MIC HOST.app/Contents/Resources/Licenses"
cp "$source_root/LICENSE" "$stage/LICENSE.txt"
cp "$source_root/LICENSE" "$stage/VL MIC HOST.app/Contents/Resources/Licenses/AGPL-3.0.txt"
ditto "$source_root/Licenses" "$stage/VL MIC HOST.app/Contents/Resources/Licenses"
cp "$source_root/Packaging/Установка.txt" "$stage/Установка.txt"
cp "$source_root/README.md" "$stage/README.md"
if [ -d "$source_root/Presets" ]; then ditto "$source_root/Presets" "$stage/Presets"; fi
ln -s /Applications "$stage/Applications"
codesign --force --deep --sign - "$stage/VL MIC HOST.app"
codesign --verify --deep --strict "$stage/VL MIC HOST.app"
# ZIP offers installation without a mounted volume, with complete source included.
ditto -c -k --keepParent "$stage" "$output_dir/VL-MIC-HOST-${release_version}-Apple-Silicon.zip"
ditto "$stage" "$output_dir/Installer-files"
hdiutil makehybrid -hfs -hfs-volume-name "VL MIC HOST ${release_version}" -o "$package_temp/installer-hybrid.dmg" "$stage"
hdiutil convert "$package_temp/installer-hybrid.dmg" -format UDZO -ov -o "$output_dir/VL-MIC-HOST-${release_version}-NIGHT-Apple-Silicon.dmg"
hdiutil verify "$output_dir/VL-MIC-HOST-${release_version}-NIGHT-Apple-Silicon.dmg"
(cd "$output_dir" && shasum -a 256 VL-MIC-HOST-${release_version}-Apple-Silicon.zip VL-MIC-HOST-${release_version}-NIGHT-Apple-Silicon.dmg > SHA256SUMS.txt)
printf 'Staging retained: %s\n' "$package_temp"
