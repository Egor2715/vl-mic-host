#!/usr/bin/env python3
"""Isolated discovery + real load/render/editor lifecycle audit; no user settings."""
import argparse, pathlib, subprocess, os, json, time, xml.etree.ElementTree as ET
p=argparse.ArgumentParser();p.add_argument('executable');p.add_argument('output');p.add_argument('--root',action='append',default=[]);p.add_argument('--catalog');p.add_argument('--filter',default='');p.add_argument('--timeout',type=int,default=30);a=p.parse_args()
out=pathlib.Path(a.output).resolve();out.mkdir(parents=True,exist_ok=True)
env=dict(os.environ,VL_MIC_HOST_DATA_DIR=str(out/'WorkerData'))
items=[]
roots=a.root or (['/Library/Audio/Plug-Ins/VST3','/Library/Audio/Plug-Ins/VST',str(pathlib.Path.home()/'Library/Audio/Plug-Ins/VST3'),str(pathlib.Path.home()/'Library/Audio/Plug-Ins/VST')] if os.name!='nt' else [os.path.join(os.environ['CommonProgramFiles'],'VST3'),os.path.join(os.environ['ProgramFiles'],'VSTPlugins'),os.path.join(os.environ['ProgramFiles'],'Steinberg','VstPlugins')])
for root in roots:
 for folder,dirs,files in os.walk(root):
  for name in list(dirs)+files:
   ext=pathlib.Path(name).suffix.lower()
   if ext in ('.vst3','.vst','.dll'):
    path=pathlib.Path(folder)/name
    if not a.filter or a.filter.lower() in str(path).lower():items.append(('VST3' if ext=='.vst3' else 'VST',str(path.resolve())))
    if name in dirs:dirs.remove(name)
items=sorted(set(items));records=[]
def run(mode,request,response,timeout):
 try:
  completed=subprocess.run([str(pathlib.Path(a.executable).resolve()),mode,str(request),str(response)],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=timeout)
  return 'exit '+str(completed.returncode)
 except subprocess.TimeoutExpired:return 'timeout'
for index,(fmt,path) in enumerate(items):
 job=out/'Jobs'/str(index);job.mkdir(parents=True,exist_ok=True);request=job/'request.xml';response=job/'response.xml'
 ET.ElementTree(ET.Element('SCAN',format=fmt,identifier=path)).write(request)
 state=run('--scan-worker',request,response,300 if 'waveshell' in path.lower() else a.timeout)
 r={'format':fmt,'file':path,'discovery':state,'plugins':[]}
 if response.exists():
  try:
   scan=ET.parse(response).getroot();r['discovery']='ok';r['error']=scan.get('error','')
   for k,d in enumerate(scan):
    req=job/('plugin-'+str(k)+'.xml');res=job/('audit-'+str(k)+'.xml');ET.ElementTree(d).write(req)
    state=run('--audit-worker',req,res,a.timeout)
    result={'name':d.get('name'),'state':state}
    if res.exists():result.update(ET.parse(res).getroot().attrib)
    result['pass']=result.get('loaded')=='1' and result.get('rendered')=='1' and result.get('editorCreated')=='1' and result.get('closed')=='1' and state=='exit 0'
    r['plugins'].append(result)
  except ET.ParseError as error:r['error']=str(error)
 records.append(r);(out/'inventory.json').write_text(json.dumps(records,indent=2,ensure_ascii=False))
 line=str(index+1)+'/'+str(len(items))+' '+pathlib.Path(path).name+' | '+r['discovery']+' | '+str(sum(x['pass'] for x in r['plugins']))+'/'+str(len(r['plugins']))+' load / render / GUI PASS'
 print(line,flush=True)
 with (out/'progress.txt').open('a') as f:f.write(line+'\n')
print('AUDIT COMPLETE',flush=True)
