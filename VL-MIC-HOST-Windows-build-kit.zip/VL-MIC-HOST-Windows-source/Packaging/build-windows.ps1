$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
function Invoke-Checked { param([string]$Program, [string[]]$Arguments)
  & $Program @Arguments
  if ($LASTEXITCODE -ne 0) { throw "$Program failed with code $LASTEXITCODE" }
}
if (!(Test-Path 'JUCE/CMakeLists.txt')) { throw 'Place JUCE 8.0.6 sources in the JUCE folder first.' }
Invoke-Checked cmake @('-S','.', '-B','build','-A','x64',"-DJUCE_PATH=$((Resolve-Path JUCE).Path)")
Invoke-Checked cmake @('--build','build','--config','Release','--parallel','4')
$exe = Join-Path $PWD 'build/VLMicHost_artefacts/Release/VL MIC HOST.exe'
$test = Start-Process -FilePath $exe -ArgumentList '--smoke-test' -PassThru
if (!$test.WaitForExit(60000)) { $test.Kill(); throw 'Smoke test timed out' }
if ($test.ExitCode -ne 0) { throw 'Smoke test failed' }
if (!(Test-Path 'smoke-test.txt')) { throw 'Missing smoke-test report' }
Get-Content 'smoke-test.txt'
New-Item -ItemType Directory -Force dist | Out-Null
$source = Join-Path $env:TEMP ([guid]::NewGuid().ToString())
New-Item -ItemType Directory $source | Out-Null
foreach ($item in @('Source','Assets','Licenses','Packaging','.github','JUCE','CMakeLists.txt','LICENSE','README.md','WINDOWS-README.txt')) {
 Copy-Item $item $source -Recurse
}
Compress-Archive -Path "$source/*" -DestinationPath 'dist/VL-MIC-HOST-Windows-Complete-Source.zip' -Force
$iscc = Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6/ISCC.exe'
if (!(Test-Path $iscc)) { throw 'Install Inno Setup 6 before packaging.' }
Invoke-Checked $iscc @('Packaging/windows.iss')
Get-ChildItem dist/*.exe | Get-FileHash -Algorithm SHA256 | Format-List | Out-File dist/SHA256.txt
