$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
function Invoke-Checked { param([string]$Program, [string[]]$Arguments)
  & $Program @Arguments
  if ($LASTEXITCODE -ne 0) { throw "$Program failed with code $LASTEXITCODE" }
}
if (!(Test-Path 'JUCE/CMakeLists.txt')) { throw 'Place JUCE 8.0.6 sources in the JUCE folder first.' }
if (!(Test-Path 'ThirdParty/ASIO/iasiodrv.h')) { throw 'Bundled ASIO interfaces are missing. Use the complete 0.6.7 build kit.' }
Invoke-Checked -Program cmake -Arguments @('-S','.', '-B','build','-A','x64',"-DJUCE_PATH=$((Resolve-Path JUCE).Path)",'-DVL_BUILD_TEST_FIXTURES=ON')
Invoke-Checked -Program cmake -Arguments @('--build','build','--config','Release','--parallel','4')
$exe = Join-Path $PWD 'build/VLMicHost_artefacts/Release/VL MIC HOST.exe'
$env:VL_SHELL_FIXTURE_PATH = Join-Path $PWD 'build/TestPlugins/VLReorderingShell.vst3'
$savedDataDirectory = $env:VL_MIC_HOST_DATA_DIR
$env:VL_MIC_HOST_DATA_DIR = Join-Path $PWD 'build/ValidationData'
try {
  foreach ($case in @(
    @{ Argument='--smoke-test'; Report='smoke-test.txt' },
    @{ Argument='--monitor-test'; Report='monitor-validation.txt' },
    @{ Argument='--discord-test'; Report='discord-test.txt' },
    @{ Argument='--guitar-input-test'; Report='guitar-input-test.txt' },
    @{ Argument='--driver-test'; Report='driver-test.txt' },
    @{ Argument='--plugin-search-test'; Report='plugin-search-test.txt' },
    @{ Argument='--plugin-bus-test'; Report='plugin-bus-test.txt' },
    @{ Argument='--shell-plugin-test'; Report='shell-plugin-test.txt' }
  )) {
    Remove-Item $case.Report -ErrorAction SilentlyContinue
    $test = Start-Process -FilePath $exe -ArgumentList $case.Argument -WorkingDirectory $PWD -PassThru
    if (!$test.WaitForExit(60000)) { $test.Kill(); throw "$($case.Argument) timed out" }
    if ($test.ExitCode -ne 0) {
      $details = if (Test-Path $case.Report) { Get-Content $case.Report -Raw } else { 'The test did not create a report.' }
      throw "$($case.Argument) failed ($($test.ExitCode)): $details"
    }
    if (!(Test-Path $case.Report)) { throw "Missing $($case.Report)" }
    $report = Get-Content $case.Report -Raw
    if ($report -match 'FAIL' -or $report -notmatch 'PASS') { throw "Failed report: $($case.Report)" }
    Write-Output $report
  }
} finally {
  $env:VL_MIC_HOST_DATA_DIR = $savedDataDirectory
}

New-Item -ItemType Directory -Force dist | Out-Null
New-Item -ItemType Directory -Force dist/Checks | Out-Null
Copy-Item smoke-test.txt,monitor-validation.txt,discord-test.txt,guitar-input-test.txt,driver-test.txt,plugin-search-test.txt,plugin-bus-test.txt,shell-plugin-test.txt dist/Checks
$source = Join-Path $env:TEMP ([guid]::NewGuid().ToString())
New-Item -ItemType Directory $source | Out-Null
foreach ($item in @('Source','Tests','Assets','Licenses','ThirdParty','Packaging','.github','Presets','JUCE','CMakeLists.txt','LICENSE','README.md','WINDOWS-README.txt')) {
 Copy-Item $item $source -Recurse
}
Compress-Archive -Path "$source/*" -DestinationPath 'dist/VL-MIC-HOST-Windows-Complete-Source.zip' -Force
Remove-Item $source -Recurse -Force
$iscc = Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6/ISCC.exe'
if (!(Test-Path $iscc)) { throw 'Install Inno Setup 6 before packaging.' }
Invoke-Checked -Program $iscc -Arguments @('Packaging/windows.iss')
Get-ChildItem dist/*.exe | Get-FileHash -Algorithm SHA256 | Format-List | Out-File dist/SHA256.txt
