# Backport of JUCE commit 3fa28d0a14f1be97d49603c710afaa6b9b900cdb.
# https://github.com/juce-framework/JUCE/commit/3fa28d0a14f1be97d49603c710afaa6b9b900cdb
# WaveShell may reorder its classes on setHostContext. Look up the class only
# AFTER setting the context, and use that same context for instantiation.
# Work on a build-local copy; never edit the user's original JUCE checkout.
function(vl_prepare_juce source_dir result)
  set(destination "${CMAKE_BINARY_DIR}/VLPatchedJUCE")
  set(source_file "${destination}/modules/juce_audio_processors/format_types/juce_VST3PluginFormat.cpp")
  set(original_file "${source_dir}/modules/juce_audio_processors/format_types/juce_VST3PluginFormat.cpp")
  # MSBuild can re-run CMake in parallel for different targets. Prepare once,
  # under a lock, so regeneration cannot overwrite a file another job is using.
  file(LOCK "${CMAKE_BINARY_DIR}/VLPatchedJUCE.lock" GUARD FUNCTION TIMEOUT 120)
  file(SHA256 "${original_file}" original_hash)
  file(SHA256 "${CMAKE_CURRENT_FUNCTION_LIST_FILE}" patch_hash)
  set(signature "${source_dir}|${original_hash}|${patch_hash}")
  set(stamp "${CMAKE_BINARY_DIR}/VLPatchedJUCE.ready")
  if(EXISTS "${stamp}" AND EXISTS "${source_file}")
    file(READ "${stamp}" saved)
    file(SHA256 "${source_file}" prepared_hash)
    if(saved STREQUAL "${signature}\n${prepared_hash}\n")
      set(${result} "${destination}" PARENT_SCOPE)
      return()
    endif()
  endif()
  file(READ "${original_file}" contents)
  string(REPLACE "\r\n" "\n" contents "${contents}")

  set(before "static VST3ModuleHandle create (const File& pluginFile, const PluginDescription& desc)")
  set(after "static VST3ModuleHandle create (const File& pluginFile, const PluginDescription& desc, FUnknown* hostContext)")
  string(FIND "${contents}" "${before}" position)
  if(position EQUAL -1)
    message(FATAL_ERROR "VL WaveShell backport requires the pinned JUCE 8.0.6 source")
  endif()
  string(REPLACE "${before}" "${after}" contents "${contents}")
  set(before "        const auto numClasses = factory->countClasses();\n        result.classIndex = findClassMatchingDescription (factory, desc);")
  set(after "        // VL: upstream JUCE 3fa28d0; WaveShell changes its class list here.\n        if (VSTComSmartPtr<IPluginFactory3> factory3; factory3.loadFrom (factory.get()))\n            factory3->setHostContext (hostContext);\n\n${before}")
  string(REPLACE "${before}" "${after}" contents "${contents}")
  set(before "    explicit VST3ComponentHolder (const VST3ModuleHandle& m)\n        : module (m)\n    {\n        host = addVSTComSmartPtrOwner (new VST3HostContext());\n    }")
  set(after "    VST3ComponentHolder (const VST3ModuleHandle& m, VSTComSmartPtr<VST3HostContext> context)\n        : module (m), host (context)\n    {}")
  string(REPLACE "${before}" "${after}" contents "${contents}")
  string(REPLACE "    const auto module = VST3ModuleHandle::create (file, description);"
    "    auto host = addVSTComSmartPtrOwner (new VST3HostContext());\n    const auto module = VST3ModuleHandle::create (file, description, host->getFUnknown());" contents "${contents}")
  string(REPLACE "std::make_unique<VST3ComponentHolder> (module);"
    "std::make_unique<VST3ComponentHolder> (module, host);" contents "${contents}")
  # A changed upstream source must fail loudly instead of shipping a partial fix.
  foreach(expected "factory3->setHostContext (hostContext);" ": module (m), host (context)" "description, host->getFUnknown()" "VST3ComponentHolder> (module, host)")
    string(FIND "${contents}" "${expected}" position)
    if(position EQUAL -1)
      message(FATAL_ERROR "Could not apply complete VL WaveShell backport: ${expected}")
    endif()
  endforeach()
  file(COPY "${source_dir}/" DESTINATION "${destination}" PATTERN ".git" EXCLUDE)
  file(WRITE "${source_file}" "${contents}")
  file(SHA256 "${source_file}" prepared_hash)
  file(WRITE "${stamp}" "${signature}\n${prepared_hash}\n")
  message(STATUS "VL: applied JUCE WaveShell class-order fix 3fa28d0")
  set(${result} "${destination}" PARENT_SCOPE)
endfunction()
