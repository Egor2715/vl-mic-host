// SPDX-License-Identifier: AGPL-3.0-only
// Test fixture only. Reproduces WaveShell's factory-class reorder when the host
// first calls setHostContext. Not part of the installer or a commercial effect.
#include <pluginterfaces/base/ipluginbase.h>
#include <pluginterfaces/vst/ivstcomponent.h>
#include <pluginterfaces/vst/ivstaudioprocessor.h>
#include <pluginterfaces/vst/ivsteditcontroller.h>
#include <pluginterfaces/vst/vstspeaker.h>
#include <atomic>
#include <cstring>
using namespace Steinberg;
using namespace Steinberg::Vst;
namespace {
bool same(const void* a, const void* b) { return std::memcmp(a,b,16)==0; }
void cid(int id, TUID out) {
    const TUID value=INLINE_UID(0x564c5445,0x53545348,0x454c4c00,id);
    std::memcpy(out,value,16);
}
const char* name(int id) {
    switch(id) {
        case 1:return "VL Fixture Mono";case 2:return "VL Fixture Stereo";
        case 3:return "VL Fixture Surround 6.1";case 4:return "VL Fixture Other";
        default:return "VL Fixture Controller";
    }
}
void text(TChar* dst,const char* src) { while(*src)*dst++=static_cast<TChar>(*src++);*dst=0; }
class Effect final : public IComponent, public IAudioProcessor, public IEditController {
    std::atomic<uint32> refs{1};int id, channels;SpeakerArrangement layout;
public:
    explicit Effect(int i):id(i),channels(i==3?7:i==2?2:1),layout(i==3?SpeakerArr::k61Music:i==2?SpeakerArr::kStereo:SpeakerArr::kMono){}
    tresult PLUGIN_API queryInterface(const TUID iid,void** obj) override {
        *obj=nullptr;
        if(same(iid,IComponent_iid)||same(iid,IPluginBase_iid)||same(iid,FUnknown_iid))*obj=static_cast<IComponent*>(this);
        else if(same(iid,IAudioProcessor_iid))*obj=static_cast<IAudioProcessor*>(this);
        else if(same(iid,IEditController_iid))*obj=static_cast<IEditController*>(this);
        if(!*obj)return kNoInterface;addRef();return kResultOk;
    }
    uint32 PLUGIN_API addRef() override { return ++refs; }
    uint32 PLUGIN_API release() override { auto n=--refs;if(!n)delete this;return n; }
    tresult PLUGIN_API initialize(FUnknown*) override {return kResultOk;}
    tresult PLUGIN_API terminate() override {return kResultOk;}
    tresult PLUGIN_API getControllerClassId(TUID) override {return kResultFalse;}
    tresult PLUGIN_API setIoMode(IoMode) override {return kResultOk;}
    int32 PLUGIN_API getBusCount(MediaType type,BusDirection) override {return type==kAudio?1:0;}
    tresult PLUGIN_API getBusInfo(MediaType type,BusDirection dir,int32 index,BusInfo& info) override {
        if(type!=kAudio||index!=0)return kInvalidArgument;info={};info.mediaType=type;info.direction=dir;
        info.channelCount=channels;info.busType=kMain;info.flags=BusInfo::kDefaultActive;text(info.name,"Main");return kResultOk;
    }
    tresult PLUGIN_API getRoutingInfo(RoutingInfo&,RoutingInfo&) override {return kNotImplemented;}
    tresult PLUGIN_API activateBus(MediaType type,BusDirection,int32 index,TBool) override {return type==kAudio&&index==0?kResultOk:kInvalidArgument;}
    tresult PLUGIN_API setActive(TBool) override {return kResultOk;}
    tresult PLUGIN_API setState(IBStream*) override {return kResultOk;}
    tresult PLUGIN_API getState(IBStream*) override {return kResultOk;}
    tresult PLUGIN_API setBusArrangements(SpeakerArrangement* in,int32 ni,SpeakerArrangement* out,int32 no) override {
        return ni==1&&no==1&&in[0]==layout&&out[0]==layout?kResultOk:kResultFalse;
    }
    tresult PLUGIN_API getBusArrangement(BusDirection,int32 index,SpeakerArrangement& out) override {out=layout;return index==0?kResultOk:kInvalidArgument;}
    tresult PLUGIN_API canProcessSampleSize(int32 size) override {return size==kSample32?kResultOk:kResultFalse;}
    uint32 PLUGIN_API getLatencySamples() override {return 0;}
    tresult PLUGIN_API setupProcessing(ProcessSetup&) override {return kResultOk;}
    tresult PLUGIN_API setProcessing(TBool) override {return kResultOk;}
    tresult PLUGIN_API process(ProcessData& d) override {
        if(d.numInputs!=1||d.numOutputs!=1)return kResultOk;
        const float gain=id==1?2.0f:id==2?3.0f:9.0f;
        for(int ch=0;ch<channels;++ch)for(int n=0;n<d.numSamples;++n)
            d.outputs[0].channelBuffers32[ch][n]=d.inputs[0].channelBuffers32[ch][n]*gain;
        d.outputs[0].silenceFlags=0;return kResultOk;
    }
    uint32 PLUGIN_API getTailSamples() override {return 0;}
    tresult PLUGIN_API setComponentState(IBStream*) override {return kResultOk;}
    int32 PLUGIN_API getParameterCount() override {return 0;}
    tresult PLUGIN_API getParameterInfo(int32,ParameterInfo&) override {return kInvalidArgument;}
    tresult PLUGIN_API getParamStringByValue(ParamID,ParamValue,String128) override {return kInvalidArgument;}
    tresult PLUGIN_API getParamValueByString(ParamID,TChar*,ParamValue&) override {return kInvalidArgument;}
    ParamValue PLUGIN_API normalizedParamToPlain(ParamID,ParamValue v) override {return v;}
    ParamValue PLUGIN_API plainParamToNormalized(ParamID,ParamValue v) override {return v;}
    ParamValue PLUGIN_API getParamNormalized(ParamID) override {return 0;}
    tresult PLUGIN_API setParamNormalized(ParamID,ParamValue) override {return kInvalidArgument;}
    tresult PLUGIN_API setComponentHandler(IComponentHandler*) override {return kResultOk;}
    IPlugView* PLUGIN_API createView(FIDString) override {return nullptr;}
};
class Factory final : public IPluginFactory3 {
    std::atomic<uint32> refs{1};bool expanded=false;
    int classId(int index) const {
        static const int before[]={4,1,3,2},after[]={4,3,104,101,1,2,103,102};
        if(index<0||index>=(expanded?8:4))return -1;return expanded?after[index]:before[index];
    }
public:
    tresult PLUGIN_API queryInterface(const TUID iid,void** obj) override {
        *obj=nullptr;if(same(iid,FUnknown_iid)||same(iid,IPluginFactory_iid)||same(iid,IPluginFactory2_iid)||same(iid,IPluginFactory3_iid))*obj=static_cast<IPluginFactory3*>(this);
        if(!*obj)return kNoInterface;addRef();return kResultOk;
    }
    uint32 PLUGIN_API addRef() override {return ++refs;}
    uint32 PLUGIN_API release() override {auto n=--refs;if(!n)delete this;return n;}
    tresult PLUGIN_API getFactoryInfo(PFactoryInfo* info) override {*info=PFactoryInfo("VL test fixture","","",0);return kResultOk;}
    int32 PLUGIN_API countClasses() override {return expanded?8:4;}
    tresult PLUGIN_API getClassInfo(int32 index,PClassInfo* info) override {
        int id=classId(index);if(id<0)return kInvalidArgument;TUID uid;cid(id,uid);
        *info=PClassInfo(uid,PClassInfo::kManyInstances,id<100?kVstAudioEffectClass:kVstComponentControllerClass,name(id));return kResultOk;
    }
    tresult PLUGIN_API getClassInfo2(int32 index,PClassInfo2* info) override {
        int id=classId(index);if(id<0)return kInvalidArgument;TUID uid;cid(id,uid);
        *info=PClassInfo2(uid,PClassInfo::kManyInstances,id<100?kVstAudioEffectClass:kVstComponentControllerClass,name(id),0,"Fx","VL test fixture","1.0","VST 3");return kResultOk;
    }
    tresult PLUGIN_API getClassInfoUnicode(int32 index,PClassInfoW* info) override {
        PClassInfo2 c;if(getClassInfo2(index,&c)!=kResultOk)return kInvalidArgument;*info={};
        std::memcpy(info->cid,c.cid,16);info->cardinality=c.cardinality;std::strcpy(info->category,c.category);
        std::strcpy(info->subCategories,c.subCategories);text(info->name,c.name);text(info->vendor,c.vendor);text(info->version,c.version);text(info->sdkVersion,c.sdkVersion);return kResultOk;
    }
    tresult PLUGIN_API createInstance(FIDString classUID,FIDString iid,void** obj) override {
        *obj=nullptr;for(int i=1;i<=4;++i){TUID uid;cid(i,uid);if(same(classUID,uid)){
            auto* effect=new Effect(i);auto r=effect->queryInterface(iid,obj);effect->release();return r;
        }}return kNoInterface;
    }
    tresult PLUGIN_API setHostContext(FUnknown* context) override {if(context)expanded=true;return kResultOk;}
};
}
#if defined(_WIN32)
#define VL_EXPORT extern "C" __declspec(dllexport)
VL_EXPORT bool PLUGIN_API InitDll(){return true;}
VL_EXPORT bool PLUGIN_API ExitDll(){return true;}
#else
#define VL_EXPORT extern "C" __attribute__((visibility("default")))
VL_EXPORT bool bundleEntry(void*){return true;}
VL_EXPORT bool bundleExit(){return true;}
#endif
VL_EXPORT IPluginFactory* PLUGIN_API GetPluginFactory(){return new Factory();}
